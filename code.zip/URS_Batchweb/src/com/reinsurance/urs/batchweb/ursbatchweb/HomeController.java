package com.reinsurance.urs.batchweb.ursbatchweb;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batchweb.launcher.JobSchedulerService;
import com.reinsurance.urs.domain.batch.Cycle;
import com.reinsurance.urs.domain.batch.JobParam;
import com.reinsurance.urs.domain.batch.ProcessEntity;
import com.reinsurance.urs.domain.batch.ProcessSchedule;

/**
 * Handles requests for the application home page.
 */
@Controller
@SuppressWarnings({ "rawtypes", "unchecked" })
public class HomeController extends BaseHomecontroller {

	@Autowired
	@Qualifier("jobSchedulerService")
	JobSchedulerService jobSchedulerService;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	public String genericHome(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		List list_process_execution_history_data = getprocessExecutionHistoryData();
		Map<String, Object> modelDataMap = new HashMap<String, Object>();
		modelDataMap.put("list_process_execution_history_data", list_process_execution_history_data);
		model.addAttribute("model", modelDataMap);

		return "index";
	}

	/**
	 * Simply selects the cycle view to render all the cycle details by
	 * returning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/Cycle", method = RequestMethod.GET)
	public ModelAndView batchMonitorCycle(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String statusForDeleteCycle = null;
		if (request.getAttribute("statusForDeleteCycle") != null)
			statusForDeleteCycle = request.getAttribute("statusForDeleteCycle").toString();
		logger.debug("Mapping to the CycleDetails page showing list of cycle details.......statusForDeleteCycle  is--------------------"
				+ statusForDeleteCycle);
		Map<String, Object> model = new HashMap<String, Object>();
		model = loadCycleDetails();
		model.put("statusForDeleteCycle", statusForDeleteCycle);
		return new ModelAndView("CycleDetails", "model", model);
	}

	/**
	 * Simply forward to the cycle view indirectly through ToBatchMonitorCycle
	 * page byreturning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/BatchMonitorCycleForward", method = RequestMethod.POST)
	public ModelAndView BatchMonitorCycleForward(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String Cyclemessage = null;
		logger.debug("Forwarding the request to the CycleDetails page showing list of cycle details.......");
		if (request.getAttribute("Cyclemessage") != null)
			Cyclemessage = request.getAttribute("Cyclemessage").toString();
		Map<String, Object> model = new HashMap<String, Object>();
		model = loadCycleDetails();
		model.put("Cyclemessage", Cyclemessage);
		return new ModelAndView("CycleDetails", "model", model);
	}

	/**
	 * Simply map the request to this method to ad cycle.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/addCycle", method = RequestMethod.POST)
	// or GET
	public ModelAndView addCycle(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Adding a Cycle Details.......");
		addCycle(request);
		Map<String, Object> model = new HashMap<String, Object>();
		return new ModelAndView("ToBatchMonitorCycle", "model", model);

	}

	/**
	 * Simply map the request to this method for creating new cycle or editing a
	 * existing cycle.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/newCycle", method = RequestMethod.GET)
	public ModelAndView newCycle(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Mapping the request to the newCycle page for creating a new Cycle or editing an existing Cycle.......");
		List<Cycle> CycleListData = new ArrayList<Cycle>();
		CycleListData = getAllCycleList();
		if (CycleListData != null && !CycleListData.isEmpty())
			request.setAttribute("cycleListData", CycleListData);
		Map<String, Object> model = new HashMap<String, Object>();
		Map<String, Object> cycleList = null;
		List jobList = getJobs();
		model.put("jobList", jobList);
		if (request.getParameter("cEdit") != null) {
			cycleList = editCycleParameters(request);
			model.put("cycleList", cycleList.get("cycleData"));
			model.put("cyclejob", cycleList.get("jobDataList"));
			model.put("cycleId", cycleList.get("cycleId"));
		} else {
			model.put("cycleList", null);
			model.put("cyclejob", null);
			model.put("cycleId", null);
		}

		return new ModelAndView("newCycle", "model", model);

	}

	/**
	 * Simply selects the process view to render all the process details by
	 * returning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/Process", method = RequestMethod.GET)
	public ModelAndView batchMonitorProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Mapping to the ProcessEntity page by showing the process details.......");
		Map<String, Object> model = new HashMap<String, Object>();
		model = listAllProcessDetails(request);
		// model.put("msgForAddDeleteProcess", msgStatus);
		return new ModelAndView("Process", "model", model);
	}

	/**
	 * Simply forward the request to process view indirectly through
	 * ToBatchMonitorProcess page by returning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/BatchMonitorProcessForward", method = RequestMethod.POST)
	public ModelAndView BatchMonitorProcessForward(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String msgStatus = "";
		msgStatus = request.getAttribute("msgForAddProcess").toString();
		logger.debug("Forwarding the request to the ProcessEntity page showing list of process details.......");
		Map<String, Object> model = new HashMap<String, Object>();

		model = listAllProcessDetails(request);
		model.put("msgForAddDeleteProcess", msgStatus);

		return new ModelAndView("Process", "model", model);
	}

	/**
	 * Simply map the request to this page to add process.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/addProcess", method = RequestMethod.POST)
	// or GET
	public ModelAndView addProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Adding a process details.......");
		ProcessEntity process = null;
		ProcessSchedule processSchedule = null;

		process = addProcess(request);

		/* schedule process if its changed to active state */
		if (process != null && process.getProcessStatus()== URSBatchConstants.PROCESS_STATE_ACTIVE_CD) {
			logger.info("checking if this process is scheduled before?"
					+ jobSchedulerService.isJobScheduled(process.getProcessId(), process.getProcessName()));
			if (!jobSchedulerService.isJobScheduled(process.getProcessId(), process.getProcessName())) {
				processSchedule = process.getProcessSchedule();
				logger.info("this process is not scheduled before ,so scheduling process" + process.getProcessName()
						+ " in schedule : " + processSchedule.toString());
				jobSchedulerService.buildJobDetailsAndStart(process);
			}
		}

		Map<String, Object> model = new HashMap<String, Object>();
		return new ModelAndView("ToBatchMonitorProcess", "model", model);
	}

	/**
	 * Simply map the request to this method to create new process or edit
	 * existing process
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/newProcess", method = RequestMethod.GET)
	// or GET
	public ModelAndView newProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Mapping the request to the newProcess page for creating a new ProcessEntity or editing an existing ProcessEntity.......");
		List cycleList = new ArrayList();
		List<ProcessEntity> ProcessListData = new ArrayList<ProcessEntity>();
		ProcessListData = getAllProcessList();
		if (ProcessListData != null && !ProcessListData.isEmpty())
			request.setAttribute("processListData", ProcessListData);
		Map<String, Object> processList = new HashMap<String, Object>();
		cycleList = getCycles();
		processList = editProcessParameters(request);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("cycleList", cycleList);
		model.put("processList", processList.get("processData"));
		model.put("processcycle", processList.get("cycleDataList"));
		List<URSBatchConstants.Month> monthList = new ArrayList<URSBatchConstants.Month>(
				Arrays.asList(URSBatchConstants.Month.values()));
		model.put("monthEnum", monthList);
		List<URSBatchConstants.Day> dayList = new ArrayList<URSBatchConstants.Day>(Arrays.asList(URSBatchConstants.Day
				.values()));
		model.put("dayEnum", dayList);
		List<URSBatchConstants.Frequency> frequencyList = new ArrayList<URSBatchConstants.Frequency>(
				Arrays.asList(URSBatchConstants.Frequency.values()));
		model.put("frequencyEnum", frequencyList);
		if (processList.get("processStatus") != null)
			model.put("processStatus", Integer.parseInt(processList.get("processStatus").toString().trim()));
		if (processList.get("processId") != null)
			model.put("processId", Long.parseLong(processList.get("processId").toString().trim()));
		return new ModelAndView("newProcess", "model", model);

	}

	/**
	 * Simply map the request to this method to create new popup for error
	 * message of process execution history
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/errorMessage", method = RequestMethod.GET)
	// or GET
	public ModelAndView errorMessage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List list_process_execution_history_data = getprocessExecutionHistoryData();
		String processErrorMessage = getProcessInstaceError(request);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("errorMessageForProcess", list_process_execution_history_data);
		model.put("processErrorMessage", processErrorMessage);
		return new ModelAndView("errorMessage", "model", model);

	}

	/**
	 * Simply map the request to this method to create new popup for error
	 * message of cycle execution history
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/errorMessageCycle", method = RequestMethod.GET)
	// or GET
	public ModelAndView errorMessageCycle(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		String cycleErrorMessage = getCycleInstaceError(request);
		model.put("cycleErrorMessage", cycleErrorMessage);
		return new ModelAndView("errorMessageCycle", "model", model);

	}

	/**
	 * Simply map the request to this method to create new popup for error
	 * message of job execution history
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/errorMessageJob", method = RequestMethod.GET)
	// or GET
	public ModelAndView errorMessageJob(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		logger.debug("Before getJobInstaceError----");
		String jobErrorMessage = getJobInstaceError(request);
		model.put("jobErrorMessage", jobErrorMessage);
		return new ModelAndView("errorMessageJob", "model", model);

	}

	/**
	 * Simply map the request to this method to delete a process
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/delProcess", method = RequestMethod.GET)
	// or GET
	public ModelAndView delProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// boolean delStatus = false;
		logger.debug("deleting a ProcessEntity.......");
		// delStatus =
		delProcess(request);

		return batchMonitorProcess(request, response);
	}

	/**
	 * Simply map the request to this method to delete a cycle
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/delCycle", method = RequestMethod.GET)
	// or GET
	public ModelAndView delCycle(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String statusForDeleteCycle = null;
		logger.info("deleting cycle for cycleID" + request.getParameter("delCycleId"));
		statusForDeleteCycle = delCycle(request);
		request.setAttribute("statusForDeleteCycle", statusForDeleteCycle);
		return batchMonitorCycle(request, response);
	}

	/**
	 * Simply map the request to this method to launch the process
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/launchProcess", method = RequestMethod.POST)
	public ModelAndView launchProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String processid = request.getParameter("processId");
		if (processid != null) {
			long processId = Long.parseLong(processid);
			addProcess(request);
			ProcessEntity process = getProcessByProcessId(processId);
			lunchProcess(process);
		}
		return batchMonitorProcess(request, response);
	}

	/**
	 * Simply map the request to this method to processDetails view to render by
	 * returning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/processDetails", method = RequestMethod.GET)
	// or GET
	public ModelAndView processDetails(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String processexecutionId = request.getParameter("processExecutionInstanceId");
		Map<String, Object> model = new HashMap<String, Object>();
		if (processexecutionId != null) {
			List list_cycle_execution_history_data = getcycleExecutionHistoryData(Integer.parseInt(processexecutionId));
			model.put("model_cycle_execution_history_data", list_cycle_execution_history_data);
		}
		return new ModelAndView("processDetails", "model", model);

	}

	/**
	 * Simply map the request to this method to restartProcess view to render by
	 * returning its name. It simply returns all the cycles of a process with
	 * all the jobs of cycles. On Page load the fail cyccle along with fail job
	 * will be selected in the drop down in restartProcess page.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/restartProcessForCycle", method = RequestMethod.GET)
	// or GET
	public ModelAndView restartProcessForCycle(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String processexecutionId = request.getParameter("processExecutionInstanceId");
		Map<String, Object> model = new HashMap<String, Object>();
		if (processexecutionId != null) {
			List totalList = getCycleNameByProcessInstanceId(Integer.parseInt(processexecutionId));
			if (totalList != null) {
				List cycleList = (List) totalList.get(0);
				List jobList = (List) totalList.get(1);
				model.put("model_jobList", jobList);
				model.put("model_list_cycle_job_data", cycleList);
				model.put("processId", ((Map<String, Object>) totalList.get(2)).get("processId"));
				model.put("processExecutionID", ((Map<String, Object>) totalList.get(2)).get("processExecutionID"));
			}
		}
		return new ModelAndView("restartProcess", "model", model);

	}

	/**
	 * Simply map the request to this method to restartProcess view to render by
	 * returning its name. It simply returns all the cycles of a process with
	 * all the jobs of cycles. This mapping is used at the time of changing the
	 * cycle in the drop down of restartProcess page.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/restartProcessForJob", method = RequestMethod.POST)
	public ModelAndView restartProcessForJob(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		List totalList = getJobNameByCycleName(request);
		if (totalList != null) {
			List jobList = (List) totalList.get(0);
			List cycleList = new ArrayList();
			for (int i = 1; i < totalList.size() - 2; i++) {
				cycleList.add(totalList.get(i));
			}
			model.put("model_jobList", jobList);
			model.put("model_list_cycle_job_data", cycleList);
			model.put("processId", ((Map<String, Object>) totalList.get(totalList.size() - 2)).get("processId"));
			model.put("processExecutionID",
					((Map<String, Object>) totalList.get(totalList.size() - 2)).get("processExecutionID"));
			model.put("selectedRadio", ((Map<String, Object>) totalList.get(totalList.size() - 2)).get("selectedRadio"));
		}
		return new ModelAndView("restartProcess", "model", model);
	}

	/**
	 * Simply map the request to this method to re launch the process in home
	 * page.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/reLaunchProcess", method = RequestMethod.POST)
	public ModelAndView reLaunchProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		String hdnProcessId = request.getParameter("hiddenProcessId");
		String hdnProcessExecutionId = request.getParameter("hiddenProcessExecutionId");
		String restsrtOptions = request.getParameter("restsrtOptions");
		if (hdnProcessId != null && hdnProcessExecutionId != null && restsrtOptions != null) {
			String optone = request.getParameter("optone");
			String opttwo = request.getParameter("opttwo");
			long processId = Long.parseLong(hdnProcessId);
			long processExecutionId = Long.parseLong(hdnProcessExecutionId);
			long cycleId = Long.parseLong(optone.split(",")[0]);
			long jobId = Long.parseLong(opttwo);
			relunchProcess(restsrtOptions, processId, processExecutionId, cycleId, jobId);
		}
		return new ModelAndView("ToBatchMonitorIndex", "model", model);

	}

	/**
	 * Simply used to forward the request to homepage.
	 * 
	 * @param locale
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/BatchMonitorIndexForward", method = RequestMethod.POST)
	public String BatchMonitorIndexForward(Locale locale, Model model) throws Exception {
		List list_process_execution_history_data = getprocessExecutionHistoryData();
		Map<String, Object> modelDataMap = new HashMap<String, Object>();
		modelDataMap.put("list_process_execution_history_data", list_process_execution_history_data);
		model.addAttribute("model", modelDataMap);

		return "index";
	}

	/**
	 * Simply map the request to this method to jobDetails view to render by
	 * returning its name.
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/Job", method = RequestMethod.GET)
	public ModelAndView batchMonitorJob(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Mapping to the JobDetails page showing list of job details.......");
		Map<String, Object> model = new HashMap<String, Object>();
		model = loadJobDetails();
		return new ModelAndView("JobDetails", "model", model);
	}

	@RequestMapping(value = "/addInputs", method = RequestMethod.POST)
	public ModelAndView addInputs(HttpServletRequest request, HttpServletResponse response) throws Exception {
		long processId = 0;
		if (request.getParameter("processId") != null)
			processId = Long.parseLong(request.getParameter("processId"));
		else {
			if (request.getAttribute("processId") != null)
				processId = (Long) request.getAttribute("processId");
		}
		boolean flag = true;
		List<List<Map>> cycleListForProcess = new ArrayList<List<Map>>();

		cycleListForProcess = findCycleListForProcess(processId, flag);
		logger.debug("Mapping to the JobDetails page showing list of job details.......");
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("cycleListForProcess", cycleListForProcess);
		model.put("jobFlag", ((Map<String, Object>) ((cycleListForProcess.get(0)).get(0))).get("flag"));
		return new ModelAndView("processinputDetails", "model", model);
	}

	@RequestMapping(value = "/jobParams", method = RequestMethod.GET)
	public ModelAndView jobParams(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int numberParameters = 0;
		String jobName = "";
		long processCycleRelationId = 0;
		long cycleJobRelationId = 0;
		long processId = 0;
		List<JobParam> jobParamsList = new ArrayList<JobParam>();
		boolean flag = false;
		String pageValue = "";
		if (!request.getParameter("jobName").equals("") && !request.getParameter("processCycleRelationId").equals("")
				&& !request.getParameter("cycleJobRelationId").equals("")
				&& !request.getParameter("processId").equals("")) {
			processCycleRelationId = Long.parseLong(request.getParameter("processCycleRelationId"));
			cycleJobRelationId = Long.parseLong(request.getParameter("cycleJobRelationId"));
			processId = Long.parseLong(request.getParameter("processId"));
			jobName = request.getParameter("jobName");
			jobParamsList = findJobsParamsOccurance(jobName, cycleJobRelationId, processCycleRelationId);
			for (JobParam tempJob : jobParamsList) {
				if (!tempJob.getParamName().equals("")) {
					flag = true;
				}

			}
			if (flag)
				pageValue = "form";
			else
				return addInputs(request, response);
		} else {
			pageValue = "processinputDetails";
		}
		logger.debug("Mapping to the JobDetails page showing list of job details.......");
		request.setAttribute("numberParams", numberParameters);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("noParams", jobParamsList.size());
		model.put("jobParamValue", jobParamsList);
		model.put("jobName", jobParamsList.get(0).getJobId());
		model.put("processCycleRelationId", processCycleRelationId);
		model.put("cycleJobRelationId", cycleJobRelationId);
		model.put("processId", processId);
		return new ModelAndView(pageValue, "model", model);
	}

	@RequestMapping(value = "/jobParamsNext", method = RequestMethod.POST)
	public ModelAndView jobParamsNext(HttpServletRequest request, HttpServletResponse response) throws Exception {
		long paramId = 0;
		int typeCode = 0;
		String paramType = "";
		long processCycleRelationId = 0;
		long cycleJobRelationId = 0;
		String stringValue = "";
		long doubleValue = 0;
		Date dateValue = null;
		boolean valueFlag = false;
		String jobValue = "";
		int hiddenInputParams = Integer.parseInt(request.getParameter("hiddenInputParams"));
		for (int i = 1; i <= hiddenInputParams; i++) {
			stringValue = "";
			doubleValue = 0;
			dateValue = null;
			if (request.getParameter("element" + i) != null) {
				valueFlag = true;
				jobValue = request.getParameter("element" + i);
			}
			if (request.getParameter("element" + i + "s") != null) {
				StringTokenizer st = new StringTokenizer(request.getParameter("element" + i + "s"), ",");
				int count = 1;
				while (st.hasMoreTokens()) {
					String tokenValue = st.nextToken();
					if (count == 1) {
						paramId = Integer.parseInt(tokenValue);
					}
					if (count == 2) {
						paramType = tokenValue;
						if (paramType.equalsIgnoreCase("String")) {
							typeCode = 1;
							if (valueFlag && !jobValue.equals("")) {
								stringValue = jobValue;
							}

						}
						if (paramType.equalsIgnoreCase("Double")) {
							typeCode = 2;
							if (valueFlag && !jobValue.equals("")) {
								doubleValue = Long.parseLong(jobValue);
							}

						}
						if (paramType.equalsIgnoreCase("Date")) {
							typeCode = 3;
							if (valueFlag && !jobValue.equals("")) {

								SimpleDateFormat formatter1 = new SimpleDateFormat("yy-MM-dd");
								dateValue = formatter1.parse(jobValue);
							}

						}

					}
					if (count == 3) {
						processCycleRelationId = Long.parseLong(tokenValue);
					}
					if (count == 4) {
						cycleJobRelationId = Long.parseLong(tokenValue);
					}

					count = count + 1;
				}
			}

			saveParamProcessRelation(paramId, cycleJobRelationId, processCycleRelationId, typeCode, stringValue,
					doubleValue, dateValue);
		}
		long processId = Long.parseLong(request.getParameter("hiddenProcessId"));
		logger.debug("Mapping to the jobParamsNext .......");
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("noParams", hiddenInputParams);
		model.put("jobParamValue", null);
		request.setAttribute("processId", processId);
		return addInputs(request, response);
	}

	@RequestMapping(value = "/getJobsByCycleId", method = RequestMethod.GET)
	public ModelAndView getJobsByCycleId(HttpServletRequest request, HttpServletResponse response) throws Exception {
		long cycleId = Long.parseLong(request.getParameter("cycleId"));
		long processId = Long.parseLong(request.getParameter("processId"));
		boolean flag = Boolean.parseBoolean(request.getParameter("flag"));
		long processCycleRelationId = Long.parseLong(request.getParameter("processCycleRelationId"));

		List jobList = findJobListForCycle(cycleId, processCycleRelationId);
		List<List<Map>> cycleListForProcess = new ArrayList<List<Map>>();

		cycleListForProcess = findCycleListForProcess(processId, flag);

		logger.info("Mapping to the getJobsByCycleId .......");
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("cycleListForProcess", cycleListForProcess);
		model.put("jobFlag", ((Map<String, Object>) ((cycleListForProcess.get(0)).get(0))).get("flag"));
		model.put("jobList", jobList);
		model.put("processCycleRelationId", processCycleRelationId);
		model.put("processId", processId);
		return new ModelAndView("processinputDetails", "model", model);
	}

}
