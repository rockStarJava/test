/**
 * 
 */
package com.reinsurance.urs.batchweb.ursbatchweb;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.ServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.utility.CronConvertor;
import com.reinsurance.urs.batchweb.launcher.ProcessLauncher;
import com.reinsurance.urs.batchweb.launcher.ProcessRelauncher;
import com.reinsurance.urs.domain.batch.Cycle;
import com.reinsurance.urs.domain.batch.CycleExecutionHistory;
import com.reinsurance.urs.domain.batch.CycleJobRelation;
import com.reinsurance.urs.domain.batch.Job;
import com.reinsurance.urs.domain.batch.JobExecutionHistory;
import com.reinsurance.urs.domain.batch.JobParam;
import com.reinsurance.urs.domain.batch.ParamProcessRelation;
import com.reinsurance.urs.domain.batch.ProcessCycleRelation;
import com.reinsurance.urs.domain.batch.ProcessEntity;
import com.reinsurance.urs.domain.batch.ProcessExecutionHistory;
import com.reinsurance.urs.domain.batch.ProcessRelaunch;
import com.reinsurance.urs.domain.batch.ProcessSchedule;
import com.reinsurance.urs.services.batch.CycleBatchService;
import com.reinsurance.urs.services.batch.CycleExecutionHistoryService;
import com.reinsurance.urs.services.batch.CycleJobRelationService;
import com.reinsurance.urs.services.batch.JobExecutionHistoryService;
import com.reinsurance.urs.services.batch.JobParamService;
import com.reinsurance.urs.services.batch.JobService;
import com.reinsurance.urs.services.batch.ParamProcessRelationService;
import com.reinsurance.urs.services.batch.ProcessCycleRelationService;
import com.reinsurance.urs.services.batch.ProcessExecutionHistoryService;
import com.reinsurance.urs.services.batch.ProcessScheduleService;
import com.reinsurance.urs.services.batch.ProcessService;

/**
 * @author Lakshmi.Isukapally
 * 
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public abstract class BaseHomecontroller {

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	@Autowired
	@Qualifier("processExecutionHistoryService")
	ProcessExecutionHistoryService processExecutionHistoryService;

	@Autowired
	@Qualifier("cycleExecutionHistoryService")
	CycleExecutionHistoryService cycleExecutionHistoryService;

	@Autowired
	@Qualifier("jobExecutionHistoryService")
	JobExecutionHistoryService jobExecutionHistoryService;

	@Autowired
	@Qualifier("processService")
	ProcessService processService;

	@Autowired
	@Qualifier("cycleService")
	CycleBatchService cycleService;

	@Autowired
	@Qualifier("jobService")
	JobService jobService;
	
	@Autowired
	@Qualifier("jobParamService")
	JobParamService jobParamService;

	@Autowired
	@Qualifier("cycleJobRelationService")
	CycleJobRelationService cycleJobRelationService;

	@Autowired
	@Qualifier("processScheduleService")
	ProcessScheduleService processScheduleService;

	@Autowired
	@Qualifier("processCycleRelationService")
	ProcessCycleRelationService processCycleRelationService;
	@Autowired
	@Qualifier("processLauncher")
	ProcessLauncher processLauncher;

	@Autowired
	@Qualifier("processRelauncher")
	ProcessRelauncher processRelauncher;

	@Autowired
	@Qualifier("paramProcessRelationService")
	ParamProcessRelationService paramProcessRelationService;

	protected static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * this method retrieves processExectionHistory data and sets the model
	 * object
	 * 
	 * @return Model object with list
	 */

	protected List getprocessExecutionHistoryData() {
		List list_process_execution_history_data = new ArrayList();

		// Retrieve List from database
		try{
			List<ProcessExecutionHistory> processExecutionHistoryList = processExecutionHistoryService
					.findAllActiveProcessesLatestExecutions();
			Iterator<ProcessExecutionHistory> itr_process_execution_histories = processExecutionHistoryList.iterator();
			while (itr_process_execution_histories.hasNext()) {
				Map<String, Object> process_execution_history_data = new HashMap<String, Object>();
				ProcessExecutionHistory processExecutionHistory = itr_process_execution_histories.next();
				long processExecutionID = processExecutionHistory.getProcessExecutionInstanceId();
	
				// Get all the cycle executions associated with this process
				// execution
				List list_cycle_execution_history_data = getcycleExecutionHistoryData(processExecutionID);
				process_execution_history_data.put("processInstanceId", processExecutionID);
				process_execution_history_data.put("processName", processExecutionHistory.getProcess().getProcessName());
				process_execution_history_data.put("processDescription", processExecutionHistory.getProcess()
						.getProcessDescription());
				process_execution_history_data.put("end_time", processExecutionHistory.getEndTime());
				process_execution_history_data.put("status", processExecutionHistory.getStatus());
				process_execution_history_data.put("successStatus", URSBatchConstants.PROCESS_EXECUTION_SUCCESS_STATUS);
				if (processExecutionHistory.getErrorMsg() == null)
					process_execution_history_data.put("errmsg", "No Error Message");
				else
					process_execution_history_data.put("errmsg",
							StringEscapeUtils.unescapeJava(processExecutionHistory.getErrorMsg().toString()));
				process_execution_history_data.put("list_cycle_execution_history_data", list_cycle_execution_history_data);
				list_process_execution_history_data.add(process_execution_history_data);
				// }
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}

		return list_process_execution_history_data;

	}

	/**
	 * this method retrieves cycleExectionHistory data for each process
	 * execution history instance processExectionHistory data
	 * 
	 * @return
	 */

	protected List getcycleExecutionHistoryData(long processExecutionID) {
		logger.debug("started getcycleExecutionHistoryData method.");
		// UI objects
		List list_cycle_execution_history_data = new ArrayList();
		// Retrieve List from database
		try{
			List<CycleExecutionHistory> cycleExecutionHistoryList = cycleExecutionHistoryService
					.findByProcessExecutionHistoryID(processExecutionID);
			Iterator<CycleExecutionHistory> itr_cycle_execution_histories = cycleExecutionHistoryList.iterator();
			while (itr_cycle_execution_histories.hasNext()) {
				Map<String, Object> cycle_execution_history_data = new HashMap<String, Object>();
				CycleExecutionHistory cycleExecutionHistory = itr_cycle_execution_histories.next();
				long cycleExecutionID = cycleExecutionHistory.getCycleExecutionInstanceId();
				List list_job_execution_history_data_job = getjobExecutionHistoryData(cycleExecutionID);
				cycle_execution_history_data.put("cycleInstanceId", cycleExecutionID);
				cycle_execution_history_data.put("cycleName", cycleExecutionHistory.getCycle().getCycleName());
				cycle_execution_history_data
				.put("cycleDescription", cycleExecutionHistory.getCycle().getCycleDescription());
				cycle_execution_history_data.put("end_time", cycleExecutionHistory.getEndTime());
				cycle_execution_history_data.put("status", cycleExecutionHistory.getStatus());
				cycle_execution_history_data.put("successStatus", URSBatchConstants.CYCLE_EXECUTION_SUCCESS_STATUS);
				if (cycleExecutionHistory.getErrorMsg() == null)
					cycle_execution_history_data.put("errmsg", "No Error Message");
				else
					cycle_execution_history_data.put("errmsg",
							StringEscapeUtils.unescapeJava(cycleExecutionHistory.getErrorMsg().toString()));
				cycle_execution_history_data
				.put("list_job_execution_history_data_job", list_job_execution_history_data_job);
				list_cycle_execution_history_data.add(cycle_execution_history_data);
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}

		return list_cycle_execution_history_data;

	}

	/**
	 * this method retrieves jobExectionHistory data for individual
	 * cycleExectionHistory data
	 * 
	 * @return
	 */
	private List getjobExecutionHistoryData(long cycleExecutionID) {
		logger.debug("started getjobExecutionHistoryData method");
		// UI objects
		List list_job_execution_history_data = new ArrayList();
		
		try{
			List<JobExecutionHistory> jobExecutionHistoryList = jobExecutionHistoryService
					.findByCycleExecutionHistoryID(cycleExecutionID);
			Iterator<JobExecutionHistory> itr_job_execution_histories = jobExecutionHistoryList.iterator();
			while (itr_job_execution_histories.hasNext()) {
				Map<String, Object> job_execution_history_data = new HashMap<String, Object>();
				JobExecutionHistory jobExecutionHistory = itr_job_execution_histories.next();
				long jobExecutionID = jobExecutionHistory.getJobExecutionInstanceId();
				job_execution_history_data.put("jobInstanceId", jobExecutionID);
				Job faliedjob= jobService.findJobinformationByJobId(jobExecutionHistory.getJobId());
				job_execution_history_data.put("jobName", faliedjob.getBusinessName());
				job_execution_history_data.put("jobDescription", faliedjob.getJobDescription());
				job_execution_history_data.put("end_time", jobExecutionHistory.getEndTime());
				job_execution_history_data.put("status", jobExecutionHistory.getStatus());
				job_execution_history_data.put("successStatus", URSBatchConstants.JOB_EXECUTION_SUCCESS_STATUS);
				if (jobExecutionHistory.getErrorMsg() == null)
					job_execution_history_data.put("errmsg", "No Error Message");
				else
					job_execution_history_data.put("errmsg",
							StringEscapeUtils.unescapeJava(jobExecutionHistory.getErrorMsg().toString()));
				list_job_execution_history_data.add(job_execution_history_data);
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}

		return list_job_execution_history_data;

	}

	/**
	 * This methods gets all the cycles and jobs associated with those cycles.
	 * 
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> loadCycleDetails() throws Exception {
		logger.debug(" started batchMonitorCycleAction method");
		List cycleDataList = new ArrayList();
		List jobDataList = new ArrayList();
		Map<String, Object> cycle_data = null;
		List<Job> jobsList = new ArrayList<Job>();
		List<Cycle> cyclesList = new ArrayList<Cycle>();

		cyclesList = cycleService.findCycleslist();
		jobsList = jobService.findallTheJobs();

		Iterator<Cycle> itr_cycle = cyclesList.iterator();
		while (itr_cycle.hasNext()) {
			Cycle cycle = itr_cycle.next();
			String jobList = "";
			String processList = "";
			cycle_data = new HashMap<String, Object>();
			cycle_data.put("cycle_id", cycle.getCycleId());
			cycle_data.put("cycle_name", cycle.getCycleName());
			cycle_data.put("cycle_description", cycle.getCycleDescription());
			cycle_data.put("last_updated", cycle.getLastUpdated());
			Iterator<ProcessCycleRelation> itr_process_cycle_relation = cycle.getProcessCycleRelations().iterator();
			while (itr_process_cycle_relation.hasNext()) {
				ProcessCycleRelation process_cycle_relation = itr_process_cycle_relation.next();
				// create a comma seperated list
				if (processService.findByProcessId(process_cycle_relation.getProcessId()).getDeleted() == 0) {
					processList = processList + ","
							+ processService.findByProcessId(process_cycle_relation.getProcessId()).getProcessName();
				}

			}
			processList = processList.replaceFirst(",", "");
			Iterator<CycleJobRelation> itr_cycle_job_relation = cycleJobRelationService.findByCycleId(
					cycle.getCycleId()).iterator();
			while (itr_cycle_job_relation.hasNext()) {
				CycleJobRelation cycle_job_relation = itr_cycle_job_relation.next();
				jobList = jobList + ","
						+ jobService.findJobinformationByJobId(cycle_job_relation.getJobId()).getBusinessName();
			}

			jobList = jobList.replaceFirst(",", "");
			cycle_data.put("usedInProcess", processList);
			cycle_data.put("usedInJobs", jobList);
			cycleDataList.add(cycle_data);
		}

		Iterator<Job> itr_job = jobsList.iterator();
		while (itr_job.hasNext()) {
			Job job = itr_job.next();
			Map<String, Object> job_data = new HashMap<String, Object>();
			job_data.put("jobName", job.getJobName());
			jobDataList.add(job_data);
		}
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("list_cycle_data", cycleDataList);
		model.put("list_job_data", jobDataList);
		return model;
	}

	/**
	 * This method add cycles
	 * 
	 * @param request
	 * @throws Exception
	 */
	public long addCycle(ServletRequest request) throws Exception {
		logger.debug("adding a new cycle or editing the existing cycle");
		String Cyclemessage = message_source.getMessage("cycleDetails.insertSuccessMessage", null, "Default", null);
		// load all the request params
		String cycleName = request.getParameter("cyclename");
		if (cycleName != null)
			cycleName = cycleName.trim();
		String cycleDescription = request.getParameter("cycledescription");
		String cycleIdParam = request.getParameter("cycleid");
		String job = request.getParameter("cyclejob");
		String deleteJob = request.getParameter("deleteJob");
		int cycleExeOrder = 1;
		long cycle_id = 0;
		StringTokenizer jobTokens = null;
		if (job != null && !job.trim().isEmpty())
			jobTokens = new StringTokenizer(job, ",");

		StringTokenizer deletejobTokens = null;
		if (deleteJob != null && !deleteJob.trim().isEmpty())
			deletejobTokens = new StringTokenizer(deleteJob, ",");

		// Create cycleJob relation objects
		CycleJobRelation cycJobRel = null;
		Cycle cycle = null;

		// Save cycle object
		if (cycleIdParam != null && !cycleIdParam.trim().isEmpty()) {
			cycle = cycleService.findCycleInformationByCycleId(Long.parseLong(cycleIdParam));
		} else {
			cycle = new Cycle();
			cycle.setCreatedDate(new Date());
		}
		cycle.setCycleCode(cycleName);
		cycle.setLastUpdated(new Date());
		cycle.setCycleName(cycleName);
		cycle.setCycleDescription(cycleDescription);
		logger.debug("Saving cycle : " + cycle.toString());
		cycle_id = cycleService.saveCycleInformation(cycle);
		if (cycle_id == URSBatchConstants.CYCLE_INSERT_FAILURE) {
			cycle_id = URSBatchConstants.CYCLE_INSERT_FAILURE;
			Cyclemessage = message_source.getMessage("cycleDetails.insertFailureMessage", null, "Default", null);
		}
		if (cycleIdParam != null && !cycleIdParam.trim().isEmpty()) {
			// Save cyclejob relation object
			List<CycleJobRelation> lst_cycle_job_rel = cycleJobRelationService.findByCycleId(cycle_id);

			// delete all the existing relationships

			if (jobTokens != null) {
				String token = "";
				String jobName = "";
				String executionOrder = "";
				while (jobTokens.hasMoreTokens()) {
					token = jobTokens.nextToken();
					jobName = token.split("-")[0];
					if (token.split("-").length == 2)
						executionOrder = token.split("-")[1];
					else
						executionOrder = "0";
					if (jobName != null && !jobName.trim().isEmpty() && !jobName.equals("undefined")) {
						Job job_for_cycle = jobService.findJobinformationByName(jobName);
						if (job_for_cycle != null )
						{	int count = 0;
							int exeOrder = Integer.parseInt(executionOrder);
							
							Iterator<CycleJobRelation> itr_lst_cycle_job_rel = lst_cycle_job_rel.iterator();

							while (itr_lst_cycle_job_rel.hasNext()) {
								cycJobRel = itr_lst_cycle_job_rel.next();
								if ((job_for_cycle.getId() == cycJobRel.getJobId())
										&& (exeOrder == cycJobRel.getCycleExecutionOrder())) {
									count++;
									break;
								}

							}
							if (count > 0) {

							} else {
								if (exeOrder == 0) {
									cycJobRel = new CycleJobRelation();
								}
							}
							if (deletejobTokens != null) {
								String deltoken = "";
								String delete_jobName = "";
								String delexeOrder = "";
								while (deletejobTokens.hasMoreTokens()) {
									deltoken = deletejobTokens.nextToken();
									delete_jobName = deltoken.split("-")[0];
									if (deltoken.split("-").length == 2)
										delexeOrder = deltoken.split("-")[1];
									else
										delexeOrder = "0";
									if (delete_jobName != null && !delete_jobName.trim().isEmpty()
											&& !delete_jobName.equals("undefined")) {
										Job del_job = jobService.findJobinformationByName(delete_jobName);
										if (del_job != null ) {
											int delOrder = Integer.parseInt(delexeOrder);
											Iterator<CycleJobRelation> itrcycle_relation = lst_cycle_job_rel.iterator();
											CycleJobRelation cycleJobRelation = null;
											while (itrcycle_relation.hasNext()) {
												cycleJobRelation = itrcycle_relation.next();
												if (del_job.getId() == cycleJobRelation.getJobId()
														&& (delOrder == cycleJobRelation.getCycleExecutionOrder())) {
													cycleJobRelationService.deleteCycleJobRelation(cycleJobRelation);
												}
											}
										}
									}
								}

							}
							cycJobRel.setCycleId(cycle_id);
							cycJobRel.setJobId(job_for_cycle.getId());
							cycJobRel.setCycleExecutionOrder(cycleExeOrder);
							cycJobRel.setConditionFlag(URSBatchConstants.CYCLE_JOB_DEFAULT_CONDITION);
							cycleExeOrder++;
							cycleJobRelationService.saveCycleJobRelation(cycJobRel);
						} //
					}

				}

			}
		} else {
			// add cycle job relationships
			if (jobTokens != null) {
				String token = "";
				String jobName = "";
				while (jobTokens.hasMoreTokens()) {
					cycJobRel = new CycleJobRelation();
					token = jobTokens.nextToken();
					jobName = token.split("-")[0];
					if (jobName != null && !jobName.trim().isEmpty() && !jobName.equals("undefined")) {
						Job job_for_cycle = jobService.findJobinformationByName(jobName);
						if (job_for_cycle != null ) {
                          	cycJobRel.setCycleId(cycle_id);
							cycJobRel.setJobId(job_for_cycle.getId());
							cycJobRel.setCycleExecutionOrder(cycleExeOrder);
							cycJobRel.setConditionFlag(URSBatchConstants.CYCLE_JOB_DEFAULT_CONDITION);
							cycleJobRelationService.saveCycleJobRelation(cycJobRel);
							cycleExeOrder++;
						}
					}
				}
			}
		}
		request.setAttribute("Cyclemessage", Cyclemessage);
		return cycle_id;
	}

	/**
	 * Get all the jobs defined
	 * 
	 * @return
	 * @throws Exception
	 */
	public List getJobs() throws Exception {

		List jobList = new ArrayList();
		List<Job> list_job = new ArrayList<Job>();
		list_job = jobService.findallTheJobs();
		Iterator<Job> itr_job = list_job.iterator();
		while (itr_job.hasNext()) {
			Job job = itr_job.next();
			Map<String, String> jobName = new HashMap<String, String>();
			jobName.put("jobbusinessName", job.getBusinessName());
			jobName.put("jobName", job.getJobName());
			jobList.add(jobName);
		}
		return jobList;
	}

	/**
	 * This method returns data of a perticular cycle for edit.
	 * 
	 * @param request
	 * @return
	 */
	public Map<String, Object> editCycleParameters(ServletRequest request) {
		List cycleDataList = new ArrayList();
		List jobDataList = new ArrayList();
		Cycle cycle = null;
		Map<String, Object> data = new HashMap<String, Object>();
		String jobList = "";
		Map<String, Object> cycleData = new HashMap<String, Object>();
		String cycleId = request.getParameter("cId");
		
		try{
			cycle = cycleService.findCycleInformationByCycleId(Long.parseLong(cycleId));
			String cycleName = cycle.getCycleName();
			String cycleDescription = cycle.getCycleDescription();
			Iterator<CycleJobRelation> itr_cycle_job_relation = cycleJobRelationService.findByCycleId(cycle.getCycleId())
					.iterator();
			while (itr_cycle_job_relation.hasNext()) {
				CycleJobRelation cycle_job_relation = itr_cycle_job_relation.next();
				jobList = jobList + ","
						+ jobService.findJobinformationByJobId(cycle_job_relation.getJobId()).getBusinessName() + "-"
						+ cycle_job_relation.getCycleExecutionOrder();
			}
			String cycleJobs = jobList.replaceFirst(",", "");
			logger.debug("in editCycleParameters cycleJobsare :::::::::::::::" + cycleJobs);
			Map<String, String> jobName = null;
			String tokenjob = "";
			String jobBusinessname = "";
			String executionOrder = "";
			if (cycleJobs != null) {
				StringTokenizer st = new StringTokenizer(cycleJobs, ",");
				while (st.hasMoreTokens()) {
					tokenjob = st.nextToken();
					jobName = new HashMap<String, String>();
					jobBusinessname = tokenjob.split("-")[0];
					executionOrder = tokenjob.split("-")[1];
					jobName.put("cycleJobName", jobBusinessname);
					jobName.put("executionOrder", executionOrder);
					jobDataList.add(jobName);
				}
			}
			cycleData.put("cycleId", cycleId);
			cycleData.put("cycle_name", cycleName);
			cycleData.put("cycle_description", cycleDescription);
			cycleDataList.add(cycleData);
			data.put("cycleData", cycleDataList);
			data.put("jobDataList", jobDataList);
			data.put("cycleId", cycleId);
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}
		return data;
	}

	/**
	 * This lists all the active /inactive /draft process for processDeatils
	 * page
	 * 
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> listAllProcessDetails(ServletRequest request) throws Exception {
		String msgForDelProcess = "";
		List list_process_data = new ArrayList();
		List list_cycle_data_for_process = new ArrayList();

		Map<String, Object> process_data = null;
		List<Cycle> cycle_list = new ArrayList<Cycle>();
		List<ProcessEntity> process_list = new ArrayList<ProcessEntity>();

		cycle_list = cycleService.findCycleslist();
		process_list = processService.findAllProcesss();

		Iterator<ProcessEntity> itr_process = process_list.iterator();
		while (itr_process.hasNext()) {
			ProcessEntity process = (ProcessEntity) itr_process.next();
			if (process.getDeleted() != URSBatchConstants.PROCESS_DELETED) {
				String readableSchedule = "";
				String cycleList = "";
				process_data = new HashMap<String, Object>();
				process_data.put("processId", process.getProcessId());
				process_data.put("processName", process.getProcessName());
				process_data.put("processDescription", process.getProcessDescription());
				process_data.put("lastModified", process.getLastUpdated());
				readableSchedule = CronConvertor.humanReadableForm(process.getProcessSchedule().toString());
				process_data.put("cronExpression", readableSchedule);
				process_data.put("status", process.getProcessStatus());
				process_data.put("processActive", URSBatchConstants.PROCESS_STATE_ACTIVE_CD);
				process_data.put("processInactive", URSBatchConstants.PROCESS_STATE_INACTIVE_CD);
				process_data.put("processDraft", URSBatchConstants.PROCESS_STATE_DRAFT_CD);
				process_data.put("showActive", URSBatchConstants.PROCESS_STATE_ACTIVE);
				process_data.put("showInactive", URSBatchConstants.PROCESS_STATE_INACTIVE);
				process_data.put("showDraft", URSBatchConstants.PROCESS_STATE_DRAFT);

				Iterator<ProcessCycleRelation> itr_process_cycle_relation = processCycleRelationService
						.findprocessCycleRelationsByProcessId(process.getProcessId()).iterator();

				while (itr_process_cycle_relation.hasNext()) {
					ProcessCycleRelation process_cycle_relation = itr_process_cycle_relation.next();

					cycleList = cycleList
							+ ","
							+ cycleService.findCycleInformationByCycleId(process_cycle_relation.getCycleId())
							.getCycleName() + "-" + process_cycle_relation.getProcessExecutionOrder();
				}

				cycleList = cycleList.replaceFirst(",", "");
				process_data.put("usedInCycle", cycleList);
				list_process_data.add(process_data);
			}
		}

		Iterator<Cycle> itr_cycle = cycle_list.iterator();
		while (itr_cycle.hasNext()) {
			Cycle cycle = itr_cycle.next();
			Map<String, Object> cycle_data_for_process = new HashMap<String, Object>();
			cycle_data_for_process.put("cycleName", cycle.getCycleName());

			list_cycle_data_for_process.add(cycle_data_for_process);
		}

		Map<String, Object> model = new HashMap<String, Object>();
		model.put("list_process_data", list_process_data);
		model.put("list_cycle_data_for_process", list_cycle_data_for_process);
		if (request.getAttribute("msgForDeleteProcess") != null
				&& ! (request.getAttribute("msgForDeleteProcess")).toString().trim().isEmpty()) {
			msgForDelProcess = request.getAttribute("msgForDelete ProcessEntity").toString();
			model.put("msgForAddDeleteProcess", msgForDelProcess);
		}

		return model;
	}

	/**
	 * Adding a new or editing a process
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public ProcessEntity addProcess(ServletRequest request) throws Exception {
		String msgStatus = "";
		String process_id_param = "";
		String processName = "";
		String processDescription = "";
		String dayOfWeek = "";
		String month = "";
		String day_of_month = "";
		int processExeOrder = 1;
		int hrs = 0;
		int mins = 0;
		int secs = 0;
		String schedulesec = "";
		String everyDay = "";
		String days = "";
		String sunday = "";
		String monday = "";
		String tuesday = "";
		String wednesday = "";
		String thursday = "";
		String friday = "";
		String saturday = "";
		String everymonth = "";
		String month_category = "";
		String day_of_week = "";
		String category_First_Last = "";
		schedulesec = request.getParameter("schedulesec");
		everyDay = request.getParameter("everyday");
		days = request.getParameter("days");
		sunday = request.getParameter("sun");
		monday = request.getParameter("mon");
		tuesday = request.getParameter("tue");
		wednesday = request.getParameter("wed");
		thursday = request.getParameter("thu");
		friday = request.getParameter("fri");
		saturday = request.getParameter("sat");
		everymonth = request.getParameter("everymonth1");
		month = request.getParameter("month1");
		day_of_month = request.getParameter("day_of_month");
		month_category = request.getParameter("month2");
		day_of_week = request.getParameter("day_of_week");
		category_First_Last = request.getParameter("day_of_week_category");

		process_id_param = request.getParameter("processid");

		if (request.getParameter("Hr") != null && !request.getParameter("Hr").isEmpty())
			hrs = Integer.parseInt(request.getParameter("Hr"));
		if (request.getParameter("Min") != null && !request.getParameter("Min").isEmpty())
			mins = Integer.parseInt(request.getParameter("Min"));
		if (request.getParameter("Sec") != null && !request.getParameter("Sec").isEmpty())
			secs = Integer.parseInt(request.getParameter("Sec"));

		ProcessSchedule process_schedule = null;
		if (process_id_param == null || process_id_param.equals("")) {
			process_schedule = new ProcessSchedule();
		} else {
			process_schedule = processService.findByProcessId(Long.parseLong(process_id_param)).getProcessSchedule();
		}
		if ((process_id_param == null || process_id_param.equals("")) || (hrs != 00 || mins != 00 || secs != 00)) {
			process_schedule.setHours(hrs);
			process_schedule.setMinutes(mins);
			process_schedule.setSeconds(secs);
			if (schedulesec != null) {
				if (schedulesec.equals("d")) {
					process_schedule.setMonth("*");
					process_schedule.setDayOfMonth("?"); // Changed * to ?
					if (everyDay != null) {
						if (everyDay.equals("EVD")) {
							if (days.equals("1")) {
								process_schedule.setDayOfWeek("*");
							}
							if (days.equals("2")) {
								process_schedule.setDayOfWeek("2#2");
							}
							if (days.equals("3")) {
								process_schedule.setDayOfWeek("2#3");
							}
							if (days.equals("4")) {
								process_schedule.setDayOfWeek("2#4");
							}
						}
						if (everyDay.equals("EVWD")) {
							process_schedule.setDayOfWeek("2-6");
						}

					}
				}
			}

			if (schedulesec != null) {
				if (schedulesec.equals("w")) {

					if (sunday != null) {
						if (sunday.equals("sun")) {
							dayOfWeek = dayOfWeek + "," + 1;
						}
					}
					if (monday != null) {
						if (monday.equals("mon")) {
							dayOfWeek = dayOfWeek + "," + 2;
						}
					}
					if (tuesday != null) {
						if (tuesday.equals("tue")) {
							dayOfWeek = dayOfWeek + "," + 3;
						}
					}
					if (wednesday != null) {
						if (wednesday.equals("wed")) {
							dayOfWeek = dayOfWeek + "," + 4;
						}
					}
					if (thursday != null) {
						if (thursday.equals("thu")) {
							dayOfWeek = dayOfWeek + "," + 5;
						}
					}
					if (friday != null) {
						if (friday.equals("fri")) {
							dayOfWeek = dayOfWeek + "," + 6;
						}
					}
					if (saturday != null) {
						if (saturday.equals("sat")) {
							dayOfWeek = dayOfWeek + "," + 7;
						}
					}
					dayOfWeek = dayOfWeek.replaceFirst(",", "");
					process_schedule.setDayOfWeek(dayOfWeek);
					process_schedule.setMonth("*");
					process_schedule.setDayOfMonth("?"); // Changed * to ?
				}
			}
			if (schedulesec != null) {
				if (schedulesec.equals("m")) {

					if (everymonth != null) {
						if (everymonth.equals("EVM1")) {
							process_schedule.setMonth(month);
							process_schedule.setDayOfMonth(day_of_month);
							process_schedule.setDayOfWeek("?"); // Changed * to
							// ?
						}
						if (everymonth.equals("EVM2")) {
							process_schedule.setMonth(month_category);
							process_schedule.setDayOfMonth("?"); // Changed * to
							// ?
							if (category_First_Last.equals("first")) {
								dayOfWeek = day_of_week + "#" + 1;
								process_schedule.setDayOfWeek(dayOfWeek);
							}
							if (category_First_Last.equals("second")) {
								dayOfWeek = day_of_week + "#" + 2;
								process_schedule.setDayOfWeek(dayOfWeek);
							}
							if (category_First_Last.equals("third")) {
								dayOfWeek = day_of_week + "#" + 3;
								process_schedule.setDayOfWeek(dayOfWeek);
							}
							if (category_First_Last.equals("fourth")) {
								dayOfWeek = day_of_week + "#" + 4;
								process_schedule.setDayOfWeek(dayOfWeek);
							}
							if (category_First_Last.equals("last")) {
								dayOfWeek = day_of_week + "L";
								process_schedule.setDayOfWeek(dayOfWeek);
							}

						}
					}
				}
			}

			processScheduleService.saveProcessSchedule(process_schedule);
		}

		long process_id = 0;
		String cyclesCSVList = "";
		String deleteCycleList = "";
		StringTokenizer CyclesList;
		String activeStatus = "";
		int processScheduleStatus = 0;
		ProcessCycleRelation proCycRel = null;
		processName = request.getParameter("processname");
		processDescription = request.getParameter("processdescription");
		cyclesCSVList = request.getParameter("processcycle");
		deleteCycleList = request.getParameter("deleteCycle");
		activeStatus = request.getParameter("chkActive");
		if (process_id_param != null && !process_id_param.trim().isEmpty()) {
			if (activeStatus.equals("A")) {
				processScheduleStatus = 1;
			}
			if (activeStatus.equals("I")) {
				if (processService.findByProcessId(Long.parseLong(process_id_param)).getProcessStatus() == URSBatchConstants.PROCESS_STATE_DRAFT_CD)
					processScheduleStatus = 0;
				if (processService.findByProcessId(Long.parseLong(process_id_param)).getProcessStatus() == URSBatchConstants.PROCESS_STATE_ACTIVE_CD)
					processScheduleStatus = 2;
				if (processService.findByProcessId(Long.parseLong(process_id_param)).getProcessStatus() == URSBatchConstants.PROCESS_STATE_INACTIVE_CD)
					processScheduleStatus = 2;
			}
		} else {
			if (activeStatus.equals("A")) {
				processScheduleStatus = 1;
			}
			if (activeStatus.equals("I")) {
				processScheduleStatus = 0;
			}
		}
		ProcessEntity process = null;
		CyclesList = new StringTokenizer(cyclesCSVList, ",");
		// Tokenize the delete cycle
		StringTokenizer deletecycleTokens = null;
		if (deleteCycleList != null && !deleteCycleList.trim().isEmpty())
			deletecycleTokens = new StringTokenizer(deleteCycleList, ",");

		if (process_id_param != null && !process_id_param.trim().isEmpty()) {
			process = processService.findByProcessId(Long.parseLong(process_id_param));
		} else {
			process = new ProcessEntity();
		}
		process.setProcessName(processName);
		process.setProcessDescription(processDescription);

		process.setProcessName(processName);
		process.setProcessDescription(processDescription);

		process.setProcessStatus(processScheduleStatus);
		process.setProcessSchedule(process_schedule);
		process.setCreatedDate(new Timestamp((new Date().getTime())));
		process.setLastUpdated(new Timestamp((new Date().getTime())));
		process_id = processService.saveProcess(process);
		if (process_id != 0) {
			msgStatus = (message_source.getMessage("process.addMessageSuccess", null, "Default", null));
		} else {
			msgStatus = (message_source.getMessage("process.addMessageFail", null, "Default", null));
		}
		// }
		request.setAttribute("msgForAddProcess", msgStatus);

		if (process_id_param != null && !process_id_param.trim().isEmpty()) {
			List<ProcessCycleRelation> lst_process_cyc_rel = processCycleRelationService
					.findprocessCycleRelationsByProcessId(process_id);

			String token = "";
			String cycleName = "";
			String executionOrder = "";
			while (CyclesList.hasMoreTokens()) {
				token = CyclesList.nextToken();
				cycleName = token.split("-")[0];
				if (token.split("-").length == 2)
					executionOrder = token.split("-")[1];
				else
					executionOrder = "0";
				logger.debug("cycleName--" + cycleName);
				if (cycleName != null && !cycleName.trim().isEmpty() && !cycleName.equals("undefined")) {
					List<Cycle> cycleList = cycleService.findCycleInformationByCycleName(cycleName);
					if (cycleList != null) {
						int count = 0;
						int exeOrder = Integer.parseInt(executionOrder);
						Cycle cycleAdded = cycleList.get(0);
						Iterator<ProcessCycleRelation> itr_lst_process_cycle_rel = lst_process_cyc_rel.iterator();
						while (itr_lst_process_cycle_rel.hasNext()) {
							proCycRel = itr_lst_process_cycle_rel.next();
							if ((cycleAdded.getCycleId() == proCycRel.getCycleId())
									&& (exeOrder == proCycRel.getProcessExecutionOrder())) {
								count++;
								break;
							}
						}
						if (count > 0) {

						} else {
							if (exeOrder == 0) {
								proCycRel = new ProcessCycleRelation();
							}
						}
						if (deletecycleTokens != null) {
							String deltoken = "";
							String delete_cycleName = "";
							String delexeOrder = "";
							while (deletecycleTokens.hasMoreTokens()) {
								deltoken = deletecycleTokens.nextToken();
								delete_cycleName = deltoken.split("-")[0];
								if (deltoken.split("-").length == 2)
									delexeOrder = deltoken.split("-")[1];
								else
									delexeOrder = "0";
								logger.debug("delete cycleName--" + delete_cycleName);
								if (delete_cycleName != null && !delete_cycleName.trim().isEmpty()
										&& !delete_cycleName.equals("undefined")) {
									List<Cycle> deletecycleList = cycleService
											.findCycleInformationByCycleName(delete_cycleName);
									if (deletecycleList != null) {
										int delOrder = Integer.parseInt(delexeOrder);
										Cycle del_cycle = deletecycleList.get(0);
										ProcessCycleRelation processCycleRelation = null;
										Iterator<ProcessCycleRelation> itr_Listprocess_cycle_rel = lst_process_cyc_rel
												.iterator();
										while (itr_Listprocess_cycle_rel.hasNext()) {
											// START----Adding below code to
											// delete Param process relation in
											// order to avoid error
											// DELETE statement conflicted with
											// the REFERENCE constraint
											// "FK2_PARAM_PROCESS_RELATION
											// Added on 27 mar 2014
											processCycleRelation = itr_Listprocess_cycle_rel.next();
											if (del_cycle.getCycleId() == processCycleRelation.getCycleId()
													&& (delOrder == processCycleRelation.getProcessExecutionOrder())) {
												List<ParamProcessRelation> listparamProcessRelation = paramProcessRelationService
														.findParamProcessRelationByProcessCycleRelationId(processCycleRelation
																.getProcessCycleRelationId());
												Iterator<ParamProcessRelation> parampIterator = listparamProcessRelation
														.iterator();
												while (parampIterator.hasNext()) {
													ParamProcessRelation paramProcessRelation = parampIterator.next();
													paramProcessRelationService
													.deleteParamProcessRelation(paramProcessRelation);
												}// -----END

												processCycleRelationService
												.deleteProcessCycleRelation(processCycleRelation);
											}
										}
									}

								}
							}
						}
						proCycRel.setProcessId(process.getProcessId());
						proCycRel.setCycleId(cycleAdded.getCycleId());
						proCycRel.setProcessExecutionOrder(processExeOrder);
						proCycRel.setProcessCondition(URSBatchConstants.PROCESS_CYCLE_DEFAULT_CONDITION);
						processCycleRelationService.saveProcessCycleRelation(proCycRel);
						processExeOrder++;
					}
				}

			}

		} else {
			String token = "";
			String cycleName = "";
			while (CyclesList.hasMoreTokens()) {
				token = CyclesList.nextToken();
				cycleName = token.split("-")[0];
				logger.debug("cycleName--" + cycleName);
				if (cycleName != null && !cycleName.trim().isEmpty() && !cycleName.equals("undefined")) {
					List<Cycle> listCycles = cycleService.findCycleInformationByCycleName(cycleName);
					if (listCycles != null) {
						Cycle cycleAdded = listCycles.get(0);
						proCycRel = new ProcessCycleRelation();
						proCycRel.setProcessId(process.getProcessId());
						proCycRel.setCycleId(cycleAdded.getCycleId());
						proCycRel.setProcessExecutionOrder(processExeOrder);
						proCycRel.setProcessCondition(URSBatchConstants.PROCESS_CYCLE_DEFAULT_CONDITION);
						processCycleRelationService.saveProcessCycleRelation(proCycRel);
						processExeOrder++;
					}
				}
			}
		}
		return process;
	}

	/**
	 * This method return all the cycles
	 * 
	 * @return
	 * @throws Exception
	 */
	public List getCycles() throws Exception {

		List cycleList = new ArrayList();

		List<Cycle> list_cycle = new ArrayList<Cycle>();
		list_cycle = cycleService.findCycleslist();

		Iterator<Cycle> itr_cycle = list_cycle.iterator();
		while (itr_cycle.hasNext()) {
			Cycle cycle = itr_cycle.next();
			Map<String, String> cycleName = new HashMap<String, String>();
			cycleName.put("cycleName", cycle.getCycleName());
			cycleList.add(cycleName);
		}
		return cycleList;
	}

	/**
	 * This method returns data of a perticular process for edit.
	 * 
	 * @param request
	 * @return
	 */
	public Map<String, Object> editProcessParameters(ServletRequest request) {
		List processDataList = new ArrayList();
		List cycleDataList = new ArrayList();
		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, Object> processData = new HashMap<String, Object>();
		String processId = request.getParameter("pId");
		String status = request.getParameter("pStatus");
		
		try{
			if (processId != null) {
				ProcessEntity process = processService.findByProcessId(Long.parseLong(processId));
				String processCycles = request.getParameter("pCycles");
				String processEdit = request.getParameter("pEdit");
	
				Map<String, String> cycleName = null;
				if (processCycles != null) {
					String CycleToken = "";
					String processCycleName = "";
					String executionOrder = "";
					StringTokenizer st = new StringTokenizer(processCycles, ",");
					while (st.hasMoreTokens()) {
						CycleToken = st.nextToken();
						cycleName = new HashMap<String, String>();
						processCycleName = CycleToken.split("-")[0];
						executionOrder = CycleToken.split("-")[1];
						cycleName.put("processCycleName", processCycleName);
						cycleName.put("executionOrder", executionOrder);
						cycleDataList.add(cycleName);
					}
				} else {
					if (processId != null && !processId.trim().isEmpty()) {
						List<ProcessCycleRelation> lst_process_cyc_rel = processCycleRelationService
								.findprocessCycleRelationsByProcessId(Long.parseLong(processId));
						Iterator<ProcessCycleRelation> itr_lst_process_cyc_rel = lst_process_cyc_rel.iterator();
						while (itr_lst_process_cyc_rel.hasNext()) {
							ProcessCycleRelation proc_cyc_rel = itr_lst_process_cyc_rel.next();
							Cycle cycle = cycleService.findCycleInformationByCycleId(proc_cyc_rel.getCycleId());
							cycleName = new HashMap<String, String>();
							cycleName.put("processCycleName", cycle.getCycleName());
							cycleDataList.add(cycleName);
						}
					}
				}
	
				processData.put("processId", process.getProcessId());
				processData.put("processDescription", process.getProcessDescription());
				processData.put("processName", process.getProcessName());
				processData.put("cron", CronConvertor.humanReadableForm(process.getProcessSchedule().toString()));
				processData.put("processEdit", processEdit);
				processData.put("status", process.getProcessStatus());
			}
			processDataList.add(processData);
	
			data.put("processData", processDataList);
			data.put("cycleDataList", cycleDataList);
			data.put("processStatus", status);
			data.put("processId", processId);
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}

		return data;
	}

	/**
	 * Returns error message for the processexecution instance id passed
	 * 
	 * @param request
	 * @return
	 */
	public String getProcessInstaceError(ServletRequest request) {
		String processErrorMessage = "";
		String executionId = request.getParameter("processExecutionInstanceId");
		
		try{
			if (executionId != null) {
				long processExecutionInstanceID = Long.parseLong(executionId);
				ProcessExecutionHistory processHistory = processExecutionHistoryService
						.findByProcessExecutionHistoryInstanceID(processExecutionInstanceID);
	
				if (processHistory != null && processHistory.getErrorMsg() != null) {
					processErrorMessage = processHistory.getErrorMsg().toString();
				}
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}

		return processErrorMessage;
	}

	/**
	 * returns error message for passed cycle execution instance id
	 * 
	 * @param request
	 * @return
	 */
	String getCycleInstaceError(ServletRequest request) {
		String cycleErrorMessage = "";
		String executionId = request.getParameter("cycleExecutionInstanceId");
		
		try{
			if (executionId != null) {
				long cycleExecutionId = Long.parseLong(executionId);
	
				CycleExecutionHistory cycleHistory = cycleExecutionHistoryService
						.findByCyclesExecutionHistoryID(cycleExecutionId);
				if (cycleHistory != null && cycleHistory.getErrorMsg() != null) {
					cycleErrorMessage = cycleHistory.getErrorMsg().toString();
				}
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}
		return cycleErrorMessage;
	}

	/**
	 * returns error message for passed job execution instance id
	 * 
	 * @param request
	 * @return
	 */
	public String getJobInstaceError(ServletRequest request) {
		String jobErrorMessage = "";
		String executionId = request.getParameter("jobExecutionInstanceId");
		try{
			if (executionId != null) {
				long jobExecutionId = Long.parseLong(request.getParameter("jobExecutionInstanceId"));
	
				JobExecutionHistory jobHistory = jobExecutionHistoryService.findByJobExecutionHistoryID(jobExecutionId);
				if (jobHistory != null && jobHistory.getErrorMsg() != null)
					jobErrorMessage = jobHistory.getErrorMsg().toString();
			}
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}
		return jobErrorMessage;
	}

	/**
	 * returns all the process in the databse
	 * 
	 * @return
	 */
	public List<ProcessEntity> getAllProcessList() throws Exception {
		return processService.findAllProcesss();
	}

	/**
	 * returns all the cycles in the database
	 * 
	 * @return
	 */
	public List<Cycle> getAllCycleList() throws Exception {
		return cycleService.findCycleslist();
	}

	/**
	 * executes selected process
	 * 
	 * @param process
	 * @return Status execution of the process
	 */
	public int lunchProcess(ProcessEntity process) {

		return processLauncher.launchProcess(process);
	}

	/**
	 * relaunches the process
	 * 
	 * @param restsrtOptions
	 *            : option to be selected
	 * @param processID
	 *            : process ID
	 * @param processExecutionID
	 *            : execution instance to be restarted
	 * @param cycleSelected
	 *            : from where restart should start
	 * @param Jobselected
	 *            : from which job restart should be started
	 */
	public void relunchProcess(String restsrtOptions, long processID, long processExecutionID, long cycleSelected,
			long Jobselected) throws Exception{
		// long cycleJobRelationId =
		// cycleJobRelationService.findByjobId(Jobselected);
		long cycleJobRelationId = 0;
		long processCycleRelationId = 0;
		List<CycleJobRelation> cycleJobRelationList = null;
		List<ProcessCycleRelation> processcycleRelationList = null;
		cycleJobRelationList = cycleJobRelationService.findByjobId(Jobselected);
		Iterator<CycleJobRelation> itr_cycle_job_relation = cycleJobRelationList.iterator();
		while (itr_cycle_job_relation.hasNext()) {
			CycleJobRelation cyclejobrel = itr_cycle_job_relation.next();
			if (cyclejobrel.getCycleId() == cycleSelected) {
				cycleJobRelationId = cyclejobrel.getCycleJobRelationId();
				// return;
			}
		}

		processcycleRelationList = processCycleRelationService.findprocessCycleRelationsByCycleId(cycleSelected);
		Iterator<ProcessCycleRelation> itr_process_cycle_relation = processcycleRelationList.iterator();
		while (itr_process_cycle_relation.hasNext()) {
			ProcessCycleRelation processcyclerel = itr_process_cycle_relation.next();
			if (processcyclerel.getProcessId() == processID) {
				processCycleRelationId = processcyclerel.getProcessCycleRelationId();
				// return;
			}
		}

		ProcessRelaunch processRelaunch = processRelauncher.forkProcess(processID, processExecutionID, cycleSelected,
				Jobselected);
		processRelauncher.reLaunchProcess(processRelaunch, processCycleRelationId, cycleJobRelationId);
	}

	public ProcessEntity getProcessByProcessId(long processid) throws Exception{
		return processService.findByProcessId(processid);
	}

	public ProcessSchedule getScheduleByScheduleId(long processScheduleId) throws Exception{
		return processScheduleService.findProcessSchInfoByProcessScheduleId(processScheduleId);
	}

	public boolean delProcess(ServletRequest request) throws Exception {
		String msgStatus = "";
		boolean delStatus = false;
		long deletedProcessId = 0;
		logger.info("deleting process with process id" + request.getParameter("delProcessId"));
		String processId = request.getParameter("delProcessId");
		ProcessEntity processToBeDelete = processService.findByProcessId(Long.parseLong(processId));
		// processToBeDelete.setEndDate(new Date());
		processToBeDelete.setDeleted(URSBatchConstants.PROCESS_DELETED);
		deletedProcessId = processService.saveProcess(processToBeDelete);
		if (deletedProcessId == Long.parseLong(processId)) {
			msgStatus = (message_source.getMessage("process.deleteMessageSuccess", null, "Default", null));
			delStatus = true;
		}

		else {
			msgStatus = (message_source.getMessage("process.deleteMessageFail", null, "Default", null));
		}
		request.setAttribute("msgForDeleteProcess", msgStatus);
		return delStatus;
	}

	/**
	 * This method delete a perticular cycle
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */

	public String delCycle(ServletRequest request) throws Exception {
		int deleteCycleStatus = URSBatchConstants.CYCLE_DELETE_SUCCESS;
		String msgStatus = "";
		boolean deleteCond = false;
		Set<ProcessCycleRelation> processCycleRelations = null;
		String cycleID = request.getParameter("delCycleId");
		if (cycleID != null) {
			try {
				Cycle cycle = cycleService.findCycleInformationByCycleId(Integer.parseInt(cycleID));
				logger.info(" deleting Cycle with cycleID :" + cycle.getCycleId());
				processCycleRelations = cycle.getProcessCycleRelations();
				Iterator<ProcessCycleRelation> itr_process_cycle_rel = processCycleRelations.iterator();
				while (itr_process_cycle_rel.hasNext()) {
					ProcessCycleRelation pro_cycle_rel = itr_process_cycle_rel.next();
					if (processService.findByProcessId(pro_cycle_rel.getProcessId()).getDeleted() == 1) {
						deleteCond = true;
					}
				}
				if (processCycleRelations.isEmpty() || deleteCond == true) {
					try{
						cycleService.deleteCycleInformation(cycle);
						deleteCycleStatus = URSBatchConstants.CYCLE_DELETE_SUCCESS;
					}catch(Exception e){
						deleteCycleStatus = URSBatchConstants.CYCLE_DELETE_FAILURE;
					}
				} else {
					deleteCycleStatus = URSBatchConstants.PROCESS_CYCLE_RELATION;
				}
				if (deleteCycleStatus == URSBatchConstants.CYCLE_DELETE_SUCCESS) {
					msgStatus = (message_source.getMessage("cycleDetails.deleteMessageSuccess", null, "Default", null));
				} else if (deleteCycleStatus == URSBatchConstants.PROCESS_CYCLE_RELATION) {
					msgStatus = (message_source.getMessage("cycleDetails.associatesProcessmessage", null, "Default",
							null));
				} else {
					msgStatus = (message_source.getMessage("cycleDetails.deleteMessageFail", null, "Default", null));
				}
			} catch (Exception e) {
				logger.error("Not able to delete process with processID " + cycleID + "Error Message" + e.getMessage());

			}

		}
		return msgStatus;

	}

	/**
	 * This method returns the cycles of a perticular process and jobs of
	 * particular cycle of that process. By default this method is used to show
	 * the failure job of a cycle and failure cycle of a process in
	 * restartProcess page.
	 * 
	 * @param processExecutionID
	 * @return
	 */
	protected List getCycleNameByProcessInstanceId(long processExecutionID) throws Exception{
		// UI objects
		Map<String, Object> modelDataMap = null;
		List mainList = new ArrayList();

		List subList1 = new ArrayList();
		List subList2 = new ArrayList();
		String cycleName = null;
		long cycleId = 0;
		long processId = 0;
		String jobName = null;
		long jobId = 0;

		List processExecutionHistoryList = processExecutionHistoryService
				.findFailedCycleAndJobByProcessExecutionHistoryInstanceID(processExecutionID);
		Job failedJobInformation = null;
		Cycle failedCycleInformation = null;
		if (processExecutionHistoryList != null) {
			failedJobInformation = (Job) processExecutionHistoryList.get(0);
			failedCycleInformation = (Cycle) processExecutionHistoryList.get(1);
		}
		Iterator<ProcessCycleRelation> itr_pro_cycle_rel = processCycleRelationService
				.findprocessCycleRelationsByProcessId(
						processExecutionHistoryService.findByProcessExecutionHistoryInstanceID(processExecutionID)
						.getProcess().getProcessId()).iterator();
		while (itr_pro_cycle_rel.hasNext()) {

			modelDataMap = new HashMap<String, Object>();
			ProcessCycleRelation pro_cycle_relation = itr_pro_cycle_rel.next();
			cycleName = cycleService.findCycleInformationByCycleId(pro_cycle_relation.getCycleId()).getCycleName();
			cycleId = pro_cycle_relation.getCycleId();
			processId = pro_cycle_relation.getProcessId();
			modelDataMap.put("cycleName", cycleName);
			modelDataMap.put("cycleId", cycleId);
			modelDataMap.put("processId", processId);
			modelDataMap.put("processExecutionID", processExecutionID);
			if (cycleName.equals((failedCycleInformation).getCycleName())) {
				modelDataMap.put("cycleNameSelected", (failedCycleInformation).getCycleName());
			}

			subList1.add(modelDataMap);
		}
		// if(processExecutionHistoryList != null){
		Iterator<CycleJobRelation> itr_cycle_job_rel = cycleJobRelationService.findByCycleId(
				((Cycle) processExecutionHistoryList.get(1)).getCycleId()).iterator();
		while (itr_cycle_job_rel.hasNext()) {
			CycleJobRelation cycle_job_relation = itr_cycle_job_rel.next();
			jobName = jobService.findJobinformationByJobId(cycle_job_relation.getJobId()).getBusinessName();
			jobId = cycle_job_relation.getJobId();
			modelDataMap = new HashMap<String, Object>();
			modelDataMap.put("jobName", jobName);
			modelDataMap.put("jobId", jobId);
			if (jobId == (failedJobInformation).getId()) {
				modelDataMap.put("jobNameSelected", (failedJobInformation).getBusinessName());
			}
			subList2.add(modelDataMap);
		}
		// }
		modelDataMap = new HashMap<String, Object>();
		modelDataMap.put("processId",
				processExecutionHistoryService.findByProcessExecutionHistoryInstanceID(processExecutionID).getProcess()
				.getProcessId());
		modelDataMap.put("processExecutionID", processExecutionID);
		mainList.add(subList1);
		mainList.add(subList2);
		mainList.add(modelDataMap);
		return mainList;

	}

	/**
	 * This method returns the cycles of a perticular process and jobs of
	 * particular cycle of that process. But this method is used when we are
	 * changing the drop down for cycle in restartProcess page.
	 * 
	 * @param request
	 * @return
	 */
	protected List getJobNameByCycleName(ServletRequest request) throws Exception{
		Map<String, Object> modelDataMap = null;
		List mainList = new ArrayList();
		List subList2 = new ArrayList();
		long cycleidParam = Long.parseLong(request.getParameter("cycleid"));
		long processidParam = Long.parseLong(request.getParameter("processid"));
		long processExecutionIDParam = Long.parseLong(request.getParameter("processExecutionID"));
		String cycleNameParam = request.getParameter("cycleName");
		String selectedRadioParam = request.getParameter("selectedRadio");
		String cycleName = null;

		String jobName = null;
		long jobId = 0;
		List<CycleJobRelation> cycle_job_rel = cycleJobRelationService.findByCycleId(cycleidParam);
		Iterator<CycleJobRelation> itr_cycle_job_rel = cycle_job_rel.iterator();
		while (itr_cycle_job_rel.hasNext()) {
			CycleJobRelation cycl_job_re = itr_cycle_job_rel.next();
			jobName = jobService.findJobinformationByJobId(cycl_job_re.getJobId()).getBusinessName();
			jobId = cycl_job_re.getJobId();
			modelDataMap = new HashMap<String, Object>();
			modelDataMap.put("jobName", jobName);
			modelDataMap.put("jobId", jobId);
			subList2.add(modelDataMap);
		}
		mainList.add(subList2);

		Iterator<ProcessCycleRelation> itr_pro_cycle_rel = processCycleRelationService
				.findprocessCycleRelationsByProcessId(processidParam).iterator();
		while (itr_pro_cycle_rel.hasNext()) {
			modelDataMap = new HashMap<String, Object>();
			ProcessCycleRelation pro_cycle_relation = itr_pro_cycle_rel.next();
			cycleName = cycleService.findCycleInformationByCycleId(pro_cycle_relation.getCycleId()).getCycleName();

			modelDataMap.put("cycleName", cycleService.findCycleInformationByCycleId(pro_cycle_relation.getCycleId())
					.getCycleName());
			modelDataMap.put("cycleId", cycleService.findCycleInformationByCycleId(pro_cycle_relation.getCycleId())
					.getCycleId());
			modelDataMap.put("processId", processidParam);
			modelDataMap.put("processExecutionID", processExecutionIDParam);
			if (cycleNameParam.equals(cycleName)) {
				modelDataMap.put("cycleNameSelected", cycleNameParam);
			}
			mainList.add(modelDataMap);
		}
		modelDataMap = new HashMap<String, Object>();
		modelDataMap.put("processId", processidParam);
		modelDataMap.put("processExecutionID", processExecutionIDParam);
		modelDataMap.put("selectedRadio", selectedRadioParam);
		mainList.add(modelDataMap);
		mainList.add(cycleNameParam);
		return mainList;
	}

	/**
	 * This methods gets all the jobs and cycle associated with those jobs.
	 * 
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> loadJobDetails() throws Exception {
		logger.debug(" started loadJobDetails method");
		List jobDataList = new ArrayList();
		Map<String, Object> job_data = null;
		List<Job> jobsList = new ArrayList<Job>();

		jobsList = jobService.findallTheJobs();

		Iterator<Job> itr_job = jobsList.iterator();
		while (itr_job.hasNext()) {
			Job job = itr_job.next();
			String cycleList = "";
			job_data = new HashMap<String, Object>();
			job_data.put("job_id", job.getId());
			job_data.put("job_name", job.getBusinessName());
			job_data.put("job_description", job.getJobDescription());
			List<CycleJobRelation> cycleJobRelationList =cycleJobRelationService.findByjobId(job.getId());
			Iterator<CycleJobRelation> itr_cycle_job_relation = cycleJobRelationList.iterator();
			while (itr_cycle_job_relation.hasNext()) {
				CycleJobRelation cycle_job_relation = itr_cycle_job_relation.next();
				// create a comma seperated list
				cycleList = cycleList + ","
						+ cycleService.findCycleInformationByCycleId(cycle_job_relation.getCycleId()).getCycleName();

			}
			cycleList = cycleList.replaceFirst(",", "");
			job_data.put("usedIncycle", cycleList);
			jobDataList.add(job_data);
		}
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("list_job_data", jobDataList);
		return model;
	}

	

	public List<JobParam> findJobsParamsOccurance(String jobId, long cycleJobRelationId, long processCycleRelationId) throws Exception{

		List<JobParam> jobParamsList = new ArrayList<JobParam>();
		
		jobParamsList = jobParamService.getJobParamsByJobName(jobId);
		for (int jobListCnt = 0; jobListCnt < jobParamsList.size(); jobListCnt++) {
			logger.debug("jobList in findJobsParamsOccuranceis-:"
					+ jobParamsList.get(jobListCnt).getJobId());
			if (jobId.equals(jobParamsList.get(jobListCnt).getJobId())) {
				long paramId = Long.parseLong(jobParamsList.get(jobListCnt).getParamId());
				List<ParamProcessRelation> paramProcessRelationList = paramProcessRelationService
						.findByParamProcessRelation(paramId, processCycleRelationId, cycleJobRelationId);
				if (paramProcessRelationList.size() > 0) {
					ParamProcessRelation paramProcessRelation = paramProcessRelationList.get(0);
					int typeCode = paramProcessRelation.getTypeCd();
					if (typeCode == 1)
						jobParamsList.get(jobListCnt).setDefaultValue(paramProcessRelationList.get(0).getStringValue());
					if (typeCode == 2) {
						if (paramProcessRelationList.get(0).getDoubleValue() != null)
							jobParamsList.get(jobListCnt).setDefaultValue(
									paramProcessRelationList.get(0).getDoubleValue().toString());
					}
					if (typeCode == 3) {
						if (paramProcessRelationList.get(0).getDateValue() != null)
							jobParamsList.get(jobListCnt).setDefaultValue(
									paramProcessRelationList.get(0).getDateValue().toString());
					}
				}
			}
		}
		return jobParamsList;
	}

	public List<List<Map>> findCycleListForProcess(long processId, boolean flag) throws Exception {
		if (flag == false)
			flag = true;
		else
			flag = false;
		List<List<Map>> cycleListForProcess = new ArrayList<List<Map>>();
		List<Map> cycleListInformation = null;
		Map<String, Object> cycleMap = null;
		List<ProcessCycleRelation> pro_cyc_rel_list = processCycleRelationService
				.findprocessCycleRelationsByProcessId(processId);
		Iterator<ProcessCycleRelation> itr_pro_cyc_rel = pro_cyc_rel_list.iterator();
		while (itr_pro_cyc_rel.hasNext()) {
			ProcessCycleRelation processCycleRelation = itr_pro_cyc_rel.next();
			cycleMap = new HashMap<String, Object>();
			cycleListInformation = new ArrayList<Map>();
			cycleMap.put("cycleId", processCycleRelation.getCycleId());
			cycleMap.put("processId", processId);
			cycleMap.put("cycleName", cycleService.findCycleInformationByCycleId(processCycleRelation.getCycleId())
					.getCycleName());
			cycleMap.put("cycleDate", cycleService.findCycleInformationByCycleId(processCycleRelation.getCycleId())
					.getLastUpdated());
			cycleMap.put("processCycleRelationId", processCycleRelation.getProcessCycleRelationId());
			cycleMap.put("processId", processId);
			cycleMap.put("flag", flag);
			cycleListInformation.add(cycleMap);
			cycleListForProcess.add(cycleListInformation);
		}
		return cycleListForProcess;
	}

	public List findJobListForCycle(long cycleid, long processCycleRelationId) throws Exception{
		List<Map<String, Object>> jobList = new ArrayList<Map<String, Object>>();
		List<JobParam> jobParamList = new ArrayList<JobParam>();
		String paramValue = "";
		Map<String, Object> jobMapInfo = null;
		List<CycleJobRelation> cyc_job_rel_list = cycleJobRelationService.findByCycleId(cycleid);
		Iterator<CycleJobRelation> itr_cyc_job_rel = cyc_job_rel_list.iterator();
		while (itr_cyc_job_rel.hasNext()) {
			CycleJobRelation cycleJobRelation = itr_cyc_job_rel.next();
			jobParamList = findJobsParamsOccurance(jobService.findJobinformationByJobId(cycleJobRelation.getJobId())
					.getJobName(), cycleJobRelation.getCycleJobRelationId(), processCycleRelationId);
			paramValue = "";
			for (int jobListCnt = 0; jobListCnt < jobParamList.size(); jobListCnt++) {
				paramValue = paramValue + jobParamList.get(jobListCnt).getParamName() + "="
						+ jobParamList.get(jobListCnt).getDefaultValue() + "  ";
			}
			logger.debug("paramValue is:"
					+ paramValue);
			jobMapInfo = new HashMap<String, Object>();
			jobMapInfo.put("jobid", cycleJobRelation.getJobId());
			jobMapInfo.put("jobName", jobService.findJobinformationByJobId(cycleJobRelation.getJobId()).getJobName());
			jobMapInfo.put("cycleJobRelationId", cycleJobRelation.getCycleJobRelationId());
			jobMapInfo.put("paramValue", paramValue);
			jobList.add(jobMapInfo);
		}
		return jobList;

	}

	public void saveParamProcessRelation(long paramId, long cycleJobRelationId, long processCycleRelationId,
			int typeCode, String stringValue, long doubleValue, Date dateValue) throws Exception{
		logger.info("parameter values in saveParamProcessRelation are are " + paramId + "," + cycleJobRelationId + ","
				+ processCycleRelationId + "," + typeCode + "," + stringValue + "," + doubleValue + "," + dateValue);
		List paramProcessRelationList = new ArrayList();
		ParamProcessRelation paramProcessRelation = new ParamProcessRelation();
		ParamProcessRelation updateparamProcessRelation = null;
		paramProcessRelation.setParamId(paramId);
		paramProcessRelation.setCycleJobRelationId(cycleJobRelationId);
		paramProcessRelation.setProcessCycleRelationId(processCycleRelationId);
		paramProcessRelation.setTypeCd(typeCode);
		if (!stringValue.equals(""))
			paramProcessRelation.setStringValue(stringValue);
		if (doubleValue != 0)
			paramProcessRelation.setDoubleValue(doubleValue);
		if (dateValue != null)
			paramProcessRelation.setDateValue(dateValue);
		paramProcessRelationList = paramProcessRelationService.findByParamProcessRelation(paramId,
				processCycleRelationId, cycleJobRelationId);
		if (paramProcessRelationList.size() > 0) {
			updateparamProcessRelation = (ParamProcessRelation) paramProcessRelationList.get(0);
			updateparamProcessRelation.setStringValue(stringValue);
			updateparamProcessRelation.setDoubleValue(doubleValue);
			updateparamProcessRelation.setDateValue(dateValue);
			paramProcessRelationService.saveParamProcessRelation(updateparamProcessRelation);
		} else {
			paramProcessRelationService.saveParamProcessRelation(paramProcessRelation);
		}
	}

}
