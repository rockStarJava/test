package com.reinsurance.urs.batchweb.launcher;

import org.quartz.CronExpression;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.domain.batch.ProcessEntity;

/**
 * @author Lakshmi
 * @since 12/03/2013
 * @version 1.0.0
 * 
 */
@Component("jobSchedulerService")
public class JobSchedulerService {

	@Autowired
	@Qualifier("batchQuartzScheduler")
	SchedulerFactoryBean batchQuartzScheduler; 

	private Scheduler batchscheduler;

	private final static Logger log = LoggerFactory.getLogger(JobSchedulerService.class);	


	public  CronTrigger buildTrigger(String processNameID,
			String expression) {
		CronTrigger cronTrigger = new CronTrigger(processNameID + "Trigger",
				processNameID);
		try {
			// setup CronExpression
			CronExpression cexp = new CronExpression(expression);
			// Assign the CronExpression to CronTrigger
			cronTrigger.setCronExpression(cexp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cronTrigger;
	}

	public  void buildJobDetailsAndStart(String processNameID,
			CronTrigger cronTrigger) {
		// Initiate JobDetail with job name, job group, and executable job class
		JobDetail jobDetail = new JobDetail(processNameID, processNameID + "group",
				ProcessJob.class);

		log.info(jobDetail.getName());

		// specify the job' s details..

		jobDetail.getJobDataMap().put("ProcessID", processNameID);

		// schedule a job with JobDetail and Trigger
		try {
			if(batchQuartzScheduler!=null)
			{
			
				batchscheduler =  batchQuartzScheduler.getScheduler();
			if(batchscheduler!=null ){
				if (!batchscheduler.isStarted())
				{
					batchscheduler.start();
				}
				batchscheduler.scheduleJob(jobDetail, cronTrigger);}
			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public  boolean isJobScheduled(long processID, String processName) throws SchedulerException
	{
		String processIdStr = processName+processID;

		if(batchscheduler!=null && batchscheduler.isStarted())
		{
			JobDetail searchJob;
			searchJob = batchscheduler.getJobDetail(processIdStr, processIdStr + "group");
			if (searchJob != null){
				// this job is not in the scheduler yet
				return true;       
			}
		} 
	
		return false;

	}




	public void buildJobDetailsAndStart(ProcessEntity process) {

		if(process!=null && process.getProcessSchedule()!=null)
		{
			CronTrigger cronTrigger =  buildTrigger(process.getProcessName()+process.getProcessId() ,process.getProcessSchedule().toString());
			buildJobDetailsAndStart(process.getProcessName()+process.getProcessId(),cronTrigger) ;
		}

	

	}

}
