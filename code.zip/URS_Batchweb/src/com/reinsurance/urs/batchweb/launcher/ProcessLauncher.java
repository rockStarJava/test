/**
 * 
 */
package com.reinsurance.urs.batchweb.launcher;

/**
 * @author Lakshmi.Isukapally
 *
 */

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.exceptions.CycleFailedException;
import com.reinsurance.urs.domain.batch.ProcessCycleRelation;
import com.reinsurance.urs.domain.batch.ProcessEntity;
import com.reinsurance.urs.services.batch.ProcessCycleRelationService;

@Component("processLauncher")
public class ProcessLauncher {

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	@Autowired
	@Qualifier("batchCycleLauncher")
	BatchCycleLauncher batchCycleLauncher;
	@Autowired
	@Qualifier("launcherUtility")
	public LauncherUtility launcherUtility;
	

	@Autowired
	@Qualifier("processCycleRelationService")
	ProcessCycleRelationService processCycleRelationService;
	

	private final static Logger log = LoggerFactory
			.getLogger(ProcessLauncher.class);

	/**
	 * launchs execution of the ProcessEntity object
	 * 
	 * @param process
	 * @return status of the execution
	 */
	public int launchProcess(ProcessEntity process) {
		log.debug((message_source.getMessage("processLauncher.start", null,
				"Default", null)));
		if (process == null)
			return URSBatchConstants.PROCESS_DETAILS_EMPTY;
		boolean errorStatus = false;
		StringBuilder errorMessagestr = new StringBuilder("");
		// Start mark of the cycle execution in process execution history table
		Long processExexcInstId = launcherUtility.markProcessStartTime(process);
		try {
			// get all the cycles from e Batch process
			List<ProcessCycleRelation> cycleOrders = processCycleRelationService.findprocessCycleRelationsByProcessId(process.getProcessId());
			if (cycleOrders != null && cycleOrders.size() > 0) {
				// Order the cycles based on the execution orders
				Collections.sort(cycleOrders);
				Iterator<ProcessCycleRelation> it = cycleOrders
						.iterator();
				while (it.hasNext()) {
					ProcessCycleRelation processCycleRelation = (ProcessCycleRelation) it
							.next();
					int returncode = batchCycleLauncher
							.launchCycle(processCycleRelation.getProcessCycleRelationId(),processCycleRelation.getCycleId(),
									processExexcInstId);
					if (returncode != URSBatchConstants.CYCLE_EXECUTION_SUCCESS) {
						// some error happened check if you can progress further
						// ,once you have the cycle conditions

						errorMessagestr.append(message_source.getMessage(
										"processLauncher.executionFailMessage",
										null, "Default", null));
						errorMessagestr.append(processCycleRelation.getCycleId() );
						errorMessagestr.append(	URSBatchConstants.separator);
					
						log.error((message_source.getMessage(
								"processLauncher.error", null, "Default", null)));
						throw new CycleFailedException(
								(message_source.getMessage(
										"processLauncher.exception", null,
										"Default", null))
										+ processCycleRelation.getCycleId());
					}
					errorMessagestr.append(message_source.getMessage(
									"processLauncher.executionMessage", null,
									"Default", null));
					errorMessagestr.append(processCycleRelation.getCycleId());
					errorMessagestr.append(URSBatchConstants.separator);
						

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error((message_source.getMessage(
					"processLauncher.genericerror", null, "Default", null))
					+ e.getMessage());
			errorStatus = true;
		} finally {
			// mark end of the process execution in process execution history
			// table
			try{
				launcherUtility.markProcessCompletion(errorStatus, errorMessagestr.toString(),
						processExexcInstId);
			}catch(Exception e){
				log.info("Unexpected Error!!!", e);
			}
			if (errorStatus)
				return URSBatchConstants.PROCESS_IN_ERROR;

		}

		return URSBatchConstants.PROCESS_EXECUTION_SUCCESS;

	}

}
