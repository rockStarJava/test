/**
 * 
 */
package com.reinsurance.urs.batchweb.launcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.exceptions.CycleFailedException;
import com.reinsurance.urs.domain.batch.Cycle;
import com.reinsurance.urs.domain.batch.CycleJobRelation;
import com.reinsurance.urs.domain.batch.CycleRelaunch;
import com.reinsurance.urs.domain.batch.Job;
import com.reinsurance.urs.domain.batch.ProcessCycleRelation;
import com.reinsurance.urs.domain.batch.ProcessEntity;
import com.reinsurance.urs.domain.batch.ProcessRelaunch;
import com.reinsurance.urs.services.batch.CycleBatchService;
import com.reinsurance.urs.services.batch.CycleJobRelationService;
import com.reinsurance.urs.services.batch.JobService;
import com.reinsurance.urs.services.batch.ProcessService;

/**
 * @author Lakshmi.Isukapally
 * 
 */
@Component("processRelauncher")
public class ProcessRelauncher {

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	@Autowired
	@Qualifier("launcherUtility")
	public LauncherUtility launcherUtility;

	@Autowired
	@Qualifier("batchJobLauncher")
	private BatchJobLauncher batchJobLauncher;

	@Autowired
	@Qualifier("processService")
	ProcessService processService;

	@Autowired
	@Qualifier("cycleJobRelationService")
	private CycleJobRelationService cycleJobRelationService;
	
	@Autowired
	@Qualifier("cycleService")
	CycleBatchService cycleService;
	
	@Autowired
	@Qualifier("jobService")
	JobService jobService;

	protected static final Logger logger = LoggerFactory
			.getLogger(ProcessRelauncher.class);

	/**
	 * this will create process from the point where it has to be restarted
	 * 
	 * @param processId
	 * @param ProcessExecutionID
	 * @param cycleId
	 * @param jobId
	 * @return
	 */
	public ProcessRelaunch forkProcess(long processId, long ProcessExecutionID,
			long cycleId, long jobId) {
		
		try{
			logger.debug((message_source.getMessage("processRelauncher.executionMessage", null,
					"Default", null))+ processId
					+ "(cycleId & jobId) =" + cycleId + " ," + jobId);
	
			boolean pointerSet = false;		
			ProcessEntity p = processService.findByProcessId(processId);
			ProcessRelaunch processRelaunch = new ProcessRelaunch(processId,
					ProcessExecutionID);
	
			Set<ProcessCycleRelation> processCycleRelations = orderList(p
					.getProcessCycleRelations());
			
			int order = 0;
			List<CycleRelaunch> cycleRelaunchList = new ArrayList<CycleRelaunch>();
			for (ProcessCycleRelation processCycleRelation : processCycleRelations) {
				List<Job> jobsList = new ArrayList<Job>();
				Cycle tempCycle = cycleService.findCycleInformationByCycleId(processCycleRelation.getCycleId());     
				
				long tempCycleId = processCycleRelation.getCycleId();
				
				
				//long tempCycleId = processCycleRelation.getCycleId();
				//Cycle tempCycle=cycleService.findCycleInformationByCycleId(tempCycleId);
	
				List<CycleJobRelation> cycleJobRelations = cycleJobRelationService
						.findByCycleId(tempCycleId);
				Iterator<CycleJobRelation> iter = cycleJobRelations.iterator();
				while (iter.hasNext()) {
					CycleJobRelation cycleJobRelation = (CycleJobRelation) iter
							.next();
					long tempjobId = cycleJobRelation.getJobId();
					
					if ((tempCycleId == cycleId) && (tempjobId == jobId)) {
						pointerSet = true;
						
					}
					if (pointerSet) {
						jobsList.add(jobService.findJobinformationByJobId(cycleJobRelation.getJobId()));
					}
	
				}
				if (pointerSet) {
					CycleRelaunch cycleRelaunch = new CycleRelaunch(tempCycle,
							jobsList, order);
					order++;
					cycleRelaunchList.add(cycleRelaunch);
				}
			}
			processRelaunch.setCyclerelaunchlist(cycleRelaunchList);
	
			return processRelaunch;
		}catch(Exception e){
			return null;
		}
	}

	/**
	 * orders the ProcessCycleRelations based on execution order
	 * 
	 * @param cycleOrders
	 * @return
	 */
	private static TreeSet<ProcessCycleRelation> orderList(
			Set<ProcessCycleRelation> cycleOrders) {
		TreeSet<ProcessCycleRelation> OrderProcessCycleRelation = new TreeSet<ProcessCycleRelation>();
		OrderProcessCycleRelation.addAll(cycleOrders);
		return OrderProcessCycleRelation;

	}

	/**
	 * 
	 * @param processRelaunch
	 * @return
	 */
	public int reLaunchProcess(ProcessRelaunch processRelaunch,long processCycleRelationId,long cycleJobRelationId) {
		logger.debug(message_source.getMessage("processRelauncher.relaunchMessage", null,
				"Default", null));
		if (processRelaunch == null)
			return URSBatchConstants.PROCESS_DETAILS_EMPTY;

		boolean errorStatus = false;
		StringBuilder errorMessage =  new StringBuilder("");
		// Start mark of the cycle execution in process execution history table
		try{
			launcherUtility.MarkProcessRestart(processRelaunch
					.getProcessExecutionInstanceID());
		}catch(Exception e){
			logger.info("Unexpected Error!!!", e);
		}
		try {
			List<CycleRelaunch> cycleRelaunchList = processRelaunch
					.getCyclerelaunchlist();
			if (cycleRelaunchList != null && !cycleRelaunchList.isEmpty()) {
				Collections.sort(cycleRelaunchList);
				for (CycleRelaunch cycleRelaunchObj : cycleRelaunchList) {
					int executionStatus = launchCycle(cycleRelaunchObj,
							processRelaunch.getProcessExecutionInstanceID(),processCycleRelationId,cycleJobRelationId);
					if (executionStatus != URSBatchConstants.CYCLE_EXECUTION_SUCCESS) {
						// some error occurred while execution cycle
						 errorMessage.append(URSBatchConstants.separator);
						errorMessage.append(message_source.getMessage(
										"processLauncher.executionFailMessage",
										null, "Default", null));
						 errorMessage.append(cycleRelaunchObj.getCycle().getCycleName());
						

						logger.error((message_source.getMessage(
								"processLauncher.error", null, "Default", null)));
						throw new CycleFailedException(
								(message_source.getMessage(
										"processLauncher.exception", null,
										"Default", null))
										+ cycleRelaunchObj.getCycle()
												.getCycleName());
					}
					errorMessage.append(URSBatchConstants.separator);
					 errorMessage.append(message_source.getMessage(
									"processLauncher.executionMessage", null,
									"Default", null));
									 errorMessage.append(cycleRelaunchObj.getCycle().getCycleName());
					 


				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			errorStatus = true;
		} finally {
			// mark end of the process execution in process execution history
			// table
			try{
				launcherUtility.markProcessCompletion(errorStatus, errorMessage.toString(),
						processRelaunch.getProcessExecutionInstanceID());
			}catch(Exception e){
				logger.info("Unexpected Error!!!", e);
			}
			if (errorStatus)
				return URSBatchConstants.PROCESS_IN_ERROR;

		}

		return URSBatchConstants.PROCESS_EXECUTION_SUCCESS;

	}

	/**
	 * 
	 * @param cycleRelaunchObj
	 * @param processExecutionInstanceId
	 * @return
	 */
	private int launchCycle(CycleRelaunch cycleRelaunchObj,
			long processExecutionInstanceId,long processCycleRelationId,long cycleJobRelationId)

	{
		Cycle cycle = cycleRelaunchObj.getCycle();
		long	cycleInstanceId = 0;
		List<Job> jobLists = cycleRelaunchObj.getJobsList();
		boolean cycleExecutionFailstatus = false;
		StringBuilder cycleExecutionmessage = new StringBuilder("");
		
		try {
			cycleInstanceId = launcherUtility.markstartTimeoftheCycle(cycle,
					processExecutionInstanceId);
			
			for (Job jobObj : jobLists) {

				int jobexecutionStatus = batchJobLauncher.launchBatchJob(processCycleRelationId,cycleJobRelationId,
						jobObj, cycleInstanceId ,processExecutionInstanceId);
				if (jobexecutionStatus != URSBatchConstants.JOB_EXECUTION_SUCCESS) {
					cycleExecutionFailstatus = true;
					cycleExecutionmessage.append((message_source.getMessage(
							"cycleLauncher.executionFailMessage", null,
							"Default", null)));
						cycleExecutionmessage.append(cycle.getCycleName() );
						cycleExecutionmessage.append(URSBatchConstants.separator);
					throw new CycleFailedException((message_source.getMessage(
							"cycleLauncher.executionFailMessage", null,
							"Default", null))
							+ cycle.getCycleName() + URSBatchConstants.separator);
				} else
					cycleExecutionmessage.append((message_source.getMessage(
							"cycleLauncher.executionMessage", null, "Default",
							null)));
							cycleExecutionmessage.append(cycle.getCycleName() );
					cycleExecutionmessage.append(URSBatchConstants.separator);
			}
		} catch (Exception e) {
			cycleExecutionFailstatus = true;
			e.printStackTrace();

		} finally {
			try{
				launcherUtility.markTheCompletiontimeOfCycle(cycle,
						cycleExecutionFailstatus, cycleExecutionmessage.toString(),
						cycleInstanceId);
			}catch(Exception e){
				logger.info("Unexpected Error!!!", e);
			}
			if (cycleExecutionFailstatus)
				return URSBatchConstants.CYCLE_EXECUTION_ERROR;

		}
		return URSBatchConstants.CYCLE_EXECUTION_SUCCESS;

	}

}
