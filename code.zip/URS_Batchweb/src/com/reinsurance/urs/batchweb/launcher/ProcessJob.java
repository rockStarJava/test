/**
 * 
 */
package com.reinsurance.urs.batchweb.launcher;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.dao.batch.ProcessEntityDao;
import com.reinsurance.urs.domain.batch.ProcessEntity;

/**
 * @author Lakshmi.Isukapally
 * 
 */
@Component
public class ProcessJob implements Job {
	@Autowired
	ProcessEntityDao processDao;
	@Autowired
	@Qualifier("processLauncher")
	ProcessLauncher processLauncher;
	
	
	public void execute(JobExecutionContext jExeCtx)
			throws JobExecutionException {
	
		String processId = (String) jExeCtx.getMergedJobDataMap().get(
				"ProcessId");
		if (processId != null) {
			
			try {
				ProcessEntity process = getProcessDetails(processId);
				if (process != null) {
					processLauncher.launchProcess(process);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}

		}

	}

	private ProcessEntity getProcessDetails(String processId) {
		try{
			ProcessEntity process = processDao.findByProcessId(Long.getLong(processId));
			return process;
		}catch(Exception e){
			return null;
		}
	}
	

}
