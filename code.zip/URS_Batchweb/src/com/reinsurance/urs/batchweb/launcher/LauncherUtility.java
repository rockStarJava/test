/**
 * 
 */
package com.reinsurance.urs.batchweb.launcher;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.domain.batch.Cycle;
import com.reinsurance.urs.domain.batch.CycleExecutionHistory;
import com.reinsurance.urs.domain.batch.CycleJobRelation;
import com.reinsurance.urs.domain.batch.JobExecutionHistory;
import com.reinsurance.urs.domain.batch.ProcessCycleRelation;
import com.reinsurance.urs.domain.batch.ProcessEntity;
import com.reinsurance.urs.domain.batch.ProcessExecutionHistory;
import com.reinsurance.urs.services.batch.CycleExecutionHistoryService;
import com.reinsurance.urs.services.batch.JobExecutionHistoryService;
import com.reinsurance.urs.services.batch.ProcessExecutionHistoryService;

/**
 * @author Lakshmi.Isukapally
 * 
 */
@Component("launcherUtility")
public class LauncherUtility {

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	@Autowired
	@Qualifier("processExecutionHistoryService")
	ProcessExecutionHistoryService processExecutionHistoryService;

	@Autowired
	@Qualifier("cycleExecutionHistoryService")
	public CycleExecutionHistoryService cycleExecutionHistoryService;

	@Autowired
	@Qualifier("jobExecutionHistoryService")
	public JobExecutionHistoryService jobExecutionHistoryService;

	protected static final Logger logger = LoggerFactory.getLogger(LauncherUtility.class);

	/******************************* job *************************************/

	/**
	 * 
	 * @param jobExecutionInstanceId
	 * @param errorMessage
	 * @param errorStatus
	 */
	public void updateCompletionTime(long jobExecutionInstanceId, String errorMessage, boolean errorStatus) throws Exception {
		logger.info(message_source.getMessage("Launcher.startMessage", null,
				"Default", null)  + jobExecutionInstanceId + "status:"
				+ errorStatus);
		String status;
		if (errorStatus == true)
			status = URSBatchConstants.JOB_EXECUTION_FAILURE_STATUS;
		else
			status = URSBatchConstants.JOB_EXECUTION_SUCCESS_STATUS;

		JobExecutionHistory jobExecutionHistory = jobExecutionHistoryService
				.findByJobExecutionHistoryID(jobExecutionInstanceId);
		java.util.Date endTime = new java.util.Date();
		jobExecutionHistory.setErrorMsg(errorMessage);
		jobExecutionHistory.setStatus(status);
		jobExecutionHistory.setEndTime(endTime);
		jobExecutionHistoryService.saveJobExecutionHistory(jobExecutionHistory);
	}

	/**
	 * 
	 * @param job
	 * @param cycleExecutionInstanceId
	 * @param errorStatus
	 * @return
	 */
	public long updateStartTime(com.reinsurance.urs.domain.batch.Job job, long cycleExecutionInstanceId,
			boolean errorStatus) throws Exception{

		logger.info(message_source.getMessage("Launcher.markStartTimeForJob", null,
				"Default", null)+ job);
		java.util.Date startTime = new java.util.Date();
		CycleExecutionHistory cycleExecutionHistory = cycleExecutionHistoryService
				.findByCyclesExecutionHistoryID(cycleExecutionInstanceId);
		JobExecutionHistory jobExecutionHistory = new JobExecutionHistory();
		jobExecutionHistory.setJobId(job.getId());
		jobExecutionHistory.setCycleExecutionHistory(cycleExecutionHistory);
		jobExecutionHistory.setStartTime(startTime);
		jobExecutionHistory.setStatus(URSBatchConstants.EXECUTION_STARTED);
		long jobExecutionInstanceId = jobExecutionHistoryService.saveJobExecutionHistory(jobExecutionHistory);
		return jobExecutionInstanceId;
	}

	/******************************* Cycle *************************************/

	/**
	 * orders CycleJobRelation set
	 * 
	 * @param jobOrders
	 * @return
	 */
	public TreeSet<CycleJobRelation> orderList(List<CycleJobRelation> jobOrders) {
		TreeSet<CycleJobRelation> OrderCycleJobRelation = new TreeSet<CycleJobRelation>();
		OrderCycleJobRelation.addAll(jobOrders);
		return OrderCycleJobRelation;

	}

	/**
	 * This method updates cycle execution history completing status & time
	 * 
	 * @param cycle
	 * @param errorStatus
	 * @param errorMessage
	 * @param cycleExecutionInstanceId
	 */
	public void markTheCompletiontimeOfCycle(Cycle cycle, boolean errorStatus, String errorMessage,
			long cycleExecutionInstanceId) throws Exception {
		logger.info(message_source.getMessage("Launcher.markEndTimeForCycle", null,
				"Default", null)
				+ cycle.getCycleName() + ":" + cycle.getCycleId()
				+ " with status:" + errorStatus);

		String status;
		if (errorStatus == true)

			status = URSBatchConstants.CYCLE_EXECUTION_FAILURE_STATUS;
		else
			status = URSBatchConstants.CYCLE_EXECUTION_SUCCESS_STATUS;

		java.util.Date endTime = new java.util.Date();
		CycleExecutionHistory cycleExecutionHistory = cycleExecutionHistoryService
				.findByCyclesExecutionHistoryID(cycleExecutionInstanceId);
		cycleExecutionHistory.setStatus(status);
		cycleExecutionHistory.setErrorMsg(errorMessage);
		cycleExecutionHistory.setEndTime(endTime);
		cycleExecutionHistoryService.saveCycleExecutionHistory(cycleExecutionHistory);

	}

	/**
	 * marks the start time of the cycle execution
	 * 
	 * @param cycle
	 * @param processExecutionInstancId
	 * @return
	 */
	public long markstartTimeoftheCycle(Cycle cycle, long processExecutionInstancId) throws Exception {
		logger.info(message_source.getMessage("Launcher.markStartTimeForCycle", null,
				"Default", null)+  cycle.getCycleName() + ":" + cycle.getCycleId());
		java.util.Date date = new java.util.Date();
		ProcessExecutionHistory processExecutionHistory = processExecutionHistoryService
				.findByProcessExecutionHistoryInstanceID(processExecutionInstancId);
		CycleExecutionHistory cycleExecutionHistory = new CycleExecutionHistory();
		cycleExecutionHistory.setCycle(cycle);
		cycleExecutionHistory.setProcessExecutionHistory(processExecutionHistory);
		cycleExecutionHistory.setStartTime(date);
		cycleExecutionHistory.setStatus(URSBatchConstants.EXECUTION_STARTED);
		long cycleExecutionInstanceId = cycleExecutionHistoryService.saveCycleExecutionHistory(cycleExecutionHistory);
		return cycleExecutionInstanceId;
	}

	/******************************* process *************************************/
	/**
	 * marks completion of the process
	 * 
	 * @param errorStatus
	 * @param errorMessage
	 * @param processExexcInstId
	 */
	public void markProcessCompletion(boolean errorStatus, String errorMessage, long processExexcInstId) throws Exception {
		logger.info(message_source.getMessage("Launcher.markEndTimeForProcess", null,
				"Default", null)+ processExexcInstId + "with Status :"
				+ errorStatus);
		String status;
		if (errorStatus == true) {
			status = URSBatchConstants.PROCESS_EXECUTION_FAILURE_STATUS;
		} else {
			status = URSBatchConstants.PROCESS_EXECUTION_SUCCESS_STATUS;
		}

		Timestamp endTime = new Timestamp((new Date()).getTime());
		ProcessExecutionHistory processExecutionHistory = processExecutionHistoryService
				.findByProcessExecutionHistoryInstanceID(processExexcInstId);
		String previousErrorMessage = (String) processExecutionHistory.getErrorMsg();
		if (previousErrorMessage != null)
			errorMessage = previousErrorMessage + errorMessage;
		processExecutionHistory.setErrorMsg(errorMessage);
		processExecutionHistory.setEndTime(endTime);
		processExecutionHistory.setStatus(status);
		processExecutionHistoryService.saveProcessExecutionHistory(processExecutionHistory);
	}

	/**
	 * marks the start time the process started
	 * 
	 * @param process
	 * @return id of the processexecutionhistory
	 */
	public long markProcessStartTime(ProcessEntity process) {
		logger.info(message_source.getMessage("Launcher.markStartTimeForProcess", null,
				"Default", null)+  process.getProcessName() + ":"
				+ process.getProcessId());
		ProcessExecutionHistory processExecutionHistory = new ProcessExecutionHistory();
		
		Timestamp date = new Timestamp((new Date()).getTime());
		try {
			processExecutionHistory.setProcess(process);
			processExecutionHistory.setStartTime(date);
			processExecutionHistory.setStatus(URSBatchConstants.EXECUTION_STARTED);
			processExecutionHistoryService.saveProcessExecutionHistory(processExecutionHistory);

		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return processExecutionHistory.getProcessExecutionInstanceId();

	}

	/**
	 * 
	 * @param processExecutionInstanceID
	 * @return
	 */
	public Long MarkProcessRestart(long processExecutionInstanceID) throws Exception {
		logger.info(message_source.getMessage("Launcher.markReStartTimeForProcess", null,
				"Default", null)+  + processExecutionInstanceID);
		Date startTime = new Date();
		String errorMessage = "";
		ProcessExecutionHistory processExecutionHistory = processExecutionHistoryService
				.findByProcessExecutionHistoryInstanceID(processExecutionInstanceID);
		errorMessage = (String) processExecutionHistory.getErrorMsg();
		errorMessage = errorMessage.concat(URSBatchConstants.separator);
		errorMessage = errorMessage.concat(message_source.getMessage("processLauncher.relaunchAppend", null, "Default",
				null) + startTime);

		processExecutionHistory.setErrorMsg(errorMessage);
		processExecutionHistory.setStatus(URSBatchConstants.EXECUTION_STARTED);
		processExecutionHistoryService.saveProcessExecutionHistory(processExecutionHistory);
		return processExecutionInstanceID;
	}

	/**
	 * orders list based on the execution order
	 * 
	 * @param cycleOrders
	 * @return
	 */
	public TreeSet<ProcessCycleRelation> orderList(Set<ProcessCycleRelation> cycleOrders) {
		TreeSet<ProcessCycleRelation> OrderProcessCycleRelation = new TreeSet<ProcessCycleRelation>();
		OrderProcessCycleRelation.addAll(cycleOrders);
		return OrderProcessCycleRelation;

	}

}
