/**
 * 
 */
package com.reinsurance.urs.batchweb.launcher;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.exceptions.JobFailedException;
import com.reinsurance.urs.domain.batch.Cycle;
import com.reinsurance.urs.domain.batch.CycleJobRelation;
import com.reinsurance.urs.services.batch.CycleBatchService;
import com.reinsurance.urs.services.batch.CycleJobRelationService;

@Component("batchCycleLauncher")
public class BatchCycleLauncher {

	@Autowired
	@Qualifier("cycleService")
	CycleBatchService cycleService;

	@Autowired
	@Qualifier("batchJobLauncher")
	private BatchJobLauncher batchJobLauncher;

	@Autowired
	@Qualifier("cycleJobRelationService")
	private CycleJobRelationService cycleJobRelationService;

	@Autowired
	@Qualifier("launcherUtility")
	public LauncherUtility launcherUtility;

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	private final static Logger log = LoggerFactory
			.getLogger(BatchCycleLauncher.class);

	public int launchCycle(long processcylerelaionId, Cycle cycle,
			long processExecutionInstancId) {

		if (cycle == null)
			return URSBatchConstants.CYCLE_DETAILS_EMPTY;
		log.info(message_source.getMessage("cycleLauncher.startMessage", null,
				"Default", null) + cycle.getCycleName());
		boolean errorStatus = false;
		long cycleExecutionInstanceId = -1;
		StringBuilder cycleMessageStr = new StringBuilder("");

		try {

			// Start mark of the cycle execution in cycle execution history
			// table
			cycleExecutionInstanceId = launcherUtility.markstartTimeoftheCycle(
					cycle, processExecutionInstancId);

			// get all the cycles from the Batch process
			List<CycleJobRelation> jobOrders = cycleJobRelationService
					.findByCycleId(cycle.getCycleId());

			log.info(message_source.getMessage(
					"cycleLauncher.launchJobsMessage", null, "Default", null)
					+ jobOrders);
			if (jobOrders != null) {
				// Order the cycles based on the execution orders
				Set<CycleJobRelation> sortedJobOrders = launcherUtility
						.orderList(jobOrders);

				// iterate thru cycle to execute all the jobs
				Iterator<CycleJobRelation> it = sortedJobOrders.iterator();
				while (it.hasNext()) {
					CycleJobRelation cycleJobRelation = (CycleJobRelation) it
							.next();

					int jobsExecutiontatusCode = batchJobLauncher
							.launchBatchJob(processcylerelaionId,
									cycleJobRelation.getCycleJobRelationId(),
									cycleJobRelation.getJobId(),
									cycleExecutionInstanceId,
									processExecutionInstancId);
					if (jobsExecutiontatusCode != URSBatchConstants.JOB_EXECUTION_SUCCESS) {

						cycleMessageStr.append(URSBatchConstants.separator);
						cycleMessageStr.append(message_source.getMessage(
								"cycleLauncher.executionFailMessage", null,
								"Default", null));

						cycleMessageStr.append(cycleJobRelation.getJobId());
						cycleMessageStr.append(URSBatchConstants.separator);

						throw new JobFailedException(message_source.getMessage(
								"cycleLauncher.executionFailMessage", null,
								"Default", null)
								+ cycleJobRelation.getJobId());

					} else {
						cycleMessageStr.append(URSBatchConstants.separator);
						cycleMessageStr.append(message_source.getMessage(
								"cycleLauncher.executionMessage", null,
								"Default", null));
						cycleMessageStr.append(cycleJobRelation.getJobId());

					}
				}
			}

		} catch (Exception e) {
			errorStatus = true;
			e.printStackTrace();

		} finally {
			if (cycleExecutionInstanceId != -1) {
				try{
					launcherUtility.markTheCompletiontimeOfCycle(cycle,
							errorStatus, cycleMessageStr.toString(),
							cycleExecutionInstanceId);
				}catch(Exception e){
					log.info("Unexpected Error!!!", e);
				}
			} else {
				errorStatus = true;
			}

			if (errorStatus)
				return URSBatchConstants.CYCLE_EXECUTION_ERROR;

		}

		return URSBatchConstants.CYCLE_EXECUTION_SUCCESS;
	}

	public int launchCycle(long processcylerelaionId, long cycleId,
			Long processExexcInstId) {
		Cycle cycle = null;
		try{		
			cycle = cycleService.findCycleInformationByCycleId(cycleId);
		}catch(Exception e){
			log.info(e.getMessage());
		}
		
		return launchCycle(processcylerelaionId, cycle, processExexcInstId);
	}

}
