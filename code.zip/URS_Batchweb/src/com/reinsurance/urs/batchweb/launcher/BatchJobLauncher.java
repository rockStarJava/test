package com.reinsurance.urs.batchweb.launcher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.exceptions.JobBeanNotFoundExeception;
import com.reinsurance.urs.batch.exceptions.JobFailedException;
import com.reinsurance.urs.batch.jobs.framewrk.StacktraceUtil;
import com.reinsurance.urs.batch.utility.ApplicationContextUtil;
import com.reinsurance.urs.domain.batch.JobParam;
import com.reinsurance.urs.domain.batch.ParamProcessRelation;
import com.reinsurance.urs.services.batch.CycleJobRelationService;
import com.reinsurance.urs.services.batch.JobParamService;
import com.reinsurance.urs.services.batch.JobService;
import com.reinsurance.urs.services.batch.ParamProcessRelationService;
import com.reinsurance.urs.services.batch.ProcessCycleRelationService;
import com.reinsurance.urs.services.batch.ProcessScheduleService;

@Component("batchJobLauncher")
public class BatchJobLauncher {
	@Autowired
	@Qualifier("jobService")
	public JobService jobService;
	
	@Autowired
	@Qualifier("jobParamService")
	public JobParamService jobParamService;

	@Autowired
	@Qualifier("cycleJobRelationService")
	CycleJobRelationService cycleJobRelationService;

	@Autowired
	@Qualifier("processScheduleService")
	ProcessScheduleService processScheduleService;

	@Autowired
	@Qualifier("processCycleRelationService")
	ProcessCycleRelationService processCycleRelationService;

	@Autowired
	@Qualifier("paramProcessRelationService")
	ParamProcessRelationService paramProcessRelationService;
	@Autowired
	@Qualifier("launcherUtility")
	public LauncherUtility launcherUtility;

	private final static Logger log = LoggerFactory.getLogger(BatchJobLauncher.class);

	private static JobLauncher jobLauncher = null;

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	public int launchBatchJob(long processCycleRelationId, long cycleJobRelationId,
			com.reinsurance.urs.domain.batch.Job jobObj, long cycleExecutionInstanceId ,long processExecutionInstancId) {

		StringBuilder executionMessageStr = new StringBuilder("");
		int returnCode = 0;
		boolean errorStatus = false;
		long jobExecutionInstanceId = -1;
			
		
		try {
			ApplicationContext ctx = ApplicationContextUtil.getApplicationContext();

			jobExecutionInstanceId = launcherUtility.updateStartTime(jobObj, cycleExecutionInstanceId, errorStatus);

			JobParameters jobParam = setJobParams(processCycleRelationId, cycleJobRelationId, jobObj ,processExecutionInstancId);

			// getting jobLauncher bean
			jobLauncher = ctx.getBean(JobLauncher.class);

			Job job = (Job) ctx.getBean(jobObj.getJobName());
			if (job == null) {
				throw new JobBeanNotFoundExeception((message_source.getMessage("batchJobLauncher.nojobFound", null,
						"Default", null)));
			}
			
			executionMessageStr.append(getJobStartMessage(jobObj.getJobName()));
		
			// Execute the job
			JobExecution jobExecution = jobLauncher.run(job, jobParam);
			// Get all the job executions
			for (StepExecution se : jobExecution.getStepExecutions()) {
				executionMessageStr.append(URSBatchConstants.separator);
				if (se.getExecutionContext().get(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY) != null)
					executionMessageStr.append(se.getExecutionContext()
							.get(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY).toString());
				//populate end time
				executionMessageStr.append(getJobEndMessage(jobObj.getJobName()));
			
			}
			if (jobExecution.getExitStatus().getExitCode().equals(URSBatchConstants.FAILEDSTATUS)) {
				throw new JobFailedException(executionMessageStr.toString());
			}

		} catch (JobExecutionAlreadyRunningException e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
			// or set to any error code,externalize returncode
			// values to a static class
		} catch (JobFailedException e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator + URSBatchConstants.newLine);
			executionMessageStr.append(URSBatchConstants.separator + URSBatchConstants.newLine);
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(URSBatchConstants.logger_star);
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
		} catch (JobRestartException e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
		} catch (JobInstanceAlreadyCompleteException e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
		} catch (JobParametersInvalidException e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
		} catch (JobBeanNotFoundExeception e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			executionMessageStr.append(URSBatchConstants.separator);
			executionMessageStr.append(StacktraceUtil.getStackTrace(e));
			errorStatus = true;
			returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;

		} finally {

			// some error occurred before even marking the time.
			if (jobExecutionInstanceId != -1) {
				try{
					launcherUtility.updateCompletionTime(jobExecutionInstanceId, executionMessageStr.toString(),
							errorStatus);
				}catch(Exception ee){
					log.info("Unexpected Error!!!", ee);
				}
			} else {
				errorStatus = true;
				returnCode = URSBatchConstants.JOB_EXECUTION_FAILURE;
			}
			if (!errorStatus)
				returnCode = URSBatchConstants.JOB_EXECUTION_SUCCESS;
		}
		log.info(message_source.getMessage("batchJob.ended", null,
				"Default", null)+ jobObj.toString());
		return returnCode;
	}

	

	public int launchBatchJob(long processcylerelaionId, long cycleJobRelationId, long jobId,
			long cycleExecutionInstanceId ,long processExecutionInstancId) {
		com.reinsurance.urs.domain.batch.Job jobObj = jobService.findJobinformationByJobId(jobId);
		return launchBatchJob(processcylerelaionId, cycleJobRelationId, jobObj, cycleExecutionInstanceId ,processExecutionInstancId);
	}

	/**
	 * This methods reads the params that are required for the execution of job
	 * and reads database for the values to be set
	 * 
	 * @param processCycleRelationId
	 * @param cycleJobRelationId
	 * @param jobObj
	 * @return
	 * @throws ParseException
	 */
	@SuppressWarnings("rawtypes")
	private JobParameters setJobParams(long processCycleRelationId, long cycleJobRelationId,
			com.reinsurance.urs.domain.batch.Job jobObj ,long processExecutionInstanceId) throws ParseException { // create
		// new
		Date dateValue = null;
		String strValue = null;
		Double doubleValue = null;
		int jobparamType = 0;
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();

		
		String filePath = message_source.getMessage("jobsParamListxml.path", null, "Default", null);
		filePath = filePath + "/jobsParamList.xml";


		// get the list of params required
		List<JobParam> paramJobList = jobParamService.getJobParamsByJobName(jobObj.getJobName());
		if (paramJobList != null) {
			Iterator it = paramJobList.iterator();

			// Iterate thru the params and extract the values if set in database
			while (it.hasNext()) {
				JobParam jobparam = (JobParam) it.next();
				List<ParamProcessRelation> paramProcessRelationList = null;
				try{
					paramProcessRelationList = paramProcessRelationService
							.findByParamProcessRelation(Long.parseLong(jobparam.getParamId()), processCycleRelationId,
									cycleJobRelationId);
				}
				catch(Exception e){
					log.info(e.getMessage());
				}
				if (paramProcessRelationList != null) {
					if (paramProcessRelationList.size() > 0) {
						ParamProcessRelation paramProcessRelation = paramProcessRelationList.get(0);
						jobparamType = paramProcessRelation.getTypeCd();
						dateValue = paramProcessRelation.getDateValue();
						strValue = paramProcessRelation.getStringValue();
						if (paramProcessRelation.getDoubleValue() != null) {
							doubleValue = new Double(paramProcessRelation.getDoubleValue());
						}
					}

				}
				// If type is String
				if ((jobparamType == URSBatchConstants.CODE_INPUT_TYPE_STRING)
						|| (jobparam.getType().equalsIgnoreCase(URSBatchConstants.INPUT_TYPE_STRING)))

				{
					if (strValue == null)
						strValue = jobparam.getDefaultValue();
						jobParametersBuilder.addString(jobparam.getParamName(), strValue);
				}
				// if type is double
				if ((jobparamType == URSBatchConstants.CODE_INPUT_TYPE_DOUBLE)
						|| (jobparam.getType().equalsIgnoreCase(URSBatchConstants.INPUT_TYPE_DOUBLE)))

				{
					double doubleValuetemp = 0;
					if (doubleValue == null)
						doubleValuetemp = Double.parseDouble(jobparam.getDefaultValue());
					else
						doubleValuetemp = doubleValue.doubleValue();

					jobParametersBuilder.addDouble(jobparam.getParamName(), doubleValuetemp);
				}
				// if type is date
				if ((jobparamType == URSBatchConstants.CODE_INPUT_TYPE_DATE)
						|| (jobparam.getType().equalsIgnoreCase(URSBatchConstants.INPUT_TYPE_DATE)))

				{

					boolean setDate = true;
					if (dateValue == null)
						if (jobparam.getDefaultValue() != null && !jobparam.getDefaultValue().isEmpty()) {
							try {
								dateValue = new SimpleDateFormat(URSBatchConstants.DATE_FORMAT, Locale.ENGLISH)
										.parse(jobparam.getDefaultValue());
							} catch (Exception e) {
								log.info( message_source.getMessage("batchJobLauncher.paramDateError", null,"Default", null) + processCycleRelationId + " :"
										+ cycleJobRelationId );
								setDate = false;

							}
						}

					if (setDate)
						jobParametersBuilder.addDate(jobparam.getParamName(), dateValue);
				}
			}
		}
		// add timestamp to facilitate multiple runs
		jobParametersBuilder.addLong(URSBatchConstants.TIMESTAMP, System.currentTimeMillis());
		
		// add processExecutionID to add in reports as needed
		jobParametersBuilder.addLong(URSBatchConstants.PROCESS_EXECUTION_ID ,processExecutionInstanceId);
				
		return jobParametersBuilder.toJobParameters();

	}
	
	private String getJobStartMessage(String jobName)
	{
	return URSBatchConstants.logger_star+ URSBatchConstants.newLine+
	 URSBatchConstants.tab + message_source.getMessage("batchJob.started", null,"Default", null)	
			+ jobName
	+ " - " + new java.util.Date()+URSBatchConstants.newLine;
	}

	private String getJobEndMessage(String jobName)
	{
	return URSBatchConstants.newLine+
	 URSBatchConstants.tab + message_source.getMessage("batchJob.ended", null,"Default", null)	
			+ jobName
	+ " - " + new java.util.Date()+URSBatchConstants.newLine+ URSBatchConstants.logger_star;
	}
}
