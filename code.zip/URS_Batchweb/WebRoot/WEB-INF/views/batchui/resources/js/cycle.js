function resetCycle(){
document.getElementById("element_1").value = "";
document.getElementById("element_2").value = "";
document.getElementById("ToLB").value = "";
while (document.getElementById("ToLB").firstChild) {
document.getElementById("ToLB").removeChild(document.getElementById("ToLB").firstChild);
}
}

function moveForward(tbFrom, tbTo){
	var checkFlag = true;
	var content;
	for (i = 0; i < tbFrom.options.length; i++){
		if(tbFrom.options[i].selected){
			var tbFromVal = tbFrom.options[i].value;
			opt = document.createElement("option");
            if(tbTo.options.length > 0){
            for(i = 0; i < tbTo.options.length; i++){
            		
            	opt.value = tbFromVal;
                opt.text=tbFromVal;
                document.getElementById("ToLB").appendChild(opt);
            }
		}
            else{
            	opt.value = tbFromVal;
                opt.text=tbFromVal;
                document.getElementById("ToLB").appendChild(opt);
            }
            
			break;
		}
		
	}
	
	 for(i = 0; i < tbTo.options.length; i++){
		 if(i==0){
			 
			 content= tbTo.options[i].value;
		 }
			 if(i>0){
				 
		 content = content+','+tbTo.options[i].value;
			 }
	 }
	
	document.getElementById("hiddenJob").value = content;
}
function removeItem(tbTo){
	var content;
	for (i = 0; i < tbTo.options.length; i++){
		if(tbTo.options[i].selected){
			document.getElementById("ToLB").removeChild(tbTo.options[i]);
		}
	}
	for(i = 0; i < tbTo.options.length; i++){
		 if(i==0){
			 
			 content= tbTo.options[i].value;
		 }
			 if(i>0){
				 
		 content = content+','+tbTo.options[i].value;
			 }
	 }
	
	document.getElementById("hiddenJob").value = content;
}

$(document).ready(function(){
    $('input[type="button"]').click(function(){
        var $op = $('#ToLB option:selected'),
            $this = $(this);
        if($op.length){
            ($this.val() == 'Up') ? 
                $op.first().prev().before($op) : 
                $op.last().next().after($op);
        }
        var content;
    	for(i = 0; i < document.getElementById("ToLB").options.length; i++){
    		 if(i==0){
    			 //alert(document.getElementById("ToLB").options[i].value)
    			 content= document.getElementById("ToLB").options[i].value;
    		 }
    			 if(i>0){
    				 //alert(document.getElementById("ToLB").options[i].value) 
    		 content = content+','+document.getElementById("ToLB").options[i].value;
    			 }
    	 }
    	
    	 document.getElementById("hiddenJob").value = content;
    });
    var content;
	for(i = 0; i < document.getElementById("ToLB").options.length; i++){
		 if(i==0){
			 //alert(document.getElementById("ToLB").options[i].value)
			 content= document.getElementById("ToLB").options[i].value;
		 }
			 if(i>0){
				 //alert(document.getElementById("ToLB").options[i].value) 
		 content = content+','+document.getElementById("ToLB").options[i].value;
			 }
	 }
	
	 document.getElementById("hiddenJob").value = content;
    
});
function imposeMaxLength(Event, Object, MaxLen)
{
    return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40));
}