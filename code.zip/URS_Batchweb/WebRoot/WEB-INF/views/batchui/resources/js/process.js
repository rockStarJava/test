function fnLaunchProcess(){
	var pid=document.getElementById("hiddenProcessId").value;
	document.myform.action="./launchProcess?processId="+pid;
	document.getElementById("form_761753").submit();
}
function moveForward(tbFrom, tbTo){
	var checkFlag = true;
	var content;
	for (i = 0; i < tbFrom.options.length; i++){
		if(tbFrom.options[i].selected){
			var tbFromVal = tbFrom.options[i].value;
			opt = document.createElement("option");
            if(tbTo.options.length > 0){
            for(i = 0; i < tbTo.options.length; i++){
            		
            	opt.value = tbFromVal;
                opt.text=tbFromVal;
                document.getElementById("ToLB").appendChild(opt);
            }
		}
            else{
            	opt.value = tbFromVal;
                opt.text=tbFromVal;
                document.getElementById("ToLB").appendChild(opt);
            }
            
			break;
		}
		
	}
	
	 for(i = 0; i < tbTo.options.length; i++){
		 if(i==0){
			 
			 content= tbTo.options[i].value;
		 }
			 if(i>0){
				 
		 content = content+','+tbTo.options[i].value;
			 }
	 }
	
	 document.getElementById("hiddenProcess").value = content;
}
function removeItem(tbTo){
	var content;
	for (i = 0; i < tbTo.options.length; i++){
		if(tbTo.options[i].selected){
			document.getElementById("ToLB").removeChild(tbTo.options[i]);
		}
	}
	for(i = 0; i < tbTo.options.length; i++){
		 if(i==0){
			 
			 content= tbTo.options[i].value;
		 }
			 if(i>0){
				 
		 content = content+','+tbTo.options[i].value;
			 }
	 }
	
	 document.getElementById("hiddenProcess").value = content;
}

function editProcess(pId,pName,pDesc,lMod,cSchedule,status,cycles){
 document.getElementById("chkActive").checked=true;
 document.getElementById("textfield").value=pName;
 document.getElementById("textarea").value=pDesc;
 
 document.getElementById("scheduleTime").style.display="block";
 document.getElementById("scheduleSection").style.display="none";
 document.getElementById("scheduleTime").innerHTML = cSchedule;

 if(status == "A")
 document.getElementById("chkActive").checked=true;
 if(status == "I")
 document.getElementById("chkActive").checked=false;
 document.getElementById("hiddenProcessId").value=pId;
  while (document.getElementById("ToLB").firstChild) {
    document.getElementById("ToLB").removeChild(document.getElementById("ToLB").firstChild);
}

for(var i=0; i < cycles.split(",").length; i++)
 {
 opt = document.createElement("option");
 opt.innerHTML = cycles.split(",")[i];
  document.getElementById("ToLB").appendChild(opt);
 }
document.getElementById("editProcessId").value = "Active";
}
function changeSchedule(id){
 if(id == "d"){

 document.getElementById("daily").style.display="block";
 document.getElementById("weekly").style.display="none";
 document.getElementById("monthly").style.display="none";
 }
 if(id == "w"){

 document.getElementById("weekly").style.display="block";
 document.getElementById("daily").style.display="none";
 document.getElementById("monthly").style.display="none";
 }
 if(id == "m"){
 document.getElementById("monthly").style.display="block";
  document.getElementById("daily").style.display="none";
 document.getElementById("weekly").style.display="none";
 }
 }
 function setActiveStatus(){
	 if(document.getElementById("chkActive").checked == true){
		    document.getElementById("chkActiveHidden").value="A";
			}
		 else{
			 document.getElementById("chkActiveHidden").value="I";
		 }
 }
 function actionForward(id){
 if(id == "proSave"){
 document.forms[1].action = "./addProcess";
 document.forms[1].action = "post"; }
 if(id == proUpdate){ }
 }
 
 
 $(document).ready(function(){
	    $('input[type="button"]').click(function(){
	        var $op = $('#ToLB option:selected'),
	            $this = $(this);
	        if($op.length){
	            ($this.val() == 'Up') ? 
	                $op.first().prev().before($op) : 
	                $op.last().next().after($op);
	        }
	        var content;
	    	for(i = 0; i < document.getElementById("ToLB").options.length; i++){
	    		 if(i==0){
	    			 
	    			 content= document.getElementById("ToLB").options[i].value;
	    		 }
	    			 if(i>0){
	    				 
	    		 content = content+','+document.getElementById("ToLB").options[i].value;
	    			 }
	    	 }
	    	document.getElementById("hiddenProcess").value = content;
	    });
	    var content;
		for(i = 0; i < document.getElementById("ToLB").options.length; i++){
			 if(i==0){
				 
				 content= document.getElementById("ToLB").options[i].value;
			 }
				 if(i>0){
					 
			 content = content+','+document.getElementById("ToLB").options[i].value;
				 }
		 }
		document.getElementById("hiddenProcess").value = content;
	    document.getElementById("weekly").style.display="none";
	    document.getElementById("monthly").style.display="none";
	    document.getElementById("scheduleTime").style.display="none";
	});
function resetProcess(){
		document.getElementById("element_1").value = "";
		document.getElementById("element_2").value = "";
		
	}

function imposeMaxLength(Event, Object, MaxLen)
	{
	    return (Object.value.length <= MaxLen)||(Event.keyCode == 8 ||Event.keyCode==46||(Event.keyCode>=35&&Event.keyCode<=40));
	}
	
 function isNumberKey(evt)
	 {
	    var charCode = (evt.which) ? evt.which : event.keyCode;
	    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
	       return false;
	    
	    return true;
	 }	