function toggle(dd) {
	var ele = document.getElementById(dd);	
	if(ele.style.display == "block") {
    		ele.style.display = "none";    		
                                   	}
	else {
		ele.style.display = "block";		
	    }
       }
function popitupProcess(processId) {
	window.open("./errorMessage?processExecutionInstanceId="+processId, 'window', 'width=600,height=600');
}

function popitupCycle(cycleId) {
	window.open("./errorMessageCycle?cycleExecutionInstanceId="+cycleId, 'window', 'width=600,height=600');
}
function popitupJob(jobId) {
	window.open("./errorMessageJob?jobExecutionInstanceId="+jobId, 'window', 'width=600,height=600');
}