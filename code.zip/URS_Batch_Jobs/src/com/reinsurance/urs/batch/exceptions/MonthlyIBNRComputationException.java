package com.reinsurance.urs.batch.exceptions;

public class MonthlyIBNRComputationException extends Exception {

	private static final long serialVersionUID = 1L;
	public MonthlyIBNRComputationException() {
		super();
		
	}

	public MonthlyIBNRComputationException(String message) {
		super(message);
		
	}

}
