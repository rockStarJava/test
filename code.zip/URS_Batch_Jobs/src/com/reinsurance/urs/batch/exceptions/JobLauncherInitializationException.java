/**
 * 
 */
package com.reinsurance.urs.batch.exceptions;

/**
 * @author Lakshmi.Isukapally
 *
 */
public class JobLauncherInitializationException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JobLauncherInitializationException(String errormessage) {
		super();
		this.errormessage = errormessage;
	}

	private String errormessage ;

	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

}
