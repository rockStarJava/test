package com.reinsurance.urs.batch.exceptions;

public class JobBeanNotFoundExeception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7269127239397301121L;

	public JobBeanNotFoundExeception() {
		super();
		
	}

	
	public JobBeanNotFoundExeception(String message) {
		super(message);
		
	}

	private String errormessage ;

	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}
}
