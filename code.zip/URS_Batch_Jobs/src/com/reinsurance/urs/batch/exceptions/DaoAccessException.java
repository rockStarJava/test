package com.reinsurance.urs.batch.exceptions;

/**
 * DataAccessException
 * 
 */
public class DaoAccessException extends Exception
{
 	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     */
    public DaoAccessException(String a_message, Throwable cause)
    {
        super(a_message, cause);
     }
    
    /**
     * @param message
     */
    public DaoAccessException(String a_message)
    {
        super(a_message);
    }
	
}