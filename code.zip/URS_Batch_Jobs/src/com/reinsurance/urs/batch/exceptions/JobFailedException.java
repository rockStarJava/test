/**
 * 
 */
package com.reinsurance.urs.batch.exceptions;

/**
 * @author Lakshmi.Isukapally
 *
 */
public class JobFailedException extends Exception {
	
	
	private static final long serialVersionUID = 1L;

	public JobFailedException(String errormessage,Throwable cause) {
		 super(errormessage, cause);
	}

	    /**
	     * @param message
	     */
	    public JobFailedException(String a_message)
	    {
	        super(a_message);
	    }

}
