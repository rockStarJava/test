/**
 * 
 */
package com.reinsurance.urs.batch.exceptions;

/**
 * @author Lakshmi.Isukapally
 *
 */
public class ReportGenerationException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7908987505803590576L;
	private String errormessage ;


	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public ReportGenerationException() {
		super();
		
	}

	public ReportGenerationException(String message) {
		super(message);
		this.errormessage = message;
		
	}

}
