package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;
import java.sql.Date;

import com.reinsurance.urs.domain.accounting.accounts.AccountLoss;

public class AccountLossKey {

	private String contract = "";
	private String statutory_company = "";
	private Date experience_dte = null;
	private Date acct_dte = null;
	private Date loss_dte = null;
	private Date booked_dte = null;
	private String business_type = "";
	private String retro = null;
	private String participant = null;
	private String currency_type = "";
	private String currency = "";
	private String line_of_business = null;
	private String state = null;
	private String cat = null;
	private String utility_field_1 = "";
	private String utility_field_2 = "";
	private String utility_field_3 = "";
	private String utility_field_4 = "";
	private String utility_field_5 = "";
	private String utility_field_6 = "";
	private String invoice = "";
	private String acct_transaction = "";
	private String operator_id = "";
	private String certificate = null;
	private String broker = null;
	private String broker_sublist = null;
	private String claim = null;
	private String aggregate_payment = "";
	private String generated_flag = "";
	private BigDecimal currency_rate = null;

	public AccountLossKey() {
		super();

	}

	public AccountLossKey(AccountLoss ac) {

		this.contract = ac.getContract();
		this.statutory_company = ac.getStatutory_company();
		this.experience_dte = ac.getExperience_dte();
		this.acct_dte = ac.getAcct_dte();
		this.loss_dte = ac.getLoss_dte();
		this.booked_dte = ac.getBooked_dte();
		this.business_type = ac.getBusiness_type();
		this.retro = ac.getRetro();
		this.participant = ac.getParticipant();
		this.currency_type = ac.getCurrency_type();
		this.currency = ac.getCurrency();
		this.line_of_business = ac.getLine_of_business();
		this.state = ac.getState();
		this.cat = ac.getCat();
		this.utility_field_1 = ac.getUtility_field_1();
		this.utility_field_2 = ac.getUtility_field_2();
		this.utility_field_3 = ac.getUtility_field_3();
		this.utility_field_4 = ac.getUtility_field_4();
		this.utility_field_5 = ac.getUtility_field_5();
		this.utility_field_6 = ac.getUtility_field_6();
		this.invoice = ac.getInvoice();
		this.acct_transaction = ac.getAcct_transaction();
		this.operator_id = ac.getOperator_id();
		this.certificate = ac.getCertificate();
		this.broker = ac.getBroker();
		this.broker_sublist = ac.getBroker_sublist();
		this.claim = ac.getClaim();
		this.aggregate_payment = ac.getAggregate_payment();
		this.generated_flag = ac.getGenerated_flag();
		this.currency_rate = ac.getCurrency_rate();

	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getStatutory_company() {
		return statutory_company;
	}

	public void setStatutory_company(String statutory_company) {
		this.statutory_company = statutory_company;
	}

	public Date getExperience_dte() {
		return experience_dte;
	}

	public void setExperience_dte(Date experience_dte) {
		this.experience_dte = experience_dte;
	}

	public Date getAcct_dte() {
		return acct_dte;
	}

	public void setAcct_dte(Date acct_dte) {
		this.acct_dte = acct_dte;
	}

	public Date getLoss_dte() {
		return loss_dte;
	}

	public void setLoss_dte(Date loss_dte) {
		this.loss_dte = loss_dte;
	}

	public Date getBooked_dte() {
		return booked_dte;
	}

	public void setBooked_dte(Date booked_dte) {
		this.booked_dte = booked_dte;
	}

	public String getBusiness_type() {
		return business_type;
	}

	public void setBusiness_type(String business_type) {
		this.business_type = business_type;
	}

	public String getRetro() {
		return retro;
	}

	public void setRetro(String retro) {
		this.retro = retro;
	}

	public String getParticipant() {
		return participant;
	}

	public void setParticipant(String participant) {
		this.participant = participant;
	}

	public String getCurrency_type() {
		return currency_type;
	}

	public void setCurrency_type(String currency_type) {
		this.currency_type = currency_type;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLine_of_business() {
		return line_of_business;
	}

	public void setLine_of_business(String line_of_business) {
		this.line_of_business = line_of_business;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getUtility_field_1() {
		return utility_field_1;
	}

	public void setUtility_field_1(String utility_field_1) {
		this.utility_field_1 = utility_field_1;
	}

	public String getUtility_field_2() {
		return utility_field_2;
	}

	public void setUtility_field_2(String utility_field_2) {
		this.utility_field_2 = utility_field_2;
	}

	public String getUtility_field_3() {
		return utility_field_3;
	}

	public void setUtility_field_3(String utility_field_3) {
		this.utility_field_3 = utility_field_3;
	}

	public String getUtility_field_4() {
		return utility_field_4;
	}

	public void setUtility_field_4(String utility_field_4) {
		this.utility_field_4 = utility_field_4;
	}

	public String getUtility_field_5() {
		return utility_field_5;
	}

	public void setUtility_field_5(String utility_field_5) {
		this.utility_field_5 = utility_field_5;
	}

	public String getUtility_field_6() {
		return utility_field_6;
	}

	public void setUtility_field_6(String utility_field_6) {
		this.utility_field_6 = utility_field_6;
	}

	public String getInvoice() {
		return invoice;
	}

	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}

	public String getAcct_transaction() {
		return acct_transaction;
	}

	public void setAcct_transaction(String acct_transaction) {
		this.acct_transaction = acct_transaction;
	}

	public String getOperator_id() {
		return operator_id;
	}

	public void setOperator_id(String operator_id) {
		this.operator_id = operator_id;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getBroker() {
		return broker;
	}

	public void setBroker(String broker) {
		this.broker = broker;
	}

	public String getBroker_sublist() {
		return broker_sublist;
	}

	public void setBroker_sublist(String broker_sublist) {
		this.broker_sublist = broker_sublist;
	}

	public String getClaim() {
		return claim;
	}

	public void setClaim(String claim) {
		this.claim = claim;
	}

	public String getAggregate_payment() {
		return aggregate_payment;
	}

	public void setAggregate_payment(String aggregate_payment) {
		this.aggregate_payment = aggregate_payment;
	}

	public String getGenerated_flag() {
		return generated_flag;
	}

	public void setGenerated_flag(String generated_flag) {
		this.generated_flag = generated_flag;
	}

	public BigDecimal getCurrency_rate() {
		return currency_rate;
	}

	public void setCurrency_rate(BigDecimal currency_rate) {
		this.currency_rate = currency_rate;
	}
}
