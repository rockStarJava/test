package com.reinsurance.urs.batch.dom;


/**
 * UnderwritingIBNRAndDetailLossTransactionsData is used for generate dom object for CaluculateUnderwritingIBNRAndDetailLossTransactions
 * @author Discoverture�Solutions
 *
 */
public class UnderwritingIBNRAndDetailLossTransactionsData extends JobData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Boolean inputFinancialIbnrFlag;
	private Boolean inputUndIbnrFlag;
	/**
	 * @return the inputFinancialIbnrFlag
	 */
	public Boolean getInputFinancialIbnrFlag() {
		return inputFinancialIbnrFlag;
	}
	/**
	 * @param inputFinancialIbnrFlag the inputFinancialIbnrFlag to set
	 */
	public void setInputFinancialIbnrFlag(Boolean inputFinancialIbnrFlag) {
		this.inputFinancialIbnrFlag = inputFinancialIbnrFlag;
	}
	/**
	 * @return the inputUndIbnrFlag
	 */
	public Boolean getInputUndIbnrFlag() {
		return inputUndIbnrFlag;
	}
	/**
	 * @param inputUndIbnrFlag the inputUndIbnrFlag to set
	 */
	public void setInputUndIbnrFlag(Boolean inputUndIbnrFlag) {
		this.inputUndIbnrFlag = inputUndIbnrFlag;
	}
	

}
