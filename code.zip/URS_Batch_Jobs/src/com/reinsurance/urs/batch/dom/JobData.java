/**
 * 
 */
package com.reinsurance.urs.batch.dom;

import java.io.Serializable;

import org.slf4j.Logger;


/**
 * @author Lakshmi.Isukapally
 *
 */
public abstract class JobData implements  Serializable {
	
	/**
	 * 
	 */
	protected static final long serialVersionUID = 1L;

	private StringBuffer executionMessage = new StringBuffer();	
	
	protected Logger logger ;
		
	public void appendExecutionMessage(StringBuffer a_message) {
		executionMessage.append(a_message);
	}

	public void appendExecutionMessage(String a_message) {
		executionMessage.append(a_message);
	}
	
	public String getExecutionMessageString(){
		return executionMessage.toString();
	}
	
	public StringBuffer getExecutionMessageBuffer(){
		return executionMessage;
	}
	
	
}
