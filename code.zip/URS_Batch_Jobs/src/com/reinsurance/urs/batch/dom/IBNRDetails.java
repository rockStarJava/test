package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;
import java.util.Date;

public class IBNRDetails {
	
	private String method;
	private String company;
	private String developmentCode;
	private Date expFromDate;
	
	private String businessType;
	private String treatyNum;
	private String treatyCompany;
	private String secondaryCell;
	private BigDecimal aarPercent;
	private BigDecimal aarDeductible;
	private String aarIndicator;
	private Amounts amounts = new Amounts();
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getDevelopmentCode() {
		return developmentCode;
	}
	public void setDevelopmentCode(String developmentCode) {
		this.developmentCode = developmentCode;
	}
	public Date getExpFromDate() {
		return expFromDate;
	}
	public void setExpFromDate(Date expFromDate) {
		this.expFromDate = expFromDate;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getTreatyNum() {
		return treatyNum;
	}
	public void setTreatyNum(String treatyNum) {
		this.treatyNum = treatyNum;
	}
	public String getTreatyCompany() {
		return treatyCompany;
	}
	public void setTreatyCompany(String treatyCompany) {
		this.treatyCompany = treatyCompany;
	}
	public String getSecondaryCell() {
		return secondaryCell;
	}
	public void setSecondaryCell(String secondaryCell) {
		this.secondaryCell = secondaryCell;
	}
	public BigDecimal getAarPercent() {
		return aarPercent;
	}
	public void setAarPercent(BigDecimal aarPercent) {
		this.aarPercent = aarPercent;
	}
	public BigDecimal getAarDeductible() {
		return aarDeductible;
	}
	public void setAarDeductible(BigDecimal aarDeductible) {
		this.aarDeductible = aarDeductible;
	}
	public String getAarIndicator() {
		return aarIndicator;
	}
	public void setAarIndicator(String aarIndicator) {
		this.aarIndicator = aarIndicator;
	}
	public Amounts getAmounts() {
		return amounts;
	}
	public void setAmounts(Amounts amounts) {
		this.amounts = amounts;
	}
	public boolean isSameKey(IBNRDetails l_Details) {
		
		if ( (company!=null && company.equals(l_Details.getCompany()))
				&& (developmentCode!=null && developmentCode.equals(l_Details.getDevelopmentCode()))
				&& (expFromDate!=null && expFromDate.equals(l_Details.getExpFromDate()))
				&& (businessType!=null && businessType.equals(l_Details.getBusinessType()))
				&& (treatyNum!=null && treatyNum.equals(l_Details.getTreatyNum()))
				&& (treatyCompany!=null && treatyCompany.equals(l_Details.getTreatyCompany()))
				)
			return true;
		
	return false;
				
	}


}
