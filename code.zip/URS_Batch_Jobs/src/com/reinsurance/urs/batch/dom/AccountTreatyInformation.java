package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;
import java.sql.Date;

public class AccountTreatyInformation {
	private String      contract                 = "";
	private String      statutory_company        = "";
	private Date        experience_beg_dte       = null;
	private Date        experience_end_dte       = null;
	private BigDecimal ibnrTotal = new BigDecimal(0);
	private BigDecimal ibnrChange = new BigDecimal(0);
	private BigDecimal underwritingIbnr= new BigDecimal(0);
	
	public AccountTreatyInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountTreatyInformation(String contract, String statutory_company,
			Date experience_beg_dte, Date experience_end_dte) {
		super();
		this.contract = contract;
		this.statutory_company = statutory_company;
		this.experience_beg_dte = experience_beg_dte;
		this.experience_end_dte = experience_end_dte;
		this.ibnrTotal = new BigDecimal(0);
		this.ibnrChange = new BigDecimal(0);
		this.underwritingIbnr= new BigDecimal(0);
		
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	public String getStatutory_company() {
		return statutory_company;
	}
	public void setStatutory_company(String statutory_company) {
		this.statutory_company = statutory_company;
	}
	public Date getExperience_beg_dte() {
		return experience_beg_dte;
	}
	public void setExperience_beg_dte(Date experience_beg_dte) {
		this.experience_beg_dte = experience_beg_dte;
	}
	public Date getExperience_end_dte() {
		return experience_end_dte;
	}
	public void setExperience_end_dte(Date experience_end_dte) {
		this.experience_end_dte = experience_end_dte;
	}
	public BigDecimal getIbnrTotal() {
		return ibnrTotal;
	}
	public void setIbnrTotal(BigDecimal ibnrTotal) {
		this.ibnrTotal = ibnrTotal;
	}
	public BigDecimal getIbnrChange() {
		return ibnrChange;
	}
	public void setIbnrChange(BigDecimal ibnrChange) {
		this.ibnrChange = ibnrChange;
	}
	public BigDecimal getUnderwritingIbnr() {
		return underwritingIbnr;
	}
	public void setUnderwritingIbnr(BigDecimal underwritingIbnr) {
		this.underwritingIbnr = underwritingIbnr;
	}


}
