package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import com.reinsurance.urs.domain.sdmaint.Broker;
import com.reinsurance.urs.domain.sdmaint.Company;
import com.reinsurance.urs.domain.sdmaint.Participant;
import com.reinsurance.urs.domain.sdmaint.ParticipantList;
import com.reinsurance.urs.domain.sdmaint.WorldWideZone;
import com.reinsurance.urs.domain.sysadmin.DateCard;
import com.reinsurance.urs.domain.sysadmin.SystemDefaults;
import com.reinsurance.urs.domain.sysadmin.UtilityField;
/**
 * FederalExerciseExtractUpdatesData is used for generate dom object for UpdateRecievableOrRecoverablesWithFederalExerciseTaxExtract
 * @author Discoverture�Solutions
 *
 */
public class FederalExerciseExtractUpdatesData extends JobData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7568220724962136422L;
	private Date fromDate = null;    
	private Date thruDate = null;
	private BigDecimal fromControlNum = null;
	private BigDecimal thruControlNum  = null;
	private BigDecimal writtenPremium = null;
	private BigDecimal taxRate = new BigDecimal(0);
	private Date bookingDate = null;
	private Participant participant = null;
	private ParticipantList participantList = null;
	private List<Participant> participantRecList = null;
	private List<UtilityField> utilityFieldProxieList=null;
	private Broker broker = null;
	private Company reinsuranceCoDetail = null;
	private WorldWideZone worldWideZone = null;
	private SystemDefaults systemDefaults=null;
	private Date tempDateCardTimeStamp=null;
	private BigDecimal controlNum=null;
	private DateCard dateCard = null;
	private int recordsWritten = 0;
	private int miscRecordsWritten = 0;
	private int controlRecordsUpdated = 0;
	private int controlRecordsAdded = 0;
	private int recoverableRecordsInserted = 0;
	private int recoverableRecordsUpdated = 0;
	private int receivablesRecordsInserted = 0;
	private int receivablesRecordsUpdated = 0;
	private String dailyMonthlyInd=null;
	private Date dailyFromDate=null;
	private Date monthlyFromDate=null;
	private Date dailyThruDate=null;
	private Date monthlyThruDate=null;
	private boolean processed = false;
	/**
	 * @return the reinsuranceCoDetail
	 */
	public Company getReinsuranceCoDetail() {
		return reinsuranceCoDetail;
	}
	/**
	 * @return the worldWideZone
	 */
	public WorldWideZone getWorldWideZone() {
		return worldWideZone;
	}
	/**
	 * @param worldWideZone the worldWideZone to set
	 */
	public void setWorldWideZone(WorldWideZone worldWideZone) {
		this.worldWideZone = worldWideZone;
	}
	/**
	 * @param reinsuranceCoDetail the reinsuranceCoDetail to set
	 */
	public void setReinsuranceCoDetail(Company reinsuranceCoDetail) {
		this.reinsuranceCoDetail = reinsuranceCoDetail;
	}
	/**
	 * @return the broker
	 */
	public Broker getBroker() {
		return broker;
	}
	/**
	 * @param broker the broker to set
	 */
	public void setBroker(Broker broker) {
		this.broker = broker;
	}
	
	/**
	 * @return the participantRecList
	 */
	public List<Participant> getParticipantRecList() {
		return participantRecList;
	}
	/**
	 * @param participantRecList the participantRecList to set
	 */
	public void setParticipantRecList(List<Participant> participantRecList) {
		this.participantRecList = participantRecList;
	}
	/**
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return the thruDate
	 */
	public Date getThruDate() {
		return thruDate;
	}
	/**
	 * @param thruDate the thruDate to set
	 */
	public void setThruDate(Date thruDate) {
		this.thruDate = thruDate;
	}
	/**
	 * @return the fromControlNum
	 */
	public BigDecimal getFromControlNum() {
		return fromControlNum;
	}
	/**
	 * @param fromControlNum the fromControlNum to set
	 */
	public void setFromControlNum(BigDecimal fromControlNum) {
		this.fromControlNum = fromControlNum;
	}
	/**
	 * @return the thruControlNum
	 */
	public BigDecimal getThruControlNum() {
		return thruControlNum;
	}
	/**
	 * @param thruControlNum the thruControlNum to set
	 */
	public void setThruControlNum(BigDecimal thruControlNum) {
		this.thruControlNum = thruControlNum;
	}
	/**
	 * @return the writtenPremium
	 */
	public BigDecimal getWrittenPremium() {
		return writtenPremium;
	}
	/**
	 * @param writtenPremium the writtenPremium to set
	 */
	public void setWrittenPremium(BigDecimal writtenPremium) {
		this.writtenPremium = writtenPremium;
	}
	/**
	 * @return the bookingDate
	 */
	public Date getBookingDate() {
		return bookingDate;
	}
	/**
	 * @param bookingDate the bookingDate to set
	 */
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	/**
	 * @return the participant
	 */
	public Participant getParticipant() {
		return participant;
	}
	/**
	 * @param participant the participant to set
	 */
	public void setParticipant(Participant participant) {
		this.participant = participant;
	}
	/**
	 * @return the participantList
	 */
	public ParticipantList getParticipantList() {
		return participantList;
	}
	/**
	 * @param participantList the participantList to set
	 */
	public void setParticipantList(ParticipantList participantList) {
		this.participantList = participantList;
	}
	/**
	 * @return the taxRate
	 */
	public BigDecimal getTaxRate() {
		return taxRate;
	}
	/**
	 * @param taxRate the taxRate to set
	 */
	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}
	/**
	 * @return the utilityFieldProxieList
	 */
	public List<UtilityField> getUtilityFieldProxieList() {
		return utilityFieldProxieList;
	}
	/**
	 * @param utilityFieldProxieList the utilityFieldProxieList to set
	 */
	public void setUtilityFieldProxieList(
			List<UtilityField> utilityFieldProxieList) {
		this.utilityFieldProxieList = utilityFieldProxieList;
	}
	/**
	 * @return the systemDefaults
	 */
	public SystemDefaults getSystemDefaults() {
		return systemDefaults;
	}
	/**
	 * @param systemDefaults the systemDefaults to set
	 */
	public void setSystemDefaults(SystemDefaults systemDefaults) {
		this.systemDefaults = systemDefaults;
	}
	
	/**
	 * @return the tempDateCardTimeStamp
	 */
	public Date getTempDateCardTimeStamp() {
		return tempDateCardTimeStamp;
	}
	/**
	 * @param tempDateCardTimeStamp the tempDateCardTimeStamp to set
	 */
	public void setTempDateCardTimeStamp(Date tempDateCardTimeStamp) {
		this.tempDateCardTimeStamp = tempDateCardTimeStamp;
	}
	/**
	 * @return the controlNum
	 */
	public BigDecimal getControlNum() {
		return controlNum;
	}
	/**
	 * @param controlNum the controlNum to set
	 */
	public void setControlNum(BigDecimal controlNum) {
		this.controlNum = controlNum;
	}
	/**
	 * @return the dateCard
	 */
	public DateCard getDateCard() {
		return dateCard;
	}
	/**
	 * @param dateCard the dateCard to set
	 */
	public void setDateCard(DateCard dateCard) {
		this.dateCard = dateCard;
	}
	/**
	 * @return the recordsWritten
	 */
	public int getRecordsWritten() {
		return recordsWritten;
	}
	/**
	 * @param recordsWritten the recordsWritten to set
	 */
	public void setRecordsWritten(int recordsWritten) {
		this.recordsWritten = recordsWritten;
	}
	/**
	 * @return the miscRecordsWritten
	 */
	public int getMiscRecordsWritten() {
		return miscRecordsWritten;
	}
	/**
	 * @param miscRecordsWritten the miscRecordsWritten to set
	 */
	public void setMiscRecordsWritten(int miscRecordsWritten) {
		this.miscRecordsWritten = miscRecordsWritten;
	}
	/**
	 * @return the controlRecordsUpdated
	 */
	public int getControlRecordsUpdated() {
		return controlRecordsUpdated;
	}
	/**
	 * @param controlRecordsUpdated the controlRecordsUpdated to set
	 */
	public void setControlRecordsUpdated(int controlRecordsUpdated) {
		this.controlRecordsUpdated = controlRecordsUpdated;
	}
	/**
	 * @return the controlRecordsAdded
	 */
	public int getControlRecordsAdded() {
		return controlRecordsAdded;
	}
	/**
	 * @param controlRecordsAdded the controlRecordsAdded to set
	 */
	public void setControlRecordsAdded(int controlRecordsAdded) {
		this.controlRecordsAdded = controlRecordsAdded;
	}
	/**
	 * @return the recoverableRecordsInserted
	 */
	public int getRecoverableRecordsInserted() {
		return recoverableRecordsInserted;
	}
	/**
	 * @param recoverableRecordsInserted the recoverableRecordsInserted to set
	 */
	public void setRecoverableRecordsInserted(int recoverableRecordsInserted) {
		this.recoverableRecordsInserted = recoverableRecordsInserted;
	}
	/**
	 * @return the recoverableRecordsUpdated
	 */
	public int getRecoverableRecordsUpdated() {
		return recoverableRecordsUpdated;
	}
	/**
	 * @param recoverableRecordsUpdated the recoverableRecordsUpdated to set
	 */
	public void setRecoverableRecordsUpdated(int recoverableRecordsUpdated) {
		this.recoverableRecordsUpdated = recoverableRecordsUpdated;
	}
	/**
	 * @return the receivablesRecordsInserted
	 */
	public int getReceivablesRecordsInserted() {
		return receivablesRecordsInserted;
	}
	/**
	 * @param receivablesRecordsInserted the receivablesRecordsInserted to set
	 */
	public void setReceivablesRecordsInserted(int receivablesRecordsInserted) {
		this.receivablesRecordsInserted = receivablesRecordsInserted;
	}
	/**
	 * @return the receivablesRecordsUpdated
	 */
	public int getReceivablesRecordsUpdated() {
		return receivablesRecordsUpdated;
	}
	/**
	 * @param receivablesRecordsUpdated the receivablesRecordsUpdated to set
	 */
	public void setReceivablesRecordsUpdated(int receivablesRecordsUpdated) {
		this.receivablesRecordsUpdated = receivablesRecordsUpdated;
	}
	/**
	 * @return the dailyMonthlyInd
	 */
	public String getDailyMonthlyInd() {
		return dailyMonthlyInd;
	}
	/**
	 * @param dailyMonthlyInd the dailyMonthlyInd to set
	 */
	public void setDailyMonthlyInd(String dailyMonthlyInd) {
		this.dailyMonthlyInd = dailyMonthlyInd;
	}
	/**
	 * @return the dailyFromDate
	 */
	public Date getDailyFromDate() {
		return dailyFromDate;
	}
	/**
	 * @param dailyFromDate the dailyFromDate to set
	 */
	public void setDailyFromDate(Date dailyFromDate) {
		this.dailyFromDate = dailyFromDate;
	}
	/**
	 * @return the monthlyFromDate
	 */
	public Date getMonthlyFromDate() {
		return monthlyFromDate;
	}
	/**
	 * @param monthlyFromDate the monthlyFromDate to set
	 */
	public void setMonthlyFromDate(Date monthlyFromDate) {
		this.monthlyFromDate = monthlyFromDate;
	}
	/**
	 * @return the dailyThruDate
	 */
	public Date getDailyThruDate() {
		return dailyThruDate;
	}
	/**
	 * @param dailyThruDate the dailyThruDate to set
	 */
	public void setDailyThruDate(Date dailyThruDate) {
		this.dailyThruDate = dailyThruDate;
	}
	/**
	 * @return the monthlyThruDate
	 */
	public Date getMonthlyThruDate() {
		return monthlyThruDate;
	}
	/**
	 * @param monthlyThruDate the monthlyThruDate to set
	 */
	public void setMonthlyThruDate(Date monthlyThruDate) {
		this.monthlyThruDate = monthlyThruDate;
	}
	
	public boolean isProcessed() {
		return processed;
	}
	public void setProcessed(boolean processed) {
		this.processed = processed;
	}
	
	
}
