package com.reinsurance.urs.batch.dom;
/**
 * FlatFileTRF204 is used for generate dom object for CaluculateUnderwritingIBNRAndDetailLossTransactions
 * @author Discoverture�Solutions
 *
 */
public class CustomTICCPremInputs {
	String ticcPremLoss="l";
	String ticcCompany="";
	String ticcInput="";
	String ticcOutput="";
	
	/**
	 * @return the ticcPremLoss
	 */
	public String getTiccPremLoss() {
		return ticcPremLoss;
	}
	/**
	 * @param ticcPremLoss the ticcPremLoss to set
	 */
	public void setTiccPremLoss(String ticcPremLoss) {
		this.ticcPremLoss = ticcPremLoss;
	}
	/**
	 * @return the ticcCompany
	 */
	public String getTiccCompany() {
		return ticcCompany;
	}
	/**
	 * @param ticcCompany the ticcCompany to set
	 */
	public void setTiccCompany(String ticcCompany) {
		this.ticcCompany = ticcCompany;
	}
	/**
	 * @return the ticcInput
	 */
	public String getTiccInput() {
		return ticcInput;
	}
	/**
	 * @param ticcInput the ticcInput to set
	 */
	public void setTiccInput(String ticcInput) {
		this.ticcInput = ticcInput;
	}
	/**
	 * @return the ticcOutput
	 */
	public String getTiccOutput() {
		return ticcOutput;
	}
	/**
	 * @param ticcOutput the ticcOutput to set
	 */
	public void setTiccOutput(String ticcOutput) {
		this.ticcOutput = ticcOutput;
	}
	
}
