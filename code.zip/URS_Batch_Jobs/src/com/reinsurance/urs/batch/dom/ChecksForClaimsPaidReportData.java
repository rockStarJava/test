package com.reinsurance.urs.batch.dom;

import java.util.ArrayList;
import java.util.List;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;

import com.reinsurance.urs.domain.accounting.cash.CheckDetail;

public class ChecksForClaimsPaidReportData extends JobData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6721598120497469932L;

	private StringBuffer flatFileContent = new StringBuffer("");

	private List<CheckDetail> listCheckDetail = null;

	private List<JasperReportBuilder> listJReports = new ArrayList<JasperReportBuilder>();

	public StringBuffer getFlatFileContent() {
		return flatFileContent;
	}

	public List<CheckDetail> getListCheckDetail() {
		return listCheckDetail;
	}

	public List<JasperReportBuilder> getListJReports() {
		return listJReports;
	}

	public void setFlatFileContent(StringBuffer flatFileContent) {
		this.flatFileContent = flatFileContent;
	}

	public void setListCheckDetail(List<CheckDetail> listCheckDetail) {
		this.listCheckDetail = listCheckDetail;
	}

	public void setListJReports(List<JasperReportBuilder> listJReports) {
		this.listJReports = listJReports;
	}

}
