package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;

/**
 * UtilDepositePremiumData is used for generate dom object for GenerateDepositPremiums
 * @author Discoverture�Solutions
 *
 */
public class UtilDepositePremiumData extends JobData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8639973644332355819L;
	private BigDecimal utilSubject;
	private BigDecimal lastSubject;
	private BigDecimal utilWritten;
	private BigDecimal lastWritten;
	private BigDecimal utilCommission;
	private BigDecimal lastCommission;
	private BigDecimal utilOverride;
	private BigDecimal lastOverride;
	private BigDecimal utilBrokerage;
	private BigDecimal lastBrokerage;
	/**
	 * @return the utilSubject
	 */
	public BigDecimal getUtilSubject() {
		return utilSubject;
	}
	/**
	 * @param utilSubject the utilSubject to set
	 */
	public void setUtilSubject(BigDecimal utilSubject) {
		this.utilSubject = utilSubject;
	}
	/**
	 * @return the lastSubject
	 */
	public BigDecimal getLastSubject() {
		return lastSubject;
	}
	/**
	 * @param lastSubject the lastSubject to set
	 */
	public void setLastSubject(BigDecimal lastSubject) {
		this.lastSubject = lastSubject;
	}
	/**
	 * @return the utilWritten
	 */
	public BigDecimal getUtilWritten() {
		return utilWritten;
	}
	/**
	 * @param utilWritten the utilWritten to set
	 */
	public void setUtilWritten(BigDecimal utilWritten) {
		this.utilWritten = utilWritten;
	}
	/**
	 * @return the lastWritten
	 */
	public BigDecimal getLastWritten() {
		return lastWritten;
	}
	/**
	 * @param lastWritten the lastWritten to set
	 */
	public void setLastWritten(BigDecimal lastWritten) {
		this.lastWritten = lastWritten;
	}
	/**
	 * @return the utilCommission
	 */
	public BigDecimal getUtilCommission() {
		return utilCommission;
	}
	/**
	 * @param utilCommission the utilCommission to set
	 */
	public void setUtilCommission(BigDecimal utilCommission) {
		this.utilCommission = utilCommission;
	}
	/**
	 * @return the lastCommission
	 */
	public BigDecimal getLastCommission() {
		return lastCommission;
	}
	/**
	 * @param lastCommission the lastCommission to set
	 */
	public void setLastCommission(BigDecimal lastCommission) {
		this.lastCommission = lastCommission;
	}
	/**
	 * @return the utilOverride
	 */
	public BigDecimal getUtilOverride() {
		return utilOverride;
	}
	/**
	 * @param utilOverride the utilOverride to set
	 */
	public void setUtilOverride(BigDecimal utilOverride) {
		this.utilOverride = utilOverride;
	}
	/**
	 * @return the lastOverride
	 */
	public BigDecimal getLastOverride() {
		return lastOverride;
	}
	/**
	 * @param lastOverride the lastOverride to set
	 */
	public void setLastOverride(BigDecimal lastOverride) {
		this.lastOverride = lastOverride;
	}
	/**
	 * @return the utilBrokerage
	 */
	public BigDecimal getUtilBrokerage() {
		return utilBrokerage;
	}
	/**
	 * @param utilBrokerage the utilBrokerage to set
	 */
	public void setUtilBrokerage(BigDecimal utilBrokerage) {
		this.utilBrokerage = utilBrokerage;
	}
	/**
	 * @return the lastBrokerage
	 */
	public BigDecimal getLastBrokerage() {
		return lastBrokerage;
	}
	/**
	 * @param lastBrokerage the lastBrokerage to set
	 */
	public void setLastBrokerage(BigDecimal lastBrokerage) {
		this.lastBrokerage = lastBrokerage;
	}
	
	
}
