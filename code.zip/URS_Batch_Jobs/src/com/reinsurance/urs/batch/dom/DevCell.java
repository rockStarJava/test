package com.reinsurance.urs.batch.dom;

public class DevCell implements java.io.Serializable{

	/**
	 * DevCell is used for generate dom object for CaluculateUnderwritingIBNRAndDetailLossTransactions
	 * @author Discoverture�Solutions
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String statuatoryCompany;
	private String inCell;
	private String outCell;
	
	
	public DevCell() {
		super();
	}
	public DevCell(String statuatoryCompany, String inCell, String outCell) {
		super();
		this.statuatoryCompany = statuatoryCompany;
		this.inCell = inCell;
		this.outCell = outCell;
	}
	/**
	 * @return the statuatoryCompany
	 */
	public String getStatuatoryCompany() {
		return statuatoryCompany;
	}
	/**
	 * @param statuatoryCompany the statuatoryCompany to set
	 */
	public void setStatuatoryCompany(String statuatoryCompany) {
		this.statuatoryCompany = statuatoryCompany;
	}
	/**
	 * @return the inCell
	 */
	public String getInCell() {
		return inCell;
	}
	/**
	 * @param inCell the inCell to set
	 */
	public void setInCell(String inCell) {
		this.inCell = inCell;
	}
	/**
	 * @return the outCell
	 */
	public String getOutCell() {
		return outCell;
	}
	/**
	 * @param outCell the outCell to set
	 */
	public void setOutCell(String outCell) {
		this.outCell = outCell;
	}
	
	
}
