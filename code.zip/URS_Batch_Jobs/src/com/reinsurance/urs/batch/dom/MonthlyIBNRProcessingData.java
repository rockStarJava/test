package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;

public class MonthlyIBNRProcessingData extends JobData {
	
	private static final long serialVersionUID = 7223832575992204179L;
	private java.sql.Date monthlyBookedDate;
	private BigDecimal controlNum;
	private long processExecutionInstanceId;
	private long counter;
		
	public java.sql.Date getMonthlyBookedDate() {
		return monthlyBookedDate;
	}
	public void setMonthlyBookedDate(java.sql.Date monthlyBookedDate) {
		this.monthlyBookedDate = monthlyBookedDate;
	}
	public BigDecimal getControlNum() {
		return controlNum;
	}
	public void setControlNum(BigDecimal controlNum) {
		this.controlNum = controlNum;
	}
	public long getProcessExecutionInstanceId() {
		return processExecutionInstanceId;
	}
	public void setProcessExecutionInstanceId(long processExecutionInstanceId) {
		this.processExecutionInstanceId = processExecutionInstanceId;
	}
	public long getCounter() {
		return counter;
	}
	public void setCounter(long counter) {
		this.counter = counter;
	}
	public void incrementControlNum()
	{
		this.controlNum.add(new BigDecimal(1));
		
	}
	
}
