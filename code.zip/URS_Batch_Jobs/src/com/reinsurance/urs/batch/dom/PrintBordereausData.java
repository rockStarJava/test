package com.reinsurance.urs.batch.dom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import net.sf.dynamicreports.report.datasource.DRDataSource;

import com.reinsurance.urs.domain.accounting.balmaint.BordereauPrintJournal;

/**
 * ClaimsPaid id the dom object for PrintBordereausReport.java
 * 
 * @author Discoverture Solutions
 * 
 */
public class PrintBordereausData extends JobData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7818574760464458106L;
	private String treatyNum = "";
	private String treatyCompany = "";
	private String contract = "";
	private String statCompant = "";
	private String claim = "";
	private String chkMemo ;
	private String OperId ;
	private BigDecimal inputControlNum;
	private Date begDate; 
	private Date endDate;
	private List<DRDataSource> reportData = null;

	public List<DRDataSource> getReportData() {
		return reportData;
	}

	public void setReportData(List<DRDataSource> reportData) {
		this.reportData = reportData;
	}

	List<BordereauPrintJournal> headerDetailList = new ArrayList<BordereauPrintJournal>();


	/**
	 * @return the treatyNum
	 */
	public String getTreatyNum() {
		return treatyNum;
	}

	/**
	 * @param treatyNum
	 *            the treatyNum to set
	 */
	public void setTreatyNum(String treatyNum) {
		this.treatyNum = treatyNum;
	}

	/**
	 * @return the treatyCompany
	 */
	public String getTreatyCompany() {
		return treatyCompany;
	}

	/**
	 * @param treatyCompany
	 *            the treatyCompany to set
	 */
	public void setTreatyCompany(String treatyCompany) {
		this.treatyCompany = treatyCompany;
	}

	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}

	/**
	 * @param contract
	 *            the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}

	/**
	 * @return the statCompant
	 */
	public String getStatCompant() {
		return statCompant;
	}

	/**
	 * @param statCompant
	 *            the statCompant to set
	 */
	public void setStatCompant(String statCompant) {
		this.statCompant = statCompant;
	}

	/**
	 * @return the claim
	 */
	public String getClaim() {
		return claim;
	}

	/**
	 * @param claim
	 *            the claim to set
	 */
	public void setClaim(String claim) {
		this.claim = claim;
	}

	/**
	 * @return the headerDetailList
	 */
	public List<BordereauPrintJournal> getHeaderDetailList() {
		return headerDetailList;
	}

	/**
	 * @param headerDetailList
	 *            the headerDetailList to set
	 */
	public void setHeaderDetailList(List<BordereauPrintJournal> headerDetailList) {
		this.headerDetailList = headerDetailList;
	}

	public String getChkMemo() {
		return chkMemo;
	}

	public void setChkMemo(String chkMemo) {
		this.chkMemo = chkMemo;
	}

	public String getOperId() {
		return OperId;
	}

	public void setOperId(String operId) {
		OperId = operId;
	}

	public BigDecimal getInputControlNum() {
		return inputControlNum;
	}

	public void setInputControlNum(BigDecimal inputControlNum) {
		this.inputControlNum = inputControlNum;
	}

	public Date getBegDate() {
		return begDate;
	}

	public void setBegDate(Date begDate) {
		this.begDate = begDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
