
package com.reinsurance.urs.batch.dom;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.reinsurance.urs.domain.accounting.accounts.AccountPremium;

/**
 * CalculateRetrospectivePremiumAndUpdateAccountsData is used for generate dom object for CalculateRetrospectivePremiumAndUpdateAccounts
 * @author Discoverture�Solutions
 *
 */
public class CalculateRetrospectivePremiumAndUpdateAccountsData extends JobData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String storeTreatyNum = "";           
	private String storeTreatyCcompany = "";     
	private String storeRatingIndicator = "";
	private String holdExpPer = "" ;    
	private String retroPriority = "";
	
	private BigDecimal storeSubjectPrem = new BigDecimal(0);
	private BigDecimal storeEarnedPrem = new BigDecimal(0);
	private BigDecimal storeCommission = new BigDecimal(0);
	private BigDecimal totalPremium = new BigDecimal(0);    
	private BigDecimal totalIncurred = new BigDecimal(0);
	
	private BigDecimal particantPercentage = new BigDecimal(0);
	private BigDecimal margin = new BigDecimal(0);
	private BigDecimal storedIncurredLoss = new BigDecimal(0);
	private BigDecimal developedPremium = new BigDecimal(0);
	private BigDecimal holdAmount = new BigDecimal(0);
	private BigDecimal minimum = new BigDecimal(0);
	private BigDecimal maximum = new BigDecimal(0);
	private BigDecimal storeAmounts = new BigDecimal(0);                            
	                           
	private BigDecimal totalRetroChange = new BigDecimal(0);  
	private BigDecimal proRatePercent = new BigDecimal(0);
	private BigDecimal proRatePercentRound = new BigDecimal(0);
	private BigDecimal holdRetro = new BigDecimal(0);
	private BigDecimal holdPercent = new BigDecimal(0);
	private BigDecimal retroToal = new BigDecimal(0);
	private BigDecimal cededRetroTotal  = new BigDecimal(0);
	
	private Date holdRatingPeriodBeg = null;
	private Date holdRatingPeriodEnd = null;
	private Date monthlyBookedDate= null;
	private List<AccountPremium> workFileList = new ArrayList<AccountPremium>();
	private int workRecords = 0;
	private int premRecordsAdded =0;
	private int cntrRecordsAdded =0;
	private int cntrRecordsUpdated = 0;
	private int premRecordsUpdated=0;
	
	
	
 	/**
	 * @return the storeTreatyNum
	 */
	public String getStoreTreatyNum() {
		return storeTreatyNum;
	}

	/**
	 * @param storeTreatyNum the storeTreatyNum to set
	 */
	public void setStoreTreatyNum(String storeTreatyNum) {
		this.storeTreatyNum = storeTreatyNum;
	}

	/**
	 * @return the storeTreatyCcompany
	 */
	public String getStoreTreatyCcompany() {
		return storeTreatyCcompany;
	}

	/**
	 * @param storeTreatyCcompany the storeTreatyCcompany to set
	 */
	public void setStoreTreatyCcompany(String storeTreatyCcompany) {
		this.storeTreatyCcompany = storeTreatyCcompany;
	}

	/**
	 * @return the storeRatingIndicator
	 */
	public String getStoreRatingIndicator() {
		return storeRatingIndicator;
	}

	/**
	 * @param storeRatingIndicator the storeRatingIndicator to set
	 */
	public void setStoreRatingIndicator(String storeRatingIndicator) {
		this.storeRatingIndicator = storeRatingIndicator;
	}

	/**
	 * @return the holdExpPer
	 */
	public String getHoldExpPer() {
		return holdExpPer;
	}

	/**
	 * @param holdExpPer the holdExpPer to set
	 */
	public void setHoldExpPer(String holdExpPer) {
		this.holdExpPer = holdExpPer;
	}

	/**
	 * @return the retroPriority
	 */
	public String getRetroPriority() {
		return retroPriority;
	}

	/**
	 * @param retroPriority the retroPriority to set
	 */
	public void setRetroPriority(String retroPriority) {
		this.retroPriority = retroPriority;
	}

	/**
	 * @return the storeSubjectPrem
	 */
	public BigDecimal getStoreSubjectPrem() {
		return storeSubjectPrem;
	}

	/**
	 * @param storeSubjectPrem the storeSubjectPrem to set
	 */
	public void setStoreSubjectPrem(BigDecimal storeSubjectPrem) {
		this.storeSubjectPrem = storeSubjectPrem;
	}

	/**
	 * @return the storeEarnedPrem
	 */
	public BigDecimal getStoreEarnedPrem() {
		return storeEarnedPrem;
	}

	/**
	 * @param storeEarnedPrem the storeEarnedPrem to set
	 */
	public void setStoreEarnedPrem(BigDecimal storeEarnedPrem) {
		this.storeEarnedPrem = storeEarnedPrem;
	}

	/**
	 * @return the storeCommission
	 */
	public BigDecimal getStoreCommission() {
		return storeCommission;
	}

	/**
	 * @param storeCommission the storeCommission to set
	 */
	public void setStoreCommission(BigDecimal storeCommission) {
		this.storeCommission = storeCommission;
	}

	/**
	 * @return the totalPremium
	 */
	public BigDecimal getTotalPremium() {
		return totalPremium;
	}

	/**
	 * @param totalPremium the totalPremium to set
	 */
	public void setTotalPremium(BigDecimal totalPremium) {
		this.totalPremium = totalPremium;
	}

	/**
	 * @return the totalIncurred
	 */
	public BigDecimal getTotalIncurred() {
		return totalIncurred;
	}

	/**
	 * @param totalIncurred the totalIncurred to set
	 */
	public void setTotalIncurred(BigDecimal totalIncurred) {
		this.totalIncurred = totalIncurred;
	}

	/**
	 * @return the particantPercentage
	 */
	public BigDecimal getParticantPercentage() {
		return particantPercentage;
	}

	/**
	 * @param particantPercentage the particantPercentage to set
	 */
	public void setParticantPercentage(BigDecimal particantPercentage) {
		this.particantPercentage = particantPercentage;
	}

	/**
	 * @return the margin
	 */
	public BigDecimal getMargin() {
		return margin;
	}

	/**
	 * @param margin the margin to set
	 */
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	/**
	 * @return the storedIncurredLoss
	 */
	public BigDecimal getStoredIncurredLoss() {
		return storedIncurredLoss;
	}

	/**
	 * @param storedIncurredLoss the storedIncurredLoss to set
	 */
	public void setStoredIncurredLoss(BigDecimal storedIncurredLoss) {
		this.storedIncurredLoss = storedIncurredLoss;
	}

	/**
	 * @return the developedPremium
	 */
	public BigDecimal getDevelopedPremium() {
		return developedPremium;
	}

	/**
	 * @param developedPremium the developedPremium to set
	 */
	public void setDevelopedPremium(BigDecimal developedPremium) {
		this.developedPremium = developedPremium;
	}

	/**
	 * @return the holdAmount
	 */
	public BigDecimal getHoldAmount() {
		return holdAmount;
	}

	/**
	 * @param holdAmount the holdAmount to set
	 */
	public void setHoldAmount(BigDecimal holdAmount) {
		this.holdAmount = holdAmount;
	}

	/**
	 * @return the minimum
	 */
	public BigDecimal getMinimum() {
		return minimum;
	}

	/**
	 * @param minimum the minimum to set
	 */
	public void setMinimum(BigDecimal minimum) {
		this.minimum = minimum;
	}

	/**
	 * @return the maximum
	 */
	public BigDecimal getMaximum() {
		return maximum;
	}

	/**
	 * @param maximum the maximum to set
	 */
	public void setMaximum(BigDecimal maximum) {
		this.maximum = maximum;
	}

	/**
	 * @return the storeAmounts
	 */
	public BigDecimal getStoreAmounts() {
		return storeAmounts;
	}

	/**
	 * @param storeAmounts the storeAmounts to set
	 */
	public void setStoreAmounts(BigDecimal storeAmounts) {
		this.storeAmounts = storeAmounts;
	}

	/**
	 * @return the totalRetroChange
	 */
	public BigDecimal getTotalRetroChange() {
		return totalRetroChange;
	}

	/**
	 * @param totalRetroChange the totalRetroChange to set
	 */
	public void setTotalRetroChange(BigDecimal totalRetroChange) {
		this.totalRetroChange = totalRetroChange;
	}

	/**
	 * @return the proRatePercent
	 */
	public BigDecimal getProRatePercent() {
		return proRatePercent;
	}

	/**
	 * @param proRatePercent the proRatePercent to set
	 */
	public void setProRatePercent(BigDecimal proRatePercent) {
		this.proRatePercent = proRatePercent;
	}

	/**
	 * @return the proRatePercentRound
	 */
	public BigDecimal getProRatePercentRound() {
		return proRatePercentRound;
	}

	/**
	 * @param proRatePercentRound the proRatePercentRound to set
	 */
	public void setProRatePercentRound(BigDecimal proRatePercentRound) {
		this.proRatePercentRound = proRatePercentRound;
	}

	/**
	 * @return the holdRetro
	 */
	public BigDecimal getHoldRetro() {
		return holdRetro;
	}

	/**
	 * @param holdRetro the holdRetro to set
	 */
	public void setHoldRetro(BigDecimal holdRetro) {
		this.holdRetro = holdRetro;
	}

	/**
	 * @return the holdPercent
	 */
	public BigDecimal getHoldPercent() {
		return holdPercent;
	}

	/**
	 * @param holdPercent the holdPercent to set
	 */
	public void setHoldPercent(BigDecimal holdPercent) {
		this.holdPercent = holdPercent;
	}

	/**
	 * @return the retroToal
	 */
	public BigDecimal getRetroToal() {
		return retroToal;
	}

	/**
	 * @param retroToal the retroToal to set
	 */
	public void setRetroToal(BigDecimal retroToal) {
		this.retroToal = retroToal;
	}

	/**
	 * @return the cededRetroTotal
	 */
	public BigDecimal getCededRetroTotal() {
		return cededRetroTotal;
	}

	/**
	 * @param cededRetroTotal the cededRetroTotal to set
	 */
	public void setCededRetroTotal(BigDecimal cededRetroTotal) {
		this.cededRetroTotal = cededRetroTotal;
	}

	/**
	 * @return the holdRatingPeriodBeg
	 */
	public Date getHoldRatingPeriodBeg() {
		return holdRatingPeriodBeg;
	}

	/**
	 * @param holdRatingPeriodBeg the holdRatingPeriodBeg to set
	 */
	public void setHoldRatingPeriodBeg(Date holdRatingPeriodBeg) {
		this.holdRatingPeriodBeg = holdRatingPeriodBeg;
	}

	/**
	 * @return the holdRatingPeriodEnd
	 */
	public Date getHoldRatingPeriodEnd() {
		return holdRatingPeriodEnd;
	}

	/**
	 * @param holdRatingPeriodEnd the holdRatingPeriodEnd to set
	 */
	public void setHoldRatingPeriodEnd(Date holdRatingPeriodEnd) {
		this.holdRatingPeriodEnd = holdRatingPeriodEnd;
	}

	
	

	/**
	 * @return the monthlyBookedDate
	 */
	public Date getMonthlyBookedDate() {
		return monthlyBookedDate;
	}

	/**
	 * @param monthlyBookedDate the monthlyBookedDate to set
	 */
	public void setMonthlyBookedDate(Date monthlyBookedDate) {
		this.monthlyBookedDate = monthlyBookedDate;
	}

	/**
	 * @return the workFileList
	 */
	public List<AccountPremium> getWorkFileList() {
		return workFileList;
	}

	/**
	 * @param workFileList the workFileList to set
	 */
	public void setWorkFileList(List<AccountPremium> workFileList) {
		this.workFileList = workFileList;
	}

	/**
	 * @return the workRecords
	 */
	public int getWorkRecords() {
		return workRecords;
	}

	/**
	 * @param workRecords the workRecords to set
	 */
	public void setWorkRecords(int workRecords) {
		this.workRecords = workRecords;
	}

	/**
	 * @param calculateRetrospectivePremiumAndUpdateAccountsData
	 * @return
	 */
	public CalculateRetrospectivePremiumAndUpdateAccountsData retroRatingNonValluedInit(CalculateRetrospectivePremiumAndUpdateAccountsData calculateRetrospectivePremiumAndUpdateAccountsData){
		
		calculateRetrospectivePremiumAndUpdateAccountsData.setStoreAmounts(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setHoldExpPer("");
		calculateRetrospectivePremiumAndUpdateAccountsData.setTotalRetroChange(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setTotalPremium(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setTotalIncurred(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setDevelopedPremium(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setStoreEarnedPrem(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setMinimum(new BigDecimal(0));
		calculateRetrospectivePremiumAndUpdateAccountsData.setMaximum(new BigDecimal(0));
		
		return calculateRetrospectivePremiumAndUpdateAccountsData;
	}

	public void clearNonCommonFields() {
		 storeTreatyNum = "";           
		 storeTreatyCcompany = "";     
		 storeRatingIndicator = "";
		 holdExpPer = "" ;    
		 retroPriority = "";
		
		 storeSubjectPrem = new BigDecimal(0);
		 storeEarnedPrem = new BigDecimal(0);
		 storeCommission = new BigDecimal(0);
		 totalPremium = new BigDecimal(0);    
		 totalIncurred = new BigDecimal(0);
		
		 particantPercentage = new BigDecimal(0);
		 margin = new BigDecimal(0);
		 storedIncurredLoss = new BigDecimal(0);
		 developedPremium = new BigDecimal(0);
		 holdAmount = new BigDecimal(0);
		 minimum = new BigDecimal(0);
		 maximum = new BigDecimal(0);
		 storeAmounts = new BigDecimal(0);                            
		                           
		 totalRetroChange = new BigDecimal(0);  
		 proRatePercent = new BigDecimal(0);
		 proRatePercentRound = new BigDecimal(0);
		 holdRetro = new BigDecimal(0);
		 holdPercent = new BigDecimal(0);
		 retroToal = new BigDecimal(0);
		 cededRetroTotal  = new BigDecimal(0);
		
		holdRatingPeriodBeg = null;
		 holdRatingPeriodEnd = null;
		 monthlyBookedDate= null;
		 workFileList = new ArrayList<AccountPremium>();
		  workRecords = 0;
		
	}

	public int getPremRecordsAdded() {
		return premRecordsAdded;
	}

	public void setPremRecordsAdded(int premRecordsAdded) {
		this.premRecordsAdded = premRecordsAdded;
	}

	public int getCntrRecordsAdded() {
		return cntrRecordsAdded;
	}

	public void setCntrRecordsAdded(int cntrRecordsAdded) {
		this.cntrRecordsAdded = cntrRecordsAdded;
	}

	public void incrementCntrRecordsAdded() {
		this.cntrRecordsAdded++;
		
	}

	public void incrementCntrRecordsUpdated() {
		this.setCntrRecordsUpdated(this.getCntrRecordsUpdated() + 1);
		
	}

	public void incrementPremRecordsAdded() {
		this.premRecordsAdded++;
		
	}
	public void incrementPremRecordsUpdated() {
		this.setPremRecordsUpdated(this.getPremRecordsUpdated() + 1);
		
	}

	public int getCntrRecordsUpdated() {
		return cntrRecordsUpdated;
	}

	public void setCntrRecordsUpdated(int cntrRecordsUpdated) {
		this.cntrRecordsUpdated = cntrRecordsUpdated;
	}

	public int getPremRecordsUpdated() {
		return premRecordsUpdated;
	}

	public void setPremRecordsUpdated(int premRecordsUpdated) {
		this.premRecordsUpdated = premRecordsUpdated;
	}
}
