package com.reinsurance.urs.batch.dom;

/**
 * InitiateDailyCycleData is used for generate dom object for InitiateDailyCycle
 * @author Discoverture�Solutions
 *
 */
public class InitiateDailyCycleData extends JobData {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1282997999745524673L;
	


}
