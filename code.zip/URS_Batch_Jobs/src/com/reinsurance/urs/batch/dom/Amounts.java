package com.reinsurance.urs.batch.dom;

import java.io.Serializable;
import java.math.BigDecimal;
/**
 * Amounts is used for generate dom object for CaluculateUnderwritingIBNRAndDetailLossTransactions
 * @author Discoverture�Solutions
 *
 */
public class Amounts implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal incurredLoss;
	private BigDecimal outstandingLoss;
	private BigDecimal earnedPrem;
	private BigDecimal underwritingIbnr;
	private BigDecimal subjectPrem;
	
	public Amounts() {
		this.incurredLoss =  new BigDecimal(0);
		this.outstandingLoss = new BigDecimal(0);;
		this.earnedPrem = new BigDecimal(0);
		this.underwritingIbnr = new BigDecimal(0);
		this.subjectPrem = new BigDecimal(0);
	}
	public Amounts(BigDecimal incurredLoss, BigDecimal outstandingLoss,
			BigDecimal earnedPrem, BigDecimal underwritingIbnr,
			BigDecimal subjectPrem) {
		super();
		this.incurredLoss = incurredLoss;
		this.outstandingLoss = outstandingLoss;
		this.earnedPrem = earnedPrem;
		this.underwritingIbnr = underwritingIbnr;
		this.subjectPrem = subjectPrem;
	}
	/**
	 * @return the incurredLoss
	 */
	public BigDecimal getIncurredLoss() {
		return incurredLoss;
	}

	/**
	 * @param incurredLoss the incurredLoss to set
	 */
	public void setIncurredLoss(BigDecimal incurredLoss) {
		this.incurredLoss = incurredLoss;
	}

	/**
	 * @return the outstandingLoss
	 */
	public BigDecimal getOutstandingLoss() {
		return outstandingLoss;
	}

	/**
	 * @param outstandingLoss the outstandingLoss to set
	 */
	public void setOutstandingLoss(BigDecimal outstandingLoss) {
		this.outstandingLoss = outstandingLoss;
	}

	/**
	 * @return the earnedPrem
	 */
	public BigDecimal getEarnedPrem() {
		return earnedPrem;
	}

	/**
	 * @param earnedPrem the earnedPrem to set
	 */
	public void setEarnedPrem(BigDecimal earnedPrem) {
		this.earnedPrem = earnedPrem;
	}

	/**
	 * @return the underwritingIbnr
	 */
	public BigDecimal getUnderwritingIbnr() {
		return underwritingIbnr;
	}

	/**
	 * @param underwritingIbnr the underwritingIbnr to set
	 */
	public void setUnderwritingIbnr(BigDecimal underwritingIbnr) {
		this.underwritingIbnr = underwritingIbnr;
	}

	/**
	 * @return the subjectPrem
	 */
	public BigDecimal getSubjectPrem() {
		return subjectPrem;
	}

	/**
	 * @param subjectPrem the subjectPrem to set
	 */
	public void setSubjectPrem(BigDecimal subjectPrem) {
		this.subjectPrem = subjectPrem;
	}
	public void addAmounts(Amounts amounts) {
		
		this.incurredLoss.add(amounts.getIncurredLoss());
		this.outstandingLoss.add(amounts.getOutstandingLoss());
		this.earnedPrem .add(amounts.getEarnedPrem());
		this.underwritingIbnr.add(amounts.getUnderwritingIbnr());
		this.subjectPrem .add(amounts.getSubjectPrem());
	}
	
}
