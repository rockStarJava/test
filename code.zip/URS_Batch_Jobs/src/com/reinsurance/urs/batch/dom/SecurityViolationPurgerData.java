package com.reinsurance.urs.batch.dom;


public class SecurityViolationPurgerData extends JobData{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1461825544110856892L;
	

}
