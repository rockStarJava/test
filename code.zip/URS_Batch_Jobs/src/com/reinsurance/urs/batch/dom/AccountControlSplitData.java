package com.reinsurance.urs.batch.dom;

import java.util.HashMap;

import com.reinsurance.urs.domain.accounting.accounts.AccountControl;
import com.reinsurance.urs.domain.accounting.accounts.AccountControlKey;
import com.reinsurance.urs.domain.sysadmin.DateCard;

/**
 * AccountControlSplitData is used for generate dom object for CreateAccountControlRecordsForContractSplits
 * @author Discoverture�Solutions
 *
 */
public class AccountControlSplitData extends JobData{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6888485050404436732L;
	private HashMap<AccountControlKey, AccountControl> accountControlhasmap = null;
	private DateCard datecard=null;
	/**
	 * @return the accountControlhasmap
	 */
	public HashMap<AccountControlKey, AccountControl> getAccountControlhasmap() {
		return accountControlhasmap;
	}
	/**
	 * @param accountControlhasmap the accountControlhasmap to set
	 */
	public void setAccountControlhasmap(
			HashMap<AccountControlKey, AccountControl> accountControlhasmap) {
		this.accountControlhasmap = accountControlhasmap;
	}
	/**
	 * @return the datecard
	 */
	public DateCard getDatecard() {
		return datecard;
	}
	/**
	 * @param datecard the datecard to set
	 */
	public void setDatecard(DateCard datecard) {
		this.datecard = datecard;
	}
	

}
