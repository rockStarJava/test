package com.reinsurance.urs.batch.dom;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

import net.sf.dynamicreports.report.datasource.DRDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.reinsurance.urs.domain.accounting.accounts.AccountUpdates;
import com.reinsurance.urs.domain.sysadmin.SystemDefaults;

/**
 * DepositPremiumData is used for generate dom object for
 * GenerateDepositPremiums
 * 
 * @author Discoverture�Solutions
 * 
 */
public class DepositPremiumData extends JobData implements Serializable {
	private static String jobName = "GenerateDepositPremiums.java";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private AccountUpdates accountUpdates = new AccountUpdates();
	private Date bookedDate = null;
	private BigDecimal controlNum = new BigDecimal(0);
	private DRDataSource depositPremiumDataSources = null;

	private boolean errorFlag = false;
	private Date nextReviewDate = null;
	private SystemDefaults systemDefaults = null;
	private BigDecimal tempBlowBrokerage = new BigDecimal(0);
	private BigDecimal tempBlowCommission = new BigDecimal(0);
	private BigDecimal tempBlowOverride = new BigDecimal(0);
	private BigDecimal tempBlowSubject = new BigDecimal(0);

	private BigDecimal tempBlowWritten = new BigDecimal(0);
	private BigDecimal tempHoldBrokerage = new BigDecimal(0);

	private BigDecimal tempHoldCommission = new BigDecimal(0);

	private BigDecimal tempHoldOverride = new BigDecimal(0);
	private BigDecimal tempHoldSubject = new BigDecimal(0);

	private BigDecimal tempHoldWritten = new BigDecimal(0);

	public void clearValues() {
		this.errorFlag = false;

		this.tempBlowBrokerage = new BigDecimal(0);
		this.tempBlowCommission = new BigDecimal(0);
		this.tempBlowOverride = new BigDecimal(0);
		this.tempBlowSubject = new BigDecimal(0);
		this.tempBlowWritten = new BigDecimal(0);

		this.tempHoldBrokerage = new BigDecimal(0);
		this.tempHoldCommission = new BigDecimal(0);

		this.tempHoldOverride = new BigDecimal(0);

		this.tempHoldSubject = new BigDecimal(0);
		this.tempHoldWritten = new BigDecimal(0);
		this.nextReviewDate = null;
		this.accountUpdates = null;

	}

	/**
	 * @return the accountUpdates
	 */
	public AccountUpdates getAccountUpdates() {
		return accountUpdates;
	}

	public Date getBookedDate() {
		return bookedDate;
	}

	public BigDecimal getControlNum() {
		return controlNum;
	}

	/**
	 * @return the depositPremiumDataSources
	 */
	public DRDataSource getDepositPremiumDataSources() {
		return depositPremiumDataSources;
	}

	public BigDecimal getIncrementedControlNum() {
		this.controlNum = controlNum.add(new BigDecimal(1));
		return controlNum;

	}

	public Logger getLogger() {
		if (logger == null) {
			logger = LoggerFactory.getLogger(jobName);
		}
		return logger;
	}

	public Date getNextReviewDate() {
		return nextReviewDate;
	}

	/**
	 * @return the systemDefaults
	 */
	public SystemDefaults getSystemDefaults() {
		return systemDefaults;
	}

	/**
	 * @return the tempBlowBrokerage
	 */
	public BigDecimal getTempBlowBrokerage() {
		return tempBlowBrokerage;
	}

	/**
	 * @return the tempBlowCommission
	 */
	public BigDecimal getTempBlowCommission() {
		return tempBlowCommission;
	}

	/**
	 * @return the tempBlowOverride
	 */
	public BigDecimal getTempBlowOverride() {
		return tempBlowOverride;
	}

	/**
	 * @return the tempBlowSubject
	 */
	public BigDecimal getTempBlowSubject() {
		return tempBlowSubject;
	}

	/**
	 * @return the tempBlowWritten
	 */
	public BigDecimal getTempBlowWritten() {
		return tempBlowWritten;
	}

	/**
	 * @return the tempHoldBrokerage
	 */
	public BigDecimal getTempHoldBrokerage() {
		return tempHoldBrokerage;
	}

	/**
	 * @return the tempHoldCommission
	 */
	public BigDecimal getTempHoldCommission() {
		return tempHoldCommission;
	}

	/**
	 * @return the tempHoldOverride
	 */
	public BigDecimal getTempHoldOverride() {
		return tempHoldOverride;
	}

	/**
	 * @return the tempHoldSubject
	 */
	public BigDecimal getTempHoldSubject() {
		return tempHoldSubject;
	}

	/**
	 * @return the tempHoldWritten
	 */
	public BigDecimal getTempHoldWritten() {
		return tempHoldWritten;
	}

	public boolean isErrorFlag() {
		return errorFlag;
	}

	/**
	 * @param accountUpdates
	 *            the accountUpdates to set
	 */
	public void setAccountUpdates(AccountUpdates accountUpdates) {
		this.accountUpdates = accountUpdates;
	}

	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}

	public void setControlNum(BigDecimal controlNum) {
		this.controlNum = controlNum;
	}

	/**
	 * @param depositPremiumDataSources
	 *            the depositPremiumDataSources to set
	 */
	public void setDepositPremiumDataSources(DRDataSource depositPremiumDataSources) {
		this.depositPremiumDataSources = depositPremiumDataSources;
	}

	public void setErrorFlag(boolean errorFlag) {
		this.errorFlag = errorFlag;
	}

	public void setNextReviewDate(Date nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	/**
	 * @param systemDefaults
	 *            the systemDefaults to set
	 */
	public void setSystemDefaults(SystemDefaults systemDefaults) {
		this.systemDefaults = systemDefaults;
	}

	/**
	 * @param tempBlowBrokerage
	 *            the tempBlowBrokerage to set
	 */
	public void setTempBlowBrokerage(BigDecimal tempBlowBrokerage) {
		this.tempBlowBrokerage = tempBlowBrokerage;
	}

	/**
	 * @param tempBlowCommission
	 *            the tempBlowCommission to set
	 */
	public void setTempBlowCommission(BigDecimal tempBlowCommission) {
		this.tempBlowCommission = tempBlowCommission;
	}

	/**
	 * @param tempBlowOverride
	 *            the tempBlowOverride to set
	 */
	public void setTempBlowOverride(BigDecimal tempBlowOverride) {
		this.tempBlowOverride = tempBlowOverride;
	}

	/**
	 * @param tempBlowSubject
	 *            the tempBlowSubject to set
	 */
	public void setTempBlowSubject(BigDecimal tempBlowSubject) {
		this.tempBlowSubject = tempBlowSubject;
	}

	/**
	 * @param tempBlowWritten
	 *            the tempBlowWritten to set
	 */
	public void setTempBlowWritten(BigDecimal tempBlowWritten) {
		this.tempBlowWritten = tempBlowWritten;
	}

	/**
	 * @param tempHoldBrokerage
	 *            the tempHoldBrokerage to set
	 */
	public void setTempHoldBrokerage(BigDecimal tempHoldBrokerage) {
		this.tempHoldBrokerage = tempHoldBrokerage;
	}

	/**
	 * @param tempHoldCommission
	 *            the tempHoldCommission to set
	 */
	public void setTempHoldCommission(BigDecimal tempHoldCommission) {
		this.tempHoldCommission = tempHoldCommission;
	}

	/**
	 * @param tempHoldOverride
	 *            the tempHoldOverride to set
	 */
	public void setTempHoldOverride(BigDecimal tempHoldOverride) {
		this.tempHoldOverride = tempHoldOverride;
	}

	/**
	 * @param tempHoldSubject
	 *            the tempHoldSubject to set
	 */
	public void setTempHoldSubject(BigDecimal tempHoldSubject) {
		this.tempHoldSubject = tempHoldSubject;
	}

	/**
	 * @param tempHoldWritten
	 *            the tempHoldWritten to set
	 */
	public void setTempHoldWritten(BigDecimal tempHoldWritten) {
		this.tempHoldWritten = tempHoldWritten;
	}

}
