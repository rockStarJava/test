package com.reinsurance.urs.batch.utility;

import java.util.StringTokenizer;



/**
 * This class converts a cron expression to human readable format. call method
 * humanReadableForm and pass the cron expression.
 * 
 * @author Lakshmi.Isukapally
 * 
 */
public class CronConvertor {

	public static String humanReadableForm(String value) {
		StringBuffer sb = new StringBuffer();
		if (value == null || value.trim().length() <= 0)
			return null;
		try {

			StringTokenizer tokens = new StringTokenizer(value, " ", false);
			String seconds = tokens.nextToken();
			String min = tokens.nextToken();
			String hours = tokens.nextToken();
			String dom = tokens.nextToken();
			String month = tokens.nextToken();
			String dow = tokens.nextToken();
			sb.append(getTimeFormat(seconds, min, hours));
			sb.append(" , ");
			String weekFormat = getWeekFormat(dow);
			String dayOfMonthFormat = getdayOfMonthFormat(dom);
			String monthlyFormat = getmonthlyFormat(month);
			if (weekFormat != null && !weekFormat.trim().isEmpty())
			{
				if (dayOfMonthFormat == null||(dayOfMonthFormat!=null && dayOfMonthFormat.trim().isEmpty())
						|| dayOfMonthFormat.trim().equalsIgnoreCase(monthlyFormat.trim())) {
				sb.append(weekFormat);
				sb.append(" , ");
				}
			}
			sb.append(dayOfMonthFormat);
			if (dayOfMonthFormat != null
					&& dayOfMonthFormat != null
					&& !dayOfMonthFormat.trim().equalsIgnoreCase(
							monthlyFormat.trim())) {
				sb.append(" ");
				sb.append(monthlyFormat);
			}

		} catch (Throwable t) {
			t.printStackTrace();
		}
		return sb.toString();
	}

	private static String getmonthlyFormat(String value) {
		String returnVal = "";
		value = value.trim();
		if (isInteger(value) && notZero(value)) {
			returnVal = "in the month of "
					+ getMonthName(Integer.parseInt(value));
		} else if (value.equals("*")) {
			returnVal = "Every Month";
		}

		else if (value.indexOf(",") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, ",", false);
			StringBuffer sb = new StringBuffer();
			sb.append("every ");
			while (tokens.hasMoreTokens()) {
				String token = tokens.nextToken();
				if (isInteger(token)) {
					sb.append(getMonthName(Integer.parseInt(token)) + " ");

				}

			}
			returnVal = sb.toString();
		} else if (value.indexOf("-") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, "-", false);
			returnVal = "From "
					+ getMonthName(Integer.parseInt(tokens.nextToken()))
					+ " to "
					+ getMonthName(Integer.parseInt(tokens.nextToken()));
		}
		//System.out.println("monthlyFormat:"+returnVal);
		return returnVal;
	}

	private static String getdayOfMonthFormat(String value) {
		value = value.trim();
		String returnVal = "";

		if (isInteger(value) && notZero(value)) {
			returnVal = value + " day-of-the-month";
		} else if (value.equals("*")) {
			returnVal = "Every Month";
		} else if (value.equals("?")) {
			returnVal = "";
		}

		else if (value.equals("L")) {
			returnVal = " last day of month";
		}
		
		return returnVal;
	}

	private static String getWeekFormat(String value) {
		String returnVal = "";
		value = value.trim();
		if (isInteger(value)) {
			returnVal = "every " + getWeekDayName(Integer.parseInt(value));
		} else if (value.equals("*") ||value.equals("?")) {
			returnVal = "Every day of the week";
		}

		else if (value.indexOf(",") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, ",", false);
			StringBuffer sb = new StringBuffer();
			sb.append("every ");

			while (tokens.hasMoreTokens()) {
				String token = tokens.nextToken();
				if (isInteger(token)) {
					sb.append(getWeekDayName(Integer.parseInt(token)) + " ");

				}

			}
			returnVal = sb.toString();
		} else if (value.indexOf("-") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, "-", false);
			returnVal = "From "
					+ getWeekDayName(Integer.parseInt(tokens.nextToken()))
					+ " to "
					+ getWeekDayName(Integer.parseInt(tokens.nextToken()));
		}

		else if (value.indexOf("#") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, "#", false);
			String day = tokens.nextToken();
			String count = tokens.nextToken();
			returnVal = " on the " + numberToWord(count) + " "
					+ getWeekDayName(Integer.parseInt(day));
		}

		else if (value.indexOf("L") > -1) {
			StringTokenizer tokens = new StringTokenizer(value, "L", false);
			String day = tokens.nextToken();

			returnVal = " on the last Day of  "
					+ getWeekDayName(Integer.parseInt(day));
		}
		//System.out.println("weekFormat"+ returnVal);
		return returnVal;

	}

	private static String numberToWord(String count) {

		int number = Integer.parseInt(count);
		switch (number) {
		case 1:
			return "first";
		case 2:
			return "second";
		case 3:
			return "third";
		case 4:
			return "fourth";
		case 5:
			return "fifth";
		}
		return count;
	}

	private static String getTimeFormat(String seconds, String min, String hours) {
		StringBuffer sb = new StringBuffer();
		sb = sb.append(getFormat(hours, "hours"));
		sb = sb.append(":");
		sb = sb.append(getFormat(min, "mins"));
		sb = sb.append(":");
		sb = sb.append(getFormat(seconds, "secs"));

		return sb.toString();

	}

	private static String getFormat(String value, String postfix) {
		String returnVal = "";
		value = value.trim();
		if (isInteger(value)) {
			if (notZero(value))
				returnVal = value;
			else
				returnVal = "00";
		} else if (value.equals("*")) {
			returnVal = "Every" + postfix;
		}
		return returnVal;

	}

	private static boolean notZero(String value) {
		try {
			int n =  Integer.parseInt(value);
			if (n > 0)
				return true;
		} catch (NumberFormatException e) {
			
			e.printStackTrace();
		}

		return false;
	}

	
	private static String getMonthName(int month)

	{
		String[] monthNames = { "January", "February", "March", "April", "May",
				"June", "July", "August", "September", "October", "November",
				"December" };
		if (month < monthNames.length+1 && month > 0) // added "monthNames.length+1" to display December when length is 12
			return monthNames[month - 1];

		else
			return null;
	}

	private static String getWeekDayName(int day) {

		String[] weekdays = { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY",
				"THURSDAY", "FRIDAY", "SATURDAY" };
		if (day < weekdays.length+1 && day > 0) // added "weekdays.length+1" to display Saturday when length is 7
			return weekdays[day - 1];
		else
			return null;
	}

	public static boolean isInteger(String s) {
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			return false;
		}
		// only got here if we didn't return false
		return true;
	}

}
