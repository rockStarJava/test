package com.reinsurance.urs.batch.service;

import static net.sf.dynamicreports.report.builder.DynamicReports.cmp;
import static net.sf.dynamicreports.report.builder.DynamicReports.col;
import static net.sf.dynamicreports.report.builder.DynamicReports.grp;
import static net.sf.dynamicreports.report.builder.DynamicReports.report;
import static net.sf.dynamicreports.report.builder.DynamicReports.sbt;
import static net.sf.dynamicreports.report.builder.DynamicReports.type;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.sf.dynamicreports.jasper.builder.JasperConcatenatedReportBuilder;
import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.dynamicreports.report.builder.ReportTemplateBuilder;
import net.sf.dynamicreports.report.builder.column.TextColumnBuilder;
import net.sf.dynamicreports.report.builder.component.PageXofYBuilder;
import net.sf.dynamicreports.report.builder.component.TextFieldBuilder;
import net.sf.dynamicreports.report.builder.group.ColumnGroupBuilder;
import net.sf.dynamicreports.report.constant.HorizontalAlignment;
import net.sf.dynamicreports.report.datasource.DRDataSource;
import net.sf.dynamicreports.report.definition.datatype.DRIDataType;
import net.sf.dynamicreports.report.exception.DRException;
import net.sf.jasperreports.engine.JRDataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.exceptions.ReportGenerationException;
import com.reinsurance.urs.batch.jobs.framewrk.DynamicColumn;
import com.reinsurance.urs.batch.jobs.framewrk.DynamicReport;
import com.reinsurance.urs.batch.jobs.framewrk.FormatUtility;
import com.reinsurance.urs.batch.jobs.framewrk.StacktraceUtil;
import com.reinsurance.urs.batch.jobs.framewrk.Templates;
import com.reinsurance.urs.dao.exception.DaoAccessException;
import com.reinsurance.urs.dao.reports.ReportOnlineDao;
import com.reinsurance.urs.dao.sysadmin.SystemDefaultsDao;
import com.reinsurance.urs.domain.reports.ReportView;
import com.reinsurance.urs.domain.service.exception.ServiceCallException;
import com.reinsurance.urs.domain.sysadmin.RptOutSetting;
import com.reinsurance.urs.domain.sysadmin.SystemConfiguration;
import com.reinsurance.urs.domain.sysadmin.SystemDefaults;
import com.reinsurance.urs.domain.sysadmin.UpdateUser;
import com.reinsurance.urs.services.ServiceAbstract;
import com.reinsurance.urs.services.sysadmin.SystemConfigurationService;

/**
 * 
 * This service creates a PDF format report
 * 
 */
@Service("dynamicReportGenerationService")
public class DynamicReportGenerationService extends ServiceAbstract {

	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource report_message = null;

	final String defaultPrefix = "TR";

	protected static final Logger logger = LoggerFactory
			.getLogger(DynamicReportGenerationService.class);

	@Autowired
	@Qualifier("systemDefaultsDao")
	private SystemDefaultsDao systemDefaultsDao = null;

	@Autowired
	@Qualifier("systemConfigService")
	private SystemConfigurationService systemConfigService = null;

	@Autowired
	@Qualifier("reportOnlineDao")
	private ReportOnlineDao reportOnlineDao = null;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public JasperReportBuilder buildReport(ReportTemplateBuilder template,
			DynamicReport dynamicReport, JRDataSource dataSource,
			String reportPrefix, String reportTitle, Date period)
			throws DRException {

		JasperReportBuilder report = report();

		String forDate = report_message.getMessage("report.For", null,
				"Default", null) + FormatUtility.formatDate(period);

		// Headers
		TextFieldBuilder<String> header1 = cmp
				.text(report_message.getMessage(
						"report.universalReinsuranceSystem", null, "Default",
						null)).setStyle(Templates.headerStyle)
				.setHorizontalAlignment(HorizontalAlignment.LEFT);
		TextFieldBuilder<String> header2 = cmp
				.text(report_message.getMessage("report.prefix", null,
						"Default", null) + reportPrefix)
				.setStyle(Templates.headerStyle)
				.setHorizontalAlignment(HorizontalAlignment.LEFT);

		// titles
		TextFieldBuilder<String> title = cmp.text(reportTitle)
				.setStyle(Templates.bold13CenteredStyle);

		TextFieldBuilder<String> subTitle = cmp.text(forDate).setStyle(
				Templates.bold12CenteredStyle.setFirstLineIndent(1));

		TextFieldBuilder<String> space = cmp.text("").setStyle(
				Templates.bold12CenteredStyle.setFirstLineIndent(1));

		// Set Report
		report.setTemplate(template);
		report.addTitle(cmp.verticalList(header1, header2, title, subTitle,
				space));
		report.highlightDetailOddRows();

		// SetColumn
		boolean lotOfColumns = false;
		List<DynamicColumn> columns = dynamicReport.getColumns();
		// if more column are there
				if (columns!=null && columns.size() > 7) {
					lotOfColumns = true;
					report.setColumnStyle(Templates.columnStyleLarge);
					report.setColumnTitleStyle(Templates.columnTitleStyleLarge);
				}
		Map<String, TextColumnBuilder> drColumns = new HashMap<String, TextColumnBuilder>();

		for (DynamicColumn column : columns) 
		{
			TextColumnBuilder drColumn = col.column(column.getTitle(),
					column.getName(),
					(DRIDataType) type.detectType(column.getType()));
			if (column.getPattern() != null) {
				drColumn.setPattern(column.getPattern());
			}
			if (column.getHorizontalAlignment() != null) {
				drColumn.setHorizontalAlignment(column.getHorizontalAlignment());
				drColumn.setTitleStyle(Templates.getcolumnTitleStyleBasedOnType(column.getHorizontalAlignment(),lotOfColumns));
				drColumn.setStyle(Templates.getcolumnStyleBased(column.getHorizontalAlignment(),lotOfColumns));
			}
			drColumns.put(column.getName(), drColumn);
				report.columns(drColumn);
			
		}

		

		for (String group : dynamicReport.getGroups()) {
			ColumnGroupBuilder group2 = grp.group(drColumns.get(group));
			report.groupBy(group2);

			for (String subtotal : dynamicReport.getSubtotals()) {
				report.subtotalsAtGroupFooter(group2,
						sbt.sum(drColumns.get(subtotal)));
			}
		}

		for (String subtotal : dynamicReport.getSubtotals()) {
			report.subtotalsAtSummary(sbt.sum(drColumns.get(subtotal)));
		}

		// footers
		TextFieldBuilder<String> runDate = cmp
				.text(report_message.getMessage("report.RunDate", null,
						"Default", null)
						+ FormatUtility.formatDate(new java.util.Date()))
				.setStyle(Templates.boldCenteredStyle)
				.setHorizontalAlignment(HorizontalAlignment.RIGHT);
		PageXofYBuilder pageXofY = cmp.pageXofY()
				.setStyle(Templates.boldCenteredStyle)
				.setHorizontalAlignment(HorizontalAlignment.JUSTIFIED);

		report.addPageFooter(cmp.verticalList(runDate, pageXofY));
		report.setDataSource(dataSource);

		return report;
	}

	/**
	 * This method will get the user home directory and check the report
	 * directory existence and if not it will create a folder to store PDF
	 * files.
	 * 
	 * @return
	 * @throws DaoAccessException
	 * @throws ServiceCallException
	 */
	public String getReportDirectoryLocation() throws IOException,
			DaoAccessException, ServiceCallException {

		SystemConfiguration l_sys_config = systemConfigService
				.getSystemConfiguration();

		String report_repository = l_sys_config.getNetwork_path();

		File file = new File(report_repository);
		// If report repository does not exist, throw an error.
		// Do not try to create repository location.
		if (!file.exists()) {
			throw new IOException(report_message.getMessage(
					"reportService.IOError ", null, "Default", null)
					+ report_repository);
		}

		return report_repository;
	}

	/**
	 * generates report from Predefined DynamicReport template ,using Report
	 * datasource
	 * 
	 * @param reportStPrefix
	 * @param reportEndPrefix
	 * @param dynamicReport
	 * @param reportDataSource
	 * @param reportTitle
	 * @param period
	 * @return
	 * @throws ReportGenerationException
	 * @throws IOException
	 * @throws DaoAccessException
	 * @throws ServiceCallException
	 */
	public boolean generateReport(String reportStPrefix,
			String reportEndPrefix, DynamicReport dynamicReport,
			DRDataSource reportDataSource, String reportName,
			String reportTitle, Date period, long processExecutionInstanceId)
			throws ReportGenerationException, IOException, DaoAccessException,
			ServiceCallException {

		boolean status = false;
		JasperReportBuilder report = null;
		String reportPrefix = "";
		String reportLocation = getReportDirectoryLocation();
		String fileName = UUID.randomUUID().toString();
		String fileSeparator = report_message.getMessage("file.separator",
				null, "Default", null);
		String fileExtension = report_message.getMessage(
				"report.pdf.extension", null, "Default", null);
		String filePath = reportLocation + fileSeparator + fileName
				+ fileExtension;

		try {
			/*
			 * Get the list of SystemDefaults whose DEFAULT_ID is TRF850I
			 */
			SystemDefaults systemDefaults = systemDefaultsDao.get();

			if (systemDefaults != null) {
				reportPrefix = reportStPrefix
						+ systemDefaults.getJcl_report_prefix()
						+ reportEndPrefix;

			} else {
				reportPrefix = reportStPrefix + defaultPrefix + reportEndPrefix;
			}
			ReportTemplateBuilder template = Templates.reportTemplate;

			report = buildReport(template, dynamicReport, reportDataSource,
					reportPrefix, reportTitle, period);

			if (report == null)
				throw new ReportGenerationException();

			// Write out report file.
			OutputStream oos = new FileOutputStream(filePath, false);
			report.toPdf(oos);
			oos.close();

			// Get file size
			File temp = new File(filePath);
			long file_size = temp.length();

			// Add report metadata to database
			addPDFReport(reportName, reportPrefix, fileName, fileExtension,
					file_size, processExecutionInstanceId);

			status = true;
		} catch (Exception e) {
			e.printStackTrace();
			String message = (URSBatchConstants.separator
					+ URSBatchConstants.tab + StacktraceUtil.getStackTrace(e));
			logger.error(report_message.getMessage("report.generation.error",
					null, "Default", null));
			throw new ReportGenerationException((report_message.getMessage(
					"batchJob.error", null, "Default", null)) + message);
		}
		return status;
	}

	public boolean generateReport(
			JasperConcatenatedReportBuilder completeReport, String reportName,
			long processExecutionInstanceId) throws IOException, DRException,
			DaoAccessException, ServiceCallException {

		String reportLocation = getReportDirectoryLocation();
		String fileName = UUID.randomUUID().toString();
		String fileSeparator = report_message.getMessage("file.separator",
				null, "Default", null);
		String fileExtension = report_message.getMessage(
				"report.pdf.extension", null, "Default", null);
		String filePath = reportLocation + fileSeparator + fileName
				+ fileExtension;

		/* Generating Report Start */
		OutputStream oos = new FileOutputStream(filePath, false);
		completeReport.toPdf(oos);
		oos.close();

		// Get file size
		File temp = new File(filePath);
		long file_size = temp.length();

		// Add report metadata to database
		addPDFReport(reportName, "Default", fileName, fileExtension, file_size,
				processExecutionInstanceId);

		return true;

	}

	private void addPDFReport(String a_reportName, String a_reportPrefix,
			String a_fileName, String a_fileExtension, long file_size,
			long a_pei) throws DaoAccessException {

		int kb_size = (int) file_size / 1000;

		// Build ReportView DOM
		ReportView reportView = new ReportView();

		reportView.setFile_id(a_fileName + a_fileExtension);
		UpdateUser updateUser = new UpdateUser();
		updateUser.setOperator_id(URSBatchConstants.USER_OPERATOR_ID);
		reportView.setOperator(updateUser);
		reportView.setReport_id("000"); // Default
		reportView.setReport_time_stamp(new Timestamp(Calendar.getInstance()
				.getTime().getTime()));
		reportView.setReport_title_id(StringUtils.left(a_reportPrefix, 10));
		reportView.setReport_title(a_reportName);
		reportView.setFile_type(RptOutSetting.PDF_OPT);
		reportView.setRun_status(ReportView.COMPLETE_STATUS);
		reportView.setPei_id((int) a_pei);
		reportView.setFile_size(kb_size);

		// Add to database
		reportOnlineDao.addReport(reportView);
	}
}
