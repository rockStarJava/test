package com.reinsurance.urs.batch.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.reinsurance.urs.dao.exception.DaoAccessException;
import com.reinsurance.urs.dao.sysadmin.SystemUserSecurityDao;



@Service("securityViolationService")
public class SecurityViolationService {
	
	@Autowired
	@Qualifier("systemUserSecurityDao")
	private SystemUserSecurityDao systemUserSecurityDao = null;
	
	public int deleteALLSecurityviolations() throws DaoAccessException{
		return systemUserSecurityDao.deleteAllViolations();
	}

}
