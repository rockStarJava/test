package com.reinsurance.urs.batch.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.StringTokenizer;

import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.dom.InitiateDailyCycleData;
import com.reinsurance.urs.batch.exceptions.JobFailedException;
import com.reinsurance.urs.batch.jobs.framewrk.StacktraceUtil;
import com.reinsurance.urs.dao.exception.DaoAccessException;
import com.reinsurance.urs.dao.sysadmin.DateCardDao;
import com.reinsurance.urs.domain.sysadmin.DateCard;
import com.reinsurance.urs.batch.dom.JobData;

@Service("batchDateCardService")
public class BatchDateCardService {
	@Autowired
	@Qualifier("dateCardDao")
	private DateCardDao dateCardDao = null;
	@Autowired
	@Qualifier("batchMessageSource")
	protected MessageSource message_source = null;

	/**
	 * This method Validate the DateCard Records.
	 * @param initiateDailyCycleData 
	 * 
	 * @return
	 * @throws DaoAccessException
	 * @throws JobExecutionAlreadyRunningException
	 * @throws JobFailedException
	 * @throws Exception
	 */
	public StringBuffer initiateDailyCycle(InitiateDailyCycleData initiateDailyCycleData) throws DaoAccessException, JobExecutionAlreadyRunningException,
			JobFailedException, Exception {
		StringBuffer dateCardMessageStr = new StringBuffer("");
		int returnCode = 0;
		DateCard dateCard = null;
		try {
			dateCard = dateCardDao.get();
			if (dateCard != null) {
				if (dateCard.getDaily_cycle_status().equals(URSBatchConstants.DAILY_CYCLE_STATUS_BEGIN)) {
					throw new JobExecutionAlreadyRunningException((message_source.getMessage("conclude.daily.cycle.validateDateCard.error", null,
							"Default", null)));
				}
				if (dateCard.getDaily_cycle_status().equals(URSBatchConstants.DAILY_CYCLE_STATUS_END)) {
					throw new JobExecutionAlreadyRunningException(message_source.getMessage("conclude.daily.cycle.validateDateCard.error", null,
							"Default", null));
				}
				java.util.Date currentDate = new java.util.Date();
				SimpleDateFormat formDate = new SimpleDateFormat(URSBatchConstants.DATE_FORMATER_TYPE);
				String curdate = formDate.format(currentDate);
				if (dateCard.getDaily_cycle_status().equals(URSBatchConstants.DAILY_CYCLE_STATUS_RUN)) {
					if (dateCard.getProcess_date().toString().compareTo(curdate) > 0) {
						returnCode = returnCode + URSBatchConstants.DAILY_CYCLE_STARTED_ERRORCODE;
						dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab);
						dateCardMessageStr.append(message_source.getMessage("dateCardJob.errormessage", null,
								"Default", null));
					} else if (dateCard.getProcess_date().toString().compareTo(curdate) < 0) {
						dateCard.setCycle_start_time(URSBatchConstants.DEFAULT_TIME_9999999);

					} else if (dateCard.getProcess_date().toString().compareTo(curdate) == 0) {
						DateFormat dateFormat = new SimpleDateFormat(URSBatchConstants.HR_MM_SEC_TYPE);
						Calendar cal = Calendar.getInstance();
						String time = dateFormat.format(cal.getTime());
						dateCard.setCycle_start_time(time);
					}
					if (dateCard.getProcess_date().compareTo(dateCard.getProcess_date_last()) < 0) {
						returnCode = URSBatchConstants.DAILY_CYCLE_ENDED_ERRORCODE;
						dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab);
						dateCardMessageStr.append(message_source.getMessage("dateCardJob.errormessageended", null,
								"Default", null));
					}
					int cycle_start_time = Integer.parseInt(dateCard.getCycle_start_time());
					int process_time_last = Integer.parseInt(dateCard.getProcess_time_last());
					if ((dateCard.getProcess_date().equals(dateCard.getProcess_date_last()))
							&& (cycle_start_time <= process_time_last)) {
						dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab);
						dateCardMessageStr.append(message_source.getMessage("dateCardJob.alreadystartedfortime", null,
								"Default", null));

					}
					dateCard.setDaily_cycle_status(URSBatchConstants.DAILY_CYCLE_STATUS_BEGIN);
					dateCardDao.update(dateCard);
				} else {
					throw new JobFailedException((message_source.getMessage("Error inside JobFailedException", null,
							"Default", null)) + dateCardMessageStr.toString());
				}

			} else {
				dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab
						+ "No Data In DataCard Table");
			}

		} catch (JobExecutionAlreadyRunningException e) {
			e.printStackTrace();
			dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab
					+ StacktraceUtil.getStackTrace(e));
			throw new JobExecutionAlreadyRunningException((message_source.getMessage("dateCardJob.alreadystarted",
					null, "Default", null)) + dateCardMessageStr.toString());
		} catch (JobFailedException e) {
			e.printStackTrace();
			dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab
					+ StacktraceUtil.getStackTrace(e));
			throw new JobFailedException(
					(message_source.getMessage("dateCardJob.failedmessage", null, "Default", null))
							+ dateCardMessageStr.toString());
		} catch (DaoAccessException e) {
			e.printStackTrace();
			dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab
					+ StacktraceUtil.getStackTrace(e));
			throw new DaoAccessException((message_source.getMessage("Error inside DaoAccessException ", null,
					"Default", null)) + dateCardMessageStr.toString());
		} catch (Exception e) {
			e.printStackTrace();
			dateCardMessageStr.append(URSBatchConstants.separator + URSBatchConstants.tab
					+ StacktraceUtil.getStackTrace(e));
			throw new Exception((message_source.getMessage("Error inside Exception", null, "Default", null))
					+ dateCardMessageStr.toString());
		}
		return dateCardMessageStr;

	}

	/**
	 * This method update DateCard Records
	 * @param concludeDailyCycleData 
	 * 
	 * @return
	 * @throws DaoAccessException
	 */
	public StringBuffer concludeDailyCycle(JobData concludeDailyCycleData) throws DaoAccessException {
		DateCard datecard = new DateCard();
		StringBuffer dateCardUpdateMessageStr = new StringBuffer("");
		try {
			datecard = dateCardDao.get();
			if (datecard == null) {
				dateCardUpdateMessageStr.append(URSBatchConstants.separator
						+ URSBatchConstants.tab);
				dateCardUpdateMessageStr.append(message_source.getMessage(
						"dateCardJob.errormessage", null, "Default", null));
			} else {

				StringTokenizer st = new StringTokenizer(datecard
						.getProcess_date().toString(), "-");
				int cnt = 0;
				int year = 0;
				int month = 0;
				int day = 0;
				while (st.hasMoreTokens()) {
					if (cnt == 0)
						year = Integer.parseInt(st.nextToken());
					if (cnt == 1)
						month = Integer.parseInt(st.nextToken());
					if (cnt == 2)
						day = Integer.parseInt(st.nextToken());
					cnt++;
				}
				Calendar cal = Calendar.getInstance();
				if (year == cal.get(Calendar.YEAR)
						&& month == cal.get(Calendar.MONTH) + 1
						&& day == cal.get(Calendar.DATE)) {
					SimpleDateFormat sdf = new SimpleDateFormat(
							URSBatchConstants.HR_MM_SEC_TYPE);
					datecard.setProcess_time_last(sdf.format(cal.getTime()));
				} else {
					datecard.setProcess_time_last(URSBatchConstants.DEFAULT_TIME_9999999);
					datecard.setDaily_cycle_status(URSBatchConstants.DAILY_CYCLE_STATUS_END);
				}
				dateCardDao.update(datecard);
			}
		} catch (DaoAccessException e) {
			e.printStackTrace();
			dateCardUpdateMessageStr.append(URSBatchConstants.separator
					+ URSBatchConstants.tab + StacktraceUtil.getStackTrace(e));
			throw new DaoAccessException((message_source.getMessage(
					"initiate.daily.cycle.updateDateCard.error", null,
					"Default", null))
					+ dateCardUpdateMessageStr.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateCardUpdateMessageStr;
	}

	

}
