package com.reinsurance.urs.batch.jobs.framewrk;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.dom.JobData;


public abstract class BaseItemProcessorAbstract<E, I> extends StepExecutionListenerSupport implements ItemProcessor<E, I> {
	
	protected Log log = LogFactory.getLog(getClass());

	@Autowired
	@Qualifier("batchMessageSource")
	private MessageSource message_source = null;

	

	protected String getMessage(String code) {
		return message_source.getMessage(code, null, "Default", null);
	}

	protected void sendExceptionMessage(Exception a_exception, JobData a_job_data, String a_message_id ,StepExecution stepExecution) {

		a_exception.printStackTrace();
		a_job_data.getExecutionMessageBuffer().append(StacktraceUtil.getStackTrace(a_exception));
		stepExecution.getExecutionContext().put(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY,
				a_job_data.getExecutionMessageString());

		log.info(getMessage("initiate.daily.cycle.error"));

	}

	protected void sendExecutionMessage(JobData a_job_data ,StepExecution stepExecution) {
		stepExecution.getExecutionContext().put(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY,
				a_job_data.getExecutionMessageString());
	}

	protected String logAndAppendMessage(String code) {
		log.info(getMessage(code));
		return (getMessage(code));

	}
}
