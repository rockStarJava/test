/**
 * 
 */
package com.reinsurance.urs.batch.jobs.framewrk;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.reinsurance.urs.batch.constants.URSBatchConstants;

/**
 * This class has general formatting methods
 * @author Lakshmi.Isukapally
 *
 */
public class FormatUtility {

	/**
	 *Converts given year,month,day to date format
	 * @param year
	 * @param month
	 * @param day
	 * @return
	 */
	public static Date toDate(int year, int month, int day) {
		Calendar c = Calendar.getInstance();

		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, month - 1);
		c.set(Calendar.DAY_OF_MONTH, day);
		return c.getTime();
	}

	/**
	 * returns last datae of any given month and year
	 * ex: if input was 1/15/2009  returns 1/31/2009
	 * @param date
	 * @return
	 */
	public static java.sql.Date lastDayOfMonth(Date date) {
		int year = Integer.parseInt(date.toString().split("-")[0]);
		int month = Integer.parseInt(date.toString().split("-")[1]) - 1;
		java.sql.Date returnDate = null;

		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.DAY_OF_MONTH, 1);// this is necessary to get proper
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		returnDate = new java.sql.Date(cal.getTimeInMillis());
		return returnDate;
	}

	/**
	 * parses date from the input string
	 * @param expDte
	 * @return
	 * @throws ParseException
	 */
	
	public static java.sql.Date parseDate(String expDte) throws ParseException {
		// expDte = URSBatchConstants.EXP_DATE;
		Date sqlExpDte = null;
		SimpleDateFormat sdf = new SimpleDateFormat(
				URSBatchConstants.DATE_FORMATER_TYPE);
		sqlExpDte = sdf.parse(expDte);
		java.sql.Date parsedDate = new java.sql.Date(sqlExpDte.getTime());
		return parsedDate;
	}

	/**
	 * Returns string in "dd/MM/YYYY" format from input date
	 * @param date
	 * @return
	 */
	public static String formatDate(java.sql.Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String dateString = sdf.format(date);
		return dateString;
	}

	/**
	 * returns string in "dd/MM/YYYY" format from input date
	 * @param date
	 * @return
	 */
	public static String formatDate(java.util.Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String dateString = sdf.format(date);
		return dateString;
	}

	/**
	 * returns current date and time in string format
	 * @return
	 */
	public static String getCurrentDateinStr() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	/**
	 * returns current date and time in string format
	 * @return
	 */
	public static Timestamp getCurrentDate() {
		 java.util.Date date= new java.util.Date();
		 return(new Timestamp(date.getTime()));
		
	}
	
	public static String getFormattedTimeStamp(Timestamp timestamp)
	{
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/YYYY HH:mm:ss");
		Date tmstmp = timestamp;
		try {
			tmstmp = format.parse(timestamp.toString());
		} catch (ParseException e) {
			return null;
		}
		return format.format(tmstmp);
		
	}

	public static int getYear(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int year = c.get(Calendar.YEAR);
		return year;
	}

	public static int getMonth(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int month = c.get(Calendar.MONTH);
		return month;
	}
}
