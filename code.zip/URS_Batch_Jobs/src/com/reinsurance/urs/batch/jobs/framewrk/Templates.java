/**
 * DynamicReports - Free Java reporting library for creating reports dynamically
 *
 * DynamicReports is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DynamicReports is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with DynamicReports. If not, see <http://www.gnu.org/licenses/>.
 */

package com.reinsurance.urs.batch.jobs.framewrk;

import static net.sf.dynamicreports.report.builder.DynamicReports.cmp;
import static net.sf.dynamicreports.report.builder.DynamicReports.stl;
import static net.sf.dynamicreports.report.builder.DynamicReports.tableOfContentsCustomizer;
import static net.sf.dynamicreports.report.builder.DynamicReports.template;

import java.awt.Color;
import java.util.List;
import java.util.Locale;

import net.sf.dynamicreports.report.base.expression.AbstractValueFormatter;
import net.sf.dynamicreports.report.builder.ReportTemplateBuilder;
import net.sf.dynamicreports.report.builder.component.ComponentBuilder;
import net.sf.dynamicreports.report.builder.component.HorizontalListBuilder;
import net.sf.dynamicreports.report.builder.component.VerticalListBuilder;
import net.sf.dynamicreports.report.builder.datatype.BigDecimalType;
import net.sf.dynamicreports.report.builder.style.ReportStyleBuilder;
import net.sf.dynamicreports.report.builder.style.StyleBuilder;
import net.sf.dynamicreports.report.builder.tableofcontents.TableOfContentsCustomizerBuilder;
import net.sf.dynamicreports.report.constant.HorizontalAlignment;
import net.sf.dynamicreports.report.constant.LineSpacing;
import net.sf.dynamicreports.report.constant.StretchType;
import net.sf.dynamicreports.report.constant.VerticalAlignment;
import net.sf.dynamicreports.report.definition.ReportParameters;

public class Templates {
	public static final StyleBuilder rootStyle;
	public static final StyleBuilder boldStyle;
	public static final StyleBuilder italicStyle;
	public static final StyleBuilder boldCenteredStyle;
	public static final StyleBuilder bold12CenteredStyle;
	public static final StyleBuilder bold13CenteredStyle;
	public static final StyleBuilder bold22CenteredStyle;
	public static final StyleBuilder columnStyle;
	public static final StyleBuilder columnTitleStyle;
	public static final StyleBuilder groupStyle;
	public static final StyleBuilder subtotalStyle;

	public static final ReportTemplateBuilder reportTemplate;
	public static final CurrencyType currencyType;
	public static final ComponentBuilder<?, ?> dynamicReportsComponent;

	public static final StyleBuilder columnStyleLarge;
	public static final StyleBuilder columnTitleStyleLarge;
	public static final StyleBuilder headerStyle;

	private static StyleBuilder borderedStyle;

	static {
		borderedStyle = stl.style(stl.pen());
		rootStyle = stl.style().setPadding(2);
		boldStyle = stl.style(rootStyle).bold();
		italicStyle = stl.style(rootStyle).italic();
		boldCenteredStyle = stl.style(boldStyle).setAlignment(
				HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
		bold12CenteredStyle = stl.style(boldCenteredStyle)
				.setLineSpacing(LineSpacing.DOUBLE).setFontSize(12);
		bold13CenteredStyle = stl.style(boldCenteredStyle).setFontSize(13)
				.setUnderline(true);
		bold22CenteredStyle = stl.style(boldCenteredStyle).setFontSize(22);
		columnStyle = stl.style(rootStyle).setVerticalAlignment(
				VerticalAlignment.JUSTIFIED);

		columnTitleStyle = stl.style(columnStyle)
				.setVerticalAlignment(VerticalAlignment.JUSTIFIED)
				.setHorizontalAlignment(HorizontalAlignment.CENTER)
				.setBorder(stl.pen()).setBackgroundColor(Color.LIGHT_GRAY)
				.bold();
		// Added for reports with more columns to display
		columnStyleLarge = stl.style(rootStyle)
				.setVerticalAlignment(VerticalAlignment.MIDDLE).setFontSize(6)
				.setVerticalAlignment(VerticalAlignment.JUSTIFIED);

		columnTitleStyleLarge = stl.style(columnStyleLarge)
				.setBorder(stl.pen())
				.setVerticalAlignment(VerticalAlignment.MIDDLE)
				// .setHorizontalAlignment(HorizontalAlignment.CENTER)
				.setBackgroundColor(Color.LIGHT_GRAY).bold();

		headerStyle = stl.style(boldCenteredStyle)
				.setHorizontalAlignment(HorizontalAlignment.LEFT)
				.setFontSize(8).setLineSpacing(LineSpacing.SINGLE);

		groupStyle = stl.style(boldStyle).setHorizontalAlignment(
				HorizontalAlignment.LEFT);
		subtotalStyle = stl.style(boldStyle).setTopBorder(stl.pen1Point());

		StyleBuilder crosstabGroupStyle = stl.style(columnTitleStyle);
		StyleBuilder crosstabGroupTotalStyle = stl.style(columnTitleStyle)
				.setBackgroundColor(new Color(170, 170, 170));
		StyleBuilder crosstabGrandTotalStyle = stl.style(columnTitleStyle)
				.setBackgroundColor(new Color(140, 140, 140));
		StyleBuilder crosstabCellStyle = stl.style(columnStyle).setBorder(
				stl.pen1Point());

		TableOfContentsCustomizerBuilder tableOfContentsCustomizer = tableOfContentsCustomizer()
				.setHeadingStyle(0, stl.style(rootStyle).bold());

		reportTemplate = template().setLocale(Locale.ENGLISH)
				.setColumnStyle(columnStyle)
				.setColumnTitleStyle(columnTitleStyle)
				.setGroupStyle(groupStyle).setGroupTitleStyle(groupStyle)
				.setSubtotalStyle(subtotalStyle).highlightDetailEvenRows()
				.crosstabHighlightEvenRows()
				.setCrosstabGroupStyle(crosstabGroupStyle)
				.setCrosstabGroupTotalStyle(crosstabGroupTotalStyle)
				.setCrosstabGrandTotalStyle(crosstabGrandTotalStyle)
				.setCrosstabCellStyle(crosstabCellStyle)
				.setTableOfContentsCustomizer(tableOfContentsCustomizer);

		currencyType = new CurrencyType();

		dynamicReportsComponent = cmp.horizontalList(
				cmp.image(
						Templates.class.getClassLoader().getResource(
								"images/dynamicreports.png"))
								.setFixedDimension(60, 60),
								cmp.verticalList(
										cmp.text("UNIVERSAL REINSURANCE SYSTEM")
										.setStyle(italicStyle)
										.setHorizontalAlignment(
												HorizontalAlignment.LEFT),
												cmp.text("REPORT :").setStyle(italicStyle)))
												.setFixedWidth(300);

	}
   /**
 * 
 * @param Type
 * @return
 */
	public static StyleBuilder getcolumnTitleStyleBasedOnType(HorizontalAlignment horizontalAlignment ,boolean lotOfColumns)
	
	{
		StyleBuilder columnTStyle = columnStyle;
		
		if(lotOfColumns)
		columnTStyle = stl.style(columnStyleLarge)
						.setBorder(stl.pen())
						.setHorizontalAlignment(horizontalAlignment)
						.setBackgroundColor(Color.LIGHT_GRAY).bold();
		
		else
			columnTStyle = stl.style(columnStyle)
			.setBorder(stl.pen())
			.setHorizontalAlignment(horizontalAlignment)
			.setBackgroundColor(Color.LIGHT_GRAY).bold();

		return  columnTStyle;
		
	}
	/**
	 * Creates custom component which is possible to add to any report band
	 * component
	 */
	public static ComponentBuilder<?, ?> createTitleComponent(String label) {
		return cmp
				.horizontalList()
				.add(dynamicReportsComponent,
						cmp.text(label)
						.setStyle(bold13CenteredStyle)
						.setHorizontalAlignment(
								HorizontalAlignment.RIGHT)).newRow()
								.add(cmp.line()).newRow().add(cmp.verticalGap(10));
	}

	/**
	 * Creates custom component which is possible to add to any report band
	 * component
	 */
	public static ComponentBuilder<?, ?> createSubTitleComponent(String label) {
		return cmp
				.horizontalList()
				.add(dynamicReportsComponent,
						cmp.text(label)
						.setStyle(bold12CenteredStyle)
						.setHorizontalAlignment(
								HorizontalAlignment.RIGHT)).newRow()
								.add(cmp.line()).newRow().add(cmp.verticalGap(10));
	}

	/**
	 * For PrintCheck Job
	 * 
	 * @param label
	 * @return
	 */

	/* start For PrintCheck Job */

	public static ComponentBuilder<?, ?> createHorizontalList(String value,
			int cell, int columns) {
		HorizontalListBuilder horizontalList = cmp.horizontalList()
				.setStretchType(StretchType.RELATIVE_TO_BAND_HEIGHT);
		for (int i = 0; i < columns; i++) {
			if (i == cell)
				horizontalList.add(cmp.text(value)
						.setPrintWhenDetailOverflows(true)
						.setStyle(borderedStyle));
			else
				horizontalList.add(cmp.text("").setStyle(borderedStyle));
		}
		return horizontalList;
	}

	public static ComponentBuilder<?, ?> createHorizontalList(
			List<String> strings, int[] cells, int columns) {
		HorizontalListBuilder horizontalList = cmp.horizontalList();
		int index = 0;
		int stringIndex = 0;
		boolean allSet = false;
		for (int i = 0; i < columns; i++) {

			if (!allSet && i == cells[index]) {
				horizontalList.add(cmp.text((String) strings.get(stringIndex))
						.setPrintWhenDetailOverflows(true)
						.setStyle(borderedStyle));
				index++;
				stringIndex++;
			} else
				horizontalList.add(cmp.text("").setStyle(borderedStyle));

			if (index >= cells.length) {
				allSet = true;

			}
		}

		return horizontalList;
	}

	public static ComponentBuilder<?, ?> createMultiRowHorizontalList() {
		HorizontalListBuilder horizontalList = cmp.horizontalList();
		for (int i = 0; i < 3; i++) {
			horizontalList.add(cmp.text("").setStyle(borderedStyle));
		}
		horizontalList.newRow();
		for (int i = 0; i < 7; i++) {
			horizontalList.add(cmp.text("").setStyle(borderedStyle));
		}
		return horizontalList;
	}

	public static ComponentBuilder<?, ?> createHorizontalFlowList() {
		HorizontalListBuilder horizontalList = cmp.horizontalFlowList();
		for (int i = 0; i < 9; i++) {
			horizontalList.add(cmp.text("").setStyle(borderedStyle));
		}
		return horizontalList;
	}

	public static ComponentBuilder<?, ?> createVerticalList() {
		VerticalListBuilder verticalList = cmp.verticalList();
		for (int i = 0; i < 4; i++) {
			verticalList.add(cmp.text("").setStyle(borderedStyle));
		}
		return verticalList;
	}

	public static ComponentBuilder<?, ?> createNestedList() {
		HorizontalListBuilder horizontalList = cmp.horizontalList();
		for (int i = 0; i < 3; i++) {
			horizontalList.add(createVerticalList());
		}
		return horizontalList;
	}

	/* End For PrintCheck Job */

	public static CurrencyValueFormatter createCurrencyValueFormatter(
			String label) {
		return new CurrencyValueFormatter(label);
	}

	public static class CurrencyType extends BigDecimalType {
		private static final long serialVersionUID = 1L;

		@Override
		public String getPattern() {
			return "$ #,###.00";
		}
	}

	private static class CurrencyValueFormatter extends
	AbstractValueFormatter<String, Number> {
		private static final long serialVersionUID = 1L;

		private String label;

		public CurrencyValueFormatter(String label) {
			this.label = label;
		}

		@Override
		public String format(Number value, ReportParameters reportParameters) {
			return label
					+ currencyType.valueToString(value,
							reportParameters.getLocale());
		}
	}

	public static ReportStyleBuilder getcolumnStyleBased(
			HorizontalAlignment horizontalAlignment, boolean lotOfColumns) {
		
		StyleBuilder	colStyle = stl.style(rootStyle).setVerticalAlignment(
				VerticalAlignment.JUSTIFIED)
				.setHorizontalAlignment(horizontalAlignment);

		if(lotOfColumns)// Added for reports with more columns to display
		colStyle= stl.style(rootStyle)
				.setVerticalAlignment(VerticalAlignment.MIDDLE).setFontSize(6)
				.setHorizontalAlignment(horizontalAlignment);

		return colStyle;
	}
}