package com.reinsurance.urs.batch.jobs;

import static org.springframework.batch.repeat.RepeatStatus.FINISHED;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.URSBatchConstants;

/**
 * Example tasklet class ,just for reference
 * @author 
 *
 */
@Component("sampleTasklet")
public class SampleTasklet extends StepExecutionListenerSupport implements Tasklet {
	
	String name;
	
	String greeting;
	
	public void beforeStep(StepExecution stepExecution) {
	      JobParameters jobParameters = stepExecution.getJobParameters();
	      name = jobParameters.getString("Name");
	      greeting = jobParameters.getString("Greeting");
	  }

	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        chunkContext.getStepContext().getStepExecution().getExecutionContext().put(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY, "example Message");

        return FINISHED;
	}

}
