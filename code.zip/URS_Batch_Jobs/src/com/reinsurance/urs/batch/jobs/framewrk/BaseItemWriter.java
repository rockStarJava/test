package com.reinsurance.urs.batch.jobs.framewrk;

import org.hibernate.SessionFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.util.Assert;

public abstract class BaseItemWriter<E> implements ItemWriter<E>,
		InitializingBean {

	@Autowired
	private SessionFactory ursSessionFactory;

	@Autowired
	@Qualifier("batchMessageSource")
	private MessageSource message_source = null;

	protected String getMessage(String code) {
		return message_source.getMessage(code, null, "Default", null);
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.ursSessionFactory = sessionFactory;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.state(ursSessionFactory != null, getMessage("job.writer.error"));

	}

}
