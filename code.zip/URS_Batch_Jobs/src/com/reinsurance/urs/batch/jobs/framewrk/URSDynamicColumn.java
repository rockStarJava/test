/**
 * 
 */
package com.reinsurance.urs.batch.jobs.framewrk;

import com.reinsurance.urs.batch.constants.ReportConstants;

import net.sf.dynamicreports.report.constant.HorizontalAlignment;

/**
 * @author Lakshmi.Isukapally
 * 
 */
public class URSDynamicColumn extends DynamicColumn {

	public URSDynamicColumn(String title, String name, String type,
			HorizontalAlignment horizontalAlignment) {
		super(title, name, type);
		setHorizontalAlignment(horizontalAlignment);

	}

	/**
	 * @param title
	 * @param name
	 * @param type
	 */
	public URSDynamicColumn(String title, String name, String type) {

		super(title, name, type);
		HorizontalAlignment horizontalAlignment = HorizontalAlignment.JUSTIFIED;
		if (type == ReportConstants.DATE||type == ReportConstants.TIMESTAMP)
			horizontalAlignment = HorizontalAlignment.CENTER;
		else if (type == ReportConstants.STRING)
			horizontalAlignment = HorizontalAlignment.LEFT;
		else if (type == ReportConstants.BIGDECIMAL)
			horizontalAlignment = HorizontalAlignment.RIGHT;
		setHorizontalAlignment(horizontalAlignment);

	}

}
