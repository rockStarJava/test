
package com.reinsurance.urs.batch.jobs.framewrk;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.dom.JobData;


/**
 * @author Dave.Sauer
 *
 */
public abstract class BatchJobAbstract extends StepExecutionListenerSupport implements Tasklet{
	
	protected List<Step> steps = new ArrayList<Step>();
	
	@Autowired
    @Qualifier("batchMessageSource")
	private 	MessageSource 	message_source			= null;
	
	protected Log log = LogFactory.getLog(getClass());

	protected String getMessage(String code){
		return message_source.getMessage(code, null, "Default", null);
	}

	
	
	protected void sendExceptionMessage(Exception a_exception,
								JobData a_job_data,
								String a_message_id,
								ChunkContext a_chunkContext){
		
		
		a_exception.printStackTrace();
		a_job_data.getExecutionMessageBuffer().append(StacktraceUtil.getStackTrace(a_exception));
        a_chunkContext.getStepContext()
                    .getStepExecution()
                    .getExecutionContext()
                    .put(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY, a_job_data.getExecutionMessageString());
        
       log.info(getMessage("initiate.daily.cycle.error"));		 

	}
	
	protected void sendExecutionMessage(JobData a_job_data, ChunkContext a_chunkContext){
		a_chunkContext.getStepContext()
					  .getStepExecution()
					  .getExecutionContext()
					  .put(URSBatchConstants.STEP_EXECUTION_MESSAGE_KEY, a_job_data.getExecutionMessageString());
	}

	protected String logAndAppendMessage(String code)
	{
		log.info(getMessage(code));
		return(getMessage(code));
	      
	}
	protected String logAndAppendMessage(String code ,int value ,boolean addNewLine)
	{
		if(addNewLine)
		log.debug(URSBatchConstants.newLine);	
		log.debug(getMessage(code) + value);
		return(URSBatchConstants.newLine+getMessage(code) +value);
	      
	}

}