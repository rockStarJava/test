package com.reinsurance.urs.batch.jobs;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.jobs.framewrk.BaseItemWriter;
import com.reinsurance.urs.dao.underwriting.contracts.ContractDao;
import com.reinsurance.urs.domain.underwriting.contracts.Contract;

@Component("sampleItemWriter")
public class SampleItemWriter extends BaseItemWriter<Contract> {

	@Autowired
	@Qualifier("contractDao")
	private ContractDao contractDao = null;

	@Override
	public void write(List<? extends Contract> items) throws Exception {
		for (Contract contract : items) {
			contractDao.update(contract);
		}

	}

}
