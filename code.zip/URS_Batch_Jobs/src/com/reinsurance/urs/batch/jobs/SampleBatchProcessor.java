package com.reinsurance.urs.batch.jobs;

import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.domain.underwriting.contracts.Contract;

@Component("sampleBatchProcessor")
public class SampleBatchProcessor extends StepExecutionListenerSupport
		implements ItemProcessor<Contract, Contract> {

	@Override
	public Contract process(Contract contract) throws Exception {

		return contract;
	}

}
