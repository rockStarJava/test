
package com.reinsurance.urs.batch.jobs.framewrk;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.AbstractJob;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;



/**
 * @author Lakshmi.Isukapally
 *
 */
public abstract class BaseJob extends AbstractJob {
	
	protected List<Step> steps = new ArrayList<Step>();
	
	@Autowired
    @Qualifier("batchMessageSource")
	protected 	MessageSource 	message_source			= null;

	
	protected static final Logger logger = LoggerFactory
			.getLogger(BaseJob.class);

	public BaseJob(String name) {
		super(name);
	}
	/**
	 * Public setter for the steps in this job. Overrides any calls to
	 * {@link #addStep(Step)}.
	 *
	 * @param steps the steps to execute
	 */
	public void setSteps(List<Step> steps) {
		this.steps.clear();
		this.steps.addAll(steps);
	}

	/**
	 * Convenience method for clients to inspect the steps for this job.
	 *
	 * @return the step names for this job
	 */
	@Override
	public Collection<String> getStepNames() {
		List<String> names = new ArrayList<String>();
		for (Step step : steps) {
			names.add(step.getName());
		}
		return names;
	}
	
	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.springframework.batch.core.job.AbstractJob#getStep(java.lang.String)
	 */
	@Override
	public Step getStep(String stepName) {
		for (Step step : this.steps) {
			if (step.getName().equals(stepName)) {
				return step;
			}
		}
		return null;
	}

	/**
	 * Convenience method for adding a single step to the job.
	 *
	 * @param step a {@link Step} to add
	 */
	public void addStep(Step step) {
		this.steps.add(step);
	}

}