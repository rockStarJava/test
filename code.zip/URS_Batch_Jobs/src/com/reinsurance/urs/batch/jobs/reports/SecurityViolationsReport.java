package com.reinsurance.urs.batch.jobs.reports;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import net.sf.dynamicreports.report.datasource.DRDataSource;
import net.sf.dynamicreports.report.exception.DRException;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.reinsurance.urs.batch.constants.ReportConstants;
import com.reinsurance.urs.batch.constants.URSBatchConstants;
import com.reinsurance.urs.batch.dom.JobData;
import com.reinsurance.urs.batch.exceptions.JobFailedException;
import com.reinsurance.urs.batch.exceptions.ReportGenerationException;
import com.reinsurance.urs.batch.jobs.framewrk.BatchJobAbstract;
import com.reinsurance.urs.batch.jobs.framewrk.DynamicReport;
import com.reinsurance.urs.batch.jobs.framewrk.FormatUtility;
import com.reinsurance.urs.batch.jobs.framewrk.URSDynamicColumn;
import com.reinsurance.urs.batch.service.DynamicReportGenerationService;
import com.reinsurance.urs.dao.exception.DaoAccessException;
import com.reinsurance.urs.dao.sysadmin.DateCardDao;
import com.reinsurance.urs.dao.sysadmin.SystemUserSecurityDao;
import com.reinsurance.urs.domain.service.exception.ServiceCallException;
import com.reinsurance.urs.domain.sysadmin.SecurityViolation;
import com.reinsurance.urs.domain.sysadmin.SystemUserProxy;

@Component("generateSecurityViolationReport")
public class SecurityViolationsReport extends BatchJobAbstract {

	@Autowired
	@Qualifier("dynamicReportGenerationService")
	DynamicReportGenerationService dynamicReportGenerationService;

	@Autowired
	@Qualifier("systemUserSecurityDao")
	private SystemUserSecurityDao systemUserSecurityDao = null;

	@Autowired
	@Qualifier("dateCardDao")
	DateCardDao dateCardDao = null;

	// Field Ids are used to identify report data columns (Ids).these are not
	// displayed in the report
	private final String fieldID_userCode = "UserCode";
	private final String fieldID_userName = "userName";
	private final String fieldID_timestamp = "timestamp";
	private final String fieldID_description = "description";

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {

		JobParameters jobParameters = chunkContext.getStepContext()
				.getStepExecution().getJobParameters();

		@SuppressWarnings("serial")
		JobData securityViolationsReportData = new JobData() {
		};
		try {
			long processExecutionInstanceId = jobParameters
					.getLong(URSBatchConstants.PROCESS_EXECUTION_ID);

			DRDataSource reportsData = null;
			securityViolationsReportData
					.appendExecutionMessage(logAndAppendMessage("security.violations.job.getdata"));

			List<SecurityViolation> securityViolationList = systemUserSecurityDao
					.fetchAllViolationsOrderedByUserCd();

			if (securityViolationList != null
					&& !securityViolationList.isEmpty()) {
				securityViolationsReportData
						.appendExecutionMessage(logAndAppendMessage(
								"security.violations.job.datasetsize",
								securityViolationList.size(), true));

				reportsData = new DRDataSource(fieldID_userCode,
						fieldID_userName, fieldID_timestamp,
						fieldID_description);

				Iterator<SecurityViolation> it = securityViolationList
						.iterator();
				while (it.hasNext()) {
					SecurityViolation securityViolationObj = it.next();

					SystemUserProxy userInformationRec = securityViolationObj
							.getUser_cd();
					if (userInformationRec != null) {
						String statusDescription = getDescriptionBasedOnattempts(securityViolationObj
								.getPassword_attempts());
						reportsData
								.add(userInformationRec.getCode(),
										userInformationRec.getName(),
										FormatUtility
												.getFormattedTimeStamp(securityViolationObj
														.getViolation_timestamp()),
										statusDescription);
					}
				}
			}

			boolean reportGenerationstatus = false;
			if (reportsData != null)
				reportGenerationstatus = generateReportForSecurityViolations(
						reportsData, processExecutionInstanceId,
						securityViolationsReportData);
			if (reportGenerationstatus) {
				securityViolationsReportData
						.appendExecutionMessage(URSBatchConstants.separator
								+ URSBatchConstants.tab
								+ logAndAppendMessage("security.report.success")
								+ dynamicReportGenerationService
										.getReportDirectoryLocation());
			} else {
				securityViolationsReportData
						.appendExecutionMessage(URSBatchConstants.separator
								+ URSBatchConstants.tab
								+ logAndAppendMessage("security.report.failure"));

			}
		} catch (Exception e) {
			sendExceptionMessage(e, securityViolationsReportData,
					"security.report.error", chunkContext);
			throw new JobFailedException((getMessage("batchJob.error"))
					+ securityViolationsReportData.getExecutionMessageString());
		}

		return RepeatStatus.FINISHED;
	}

	/**
	 * This method generates and stores AccountContractLiability for the data
	 * passed
	 * 
	 * @param periodBegin
	 * @param periodEnd
	 * @param reportDataSource
	 * @param securityViolationsReportData
	 * @return
	 * @throws ReportGenerationException
	 * @throws IOException
	 * @throws ServiceCallException
	 * @throws DaoAccessException
	 */
	private boolean generateReportForSecurityViolations(
			DRDataSource reportDataSource, long processExecutionInstanceId,
			JobData securityViolationsReportData) throws DRException,
			ReportGenerationException, FileNotFoundException, IOException,
			DaoAccessException, ServiceCallException {
		boolean status = false;
		java.sql.Date period = null;
		try {
			period = dateCardDao.get().getProcess_date();
		} catch (DaoAccessException e) {
			securityViolationsReportData
					.appendExecutionMessage(getMessage("batchjob.report.datecardError"));
			return false;
		}
		String reportStPrefix = getMessage("security.report.st_prefix");
		String reportEndPrefix = getMessage("security.report.end_prefix");
		String reportTitle = getMessage("security.report.title");
		DynamicReport dynamicReport = new DynamicReport();

		dynamicReport.addColumn(new URSDynamicColumn(
				getMessage("security.report.heading.usercode"),
				fieldID_userCode, ReportConstants.STRING));
		dynamicReport.addColumn(new URSDynamicColumn(
				getMessage("security.report.heading.username"),
				fieldID_userName, ReportConstants.STRING));

		dynamicReport.addColumn(new URSDynamicColumn(
				getMessage("security.report.heading.timestamp"),
				fieldID_timestamp, ReportConstants.STRING));
		dynamicReport.addColumn(new URSDynamicColumn(
				getMessage("security.report.heading.Description"),
				fieldID_description, ReportConstants.STRING));
		// dynamicReport.addGroup(column);
		dynamicReport.setShowPageNumber(true);
		status = dynamicReportGenerationService.generateReport(reportStPrefix,
				reportEndPrefix, dynamicReport, reportDataSource,
				getMessage("security.report.title.security_report_name"),
				reportTitle, period, processExecutionInstanceId);
		return status;
	}

	private String getDescriptionBasedOnattempts(Integer password_attempts) {

		String description = "";
		int attempts = password_attempts.intValue();

		if (attempts == 3)
			description = "invalid password (3rd attempt)";

		if (attempts == 5)
			description = "invalid password (5th attempt) , user id revoked";
		return description;

	}
}
