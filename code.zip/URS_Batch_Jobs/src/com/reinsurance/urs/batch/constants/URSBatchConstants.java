package com.reinsurance.urs.batch.constants;

import org.apache.commons.lang.SystemUtils;

public class URSBatchConstants {

	public enum Day {
		FRIDAY("6"), MONDAY("2"), SATURDAY("7"), SUNDAY("1"), THURSDAY("5"), TUESDAY("3"), WEDNESDAY("4");
		private String value;

		private Day(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
	public enum Frequency {
		First("first"), Fourth("fourth"), Last("last"), Second("second"), Third("third");

		private String value;

		private Frequency(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
	public static enum Month {
		APRIL("4"), AUGUST("8"), DECEMBER("12"), FEBRUARY("2"), JANUARY("1"), JULY("7"), JUNE("6"), MARCH("3"), MAY("5"), NOVEMBER("11"), OCTOBER(
						"10"), SEPTEMBER("9");
		private String value;

		private Month(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	public static final String ACCOUNT_LOSS_ACCT_TRANSACTION_90 = "90";
	public final static String ACCOUNT_TRANSACTION = "21";
	public static final String ACCOUNT_TRANSACTION_18 = "18";

	public static final String ACCOUNT_UPDATES = "accountUpdates";
	public static final String accountControlhasmap = "accountControlhasmap";

	public final static String AMOUNT_COMPONENT_10 = "10";
	public final static String AMOUNT_COMPONENT_7 = "7";

	public final static String AMOUNT_COMPONENT_IND_P = "P";
	public final static String BLANK_SPACE = "";

	public static final String BROKER_ZEROES = "00000";
	public final static String BROKERAGE_BASE_N = "n";

	public final static String BROKERAGE_BASE_T = "t";
	public static final String BUSINESS_TYPE = "3";

	public static final String BUSINESS_TYPE_2 = "2";
	public static final String CASH_PMT = "CASH PMT";
	public final static String CERTIFICATE = "DEPOSIT PREMIUM";

	public static final String CHECK_NUM = "CheckNum";
	public static final String CLAIM_ID = "ClaimID :";
	public static final int CODE_INPUT_TYPE_BOOLEAN = 4;

	public static final int CODE_INPUT_TYPE_DATE = 3;
	public static final int CODE_INPUT_TYPE_DOUBLE = 2;

	public static final int CODE_INPUT_TYPE_STRING = 1;

	public static final String COMMISSION_BAL = "COMMISSION BAL";

	public final static String COMMISSION_TYPE_F = "f";
	public final static String COMMISSION_TYPE_G = "g";

	public final static String COMMISSION_TYPE_O = "o";
	public final static String COMMISSION_TYPE_P = "p";

	public static final int contract_desc_order = 1;

	public static final String CONTRACT_EXPER_AAR_IDICATOR_B = "B";

	public static final String CONTRACT_EXPER_AAR_IDICATOR_L = "L";
	public static final String CONTRACT_EXPER_MEMO_INDICATOR_M = "M";
	// Contract_Exper order
	public static final int Contract_Exper_order = 1;

	public static final String CONTRACT_EXPER_TYPE_U = "U";
	public static final String CONTRACT_LOSS_EXPER_BASIS_C = "C";
	public final static String CONTRACT_TYPE_5 = "5";

	public final static String CURRENCY_TYPE_0 = "0";
	public final static String CURRENCY_TYPE_1 = "1";
	public final static String CURRENCY_TYPE_2 = "2";

	public static final int CYCLE_DELETE_FAILURE = 1;
	public static final int CYCLE_DELETE_SUCCESS = 0;
	public static final int CYCLE_DETAILS_EMPTY = -1;
	public static final int CYCLE_EXECUTION_ERROR = 1;

	public static final String CYCLE_EXECUTION_FAILURE_STATUS = "FAIL";
	public static final int CYCLE_EXECUTION_SUCCESS = 0;
	public static final String CYCLE_EXECUTION_SUCCESS_STATUS = "SUCCESS";
	public static final int CYCLE_INSERT_FAILURE = 0;

	public static final int CYCLE_INSERT_SUCCESS = 1;

	public static final String CYCLE_JOB_DEFAULT_CONDITION = "NONE";

	public static final int DAILY_CYCLE_ENDED_ERRORCODE = 3;
	public static final int DAILY_CYCLE_STARTED_ERRORCODE = 2;
	public static final String DAILY_CYCLE_STATUS_BEGIN = "BEGUN";
	public static final String DAILY_CYCLE_STATUS_END = "ENDED";

	public static final String DAILY_CYCLE_STATUS_RUN = "UNRUN";

	public static final String DAILY_FORM_DATE = "DailyFromDate";
	public static final String DAILY_MONTHLY_IND = "DailyMonthlyInd";
	public static final String DAILY_MONTHLY_IND_D = "D";
	public static final String DAILY_MONTHLY_IND_M = "M";
	public static final String DAILY_THRU_DATE = "DailyThruDate";
	public static final String DATE_FORMAT = "MMMM d, yyyy";

	public static final String DATE_FORMATER_TYPE = "yyyy-MM-dd";
	public static final String DEFAULT_TIME = "31/12/9999";
	public static final String DEFAULT_TIME_9999999 = "9999999";
	public static final String DEPOSIT_PREM_DATASOURCES = "depositPremiumDataSources";

	public static final String DEPOSIT_PREMIUM_DATASOURCES = "DEPOSIT PERMIUM DATA SOURCE";
	public static final String DEPOSIT_PREMIUM_OBJECT = "DEPOSIT PERMIUM OBJECT";
	public static final String ENTITY_NAME_UWINCURREDQFCTR = "UWIncurredQFctr";
	public static final String ENTITY_NAME_UWINCURREDYFCTR = "UWIncurredYFctr";
	public static final String ENTITY_NAME_UWLOSSRATIOFCTR = "UWLossRatioFctr";
	public static final String EXECUTION_STARTED = "START";
	public static final String EXP_DATE = "0001-01-01";
	public final static String FEDERAL_EXCISE_IND = "Y";
	public final static String FEDERAL_EXCISE_TAX_RECORD_B = "B";
	public final static String FEDERAL_EXCISE_TAX_RECORD_RECPAY_GROSSPAY_Y = "Y";
	public static final String FILE_CONTENT = "fileContent";
	public static final String FIN_IBNR_N = "n";

	public static final String FIN_IBNR_Y = "Y";
	public static final String FLATFILE_PREMIUM_LOSS_L = "l";
	public static final String FLATFILE_PREMIUM_LOSS_P = "p";
	public static final String FUNDS_LOSS = "FUNDS LOSS";
	public static final String HR_MM_SEC_TYPE = "HHmmsss";
	public static final String IBNR_IBNR_METHOD_E = "E";
	public static final String ID = "ID :";
	public static final String IND_N = "N";
	public static final String IND_Y = "y";
	public static final String INPUT_CONTROL_END_DATE = "InputControlEndDate";
	public static final String INPUT_CONTROL_NUM = "InputControlNumber";
	public static final String INPUT_CONTROL_START_DATE = "InputControlStartDate";
	public static final String INPUT_FINANCIAL_IBNR_FLAG = "InputFinancialIbnrFlag";

	public static final String INPUT_TYPE_BOOLEAN = "BOOLEAN";
	public static final String INPUT_TYPE_DATE = "DATE";
	public static final String INPUT_TYPE_DOUBLE = "DOUBLE";
	public static final String INPUT_TYPE_STRING = "STRING";
	public static final String INPUT_UND_IBNR_FLAG = "InputUndIbnrFlag";
	public static final int JOB_DETAILS_EMPTY = -1;
	public static final int JOB_EXECUTION_FAILURE = -1;
	public static final String JOB_EXECUTION_FAILURE_STATUS = "FAIL";
	public static final int JOB_EXECUTION_SUCCESS = 0;
	public static final String JOB_EXECUTION_SUCCESS_STATUS = "SUCCESS";
	public static final String LIST_J_REPORT = "listJReports";
	public static final String logger_star = "***************************************************************************************************************************************************************";
	// JobParam type
	public static final String MEMO_INDICATOR_C = "C";
	public static final String MEMO_INDICATOR_Z = "Z";
	public static final String MISC_BAL = "MISC BAL";
	public static final String Mode = "mode";
	public static final String MONTH_DATE_YEAR_FORMAT = "MM-dd-yyyy";
	public static final String MONTHLY_BOOKED_DATE = "monthlyBookedDate";
	public static final String MONTHLY_FORM_DATE = "MonthlyFromDate";
	public static final String MONTHLY_THRU_DATE = "MonthlyThruDate";

	public static final String newLine = "\n";
	public static final String OPERATOR_ID = "OperatorId";
	// Used for Federal Exercise
	public static final String OPERATORID_D08 = "D08";
	public final static String ORIGIN_BOOK_IDICATOR_O = "O";
	public static final String OTHER_CONDTION = "u";
	public static final String PAID_APPLIED = "PAID APPLIED";
	public static final String PAID_LAE = "PAID LAE";
	public static final String PARTIAL_ADJ = "PARTIAL ADJ";
	public static final String PREMIUM = "PREMIUM";
	public static final String PRINT_TODAY_ONLY = "PrintTodayOnly";
	public static final String PRIORITY = "1";
	public static final String PROCESS_CYCLE_DEFAULT_CONDITION = "NONE";
	public static final int PROCESS_CYCLE_RELATION = -1;
	public static final int PROCESS_DELETED = 1;
	public static final int PROCESS_DETAILS_EMPTY = -1;
	public static final String PROCESS_EXECUTION_FAILURE_STATUS = "FAIL";
	public static final int PROCESS_EXECUTION_SUCCESS = 0;
	public static final String PROCESS_EXECUTION_SUCCESS_STATUS = "SUCCESS";
	public static final int PROCESS_IN_ERROR = 1;
	public static final String PROCESS_STATE_ACTIVE = "ACTIVE";
	public static final int PROCESS_STATE_ACTIVE_CD = 1;
	public static final String PROCESS_STATE_DRAFT = "DRAFT";
	public static final int PROCESS_STATE_DRAFT_CD = 0;
	public static final String PROCESS_STATE_INACTIVE = "INACTIVE";
	public static final int PROCESS_STATE_INACTIVE_CD = 2;
	public static final String RATE_IND_B = "b";
	public final static String REPORT_BOOKING = "bk eq";
	public static final String RETRO_NUM = "0000000";
	public static final String RETRO_TYPE = "i";
	public static final String RETRO_ZEROES = "0000000";
	public static final String ROUNDING = "ROUNDING";
	public static final String separator = SystemUtils.LINE_SEPARATOR;
	public final static String STATUS = "A";
	public static final String STEP_EXECUTION_MESSAGE_KEY = "EXECUTION_MESSAGE";
	public final static String SYSTEM_DEFAULT_ID = "01";
	public static final String tab = "\t" + "\t";
	public static final String TEMP_GROSS_CEEDED_C = "c";
	// Used for JOB ibnrUpdateJob(TRDBAU05)
	public static final String TEMP_GROSS_CEEDED_G = "g";
	public static final String TIMESTAMP = "TimeStamp";
	// used for GenerateDepositPremiums
	public final static String UPR_FORMULA = "D";

	public final static String USER_OPERATOR_ID = "d10";

	public static final String WORLD_WIDE_ZONE_130 = "130";

	public static final String year_format = "yyyy";
	public static final String RETROSPECTIVE_MONTHLY_OBJECT = "RETROSPECTIVEMONTHLYOBJECT";
	public static final String PROCESS_EXECUTION_ID = "PROCESS_EXECUTION_ID";
	public static final String FAILEDSTATUS = "FAILED";
	public static final String PurgedRecords = "purged records :";
	public static final String DASH = "-";
	public static final String TO = " to ";
	public static final String BOOKED_DATE = "BOOKED DATE";
	public static final String MONTHLY_IBNR_PROCESSING_DATA = "MONTHLY_IBNR_PROCESSING_DATA";
	public static final String MONTHLY_IBNR_PROCESSING_ACCOUNTLOSS_RECORDS_MAP = "ACCOUNTLOSS_RECORDS_MAP";
	public static final String PRIOR_WORK_ACCOUNT_CONTROL ="PRIOR_WORK_ACCOUNT_CONTROL";


}
