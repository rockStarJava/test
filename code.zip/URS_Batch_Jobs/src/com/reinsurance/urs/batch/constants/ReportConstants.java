package com.reinsurance.urs.batch.constants;

public class ReportConstants {

	// Report's Field Data type
	public static String STRING = "string";
	public static String DATE = "date";
	public static String BIGDECIMAL = "bigDecimal";
	public static String INT = "integer";
	// Account Common Constants
	public static String CURRENCY_TYPE = "2";
	public static String ACC_TYPE_1 = "01";
	public static String ACC_TYPE_2 = "02";
	public static String OPERATORID_D05 = "D05";
	public static String OPERATORID_D07 = "D07";
	public static String OPERATORID_D20 = "D20";
	public static String OPERATORID_D21 = "D21";
	public static String OPERATORID_D22 = "D22";
	public static String OPERATORID_D29 = "D29";
	public static String OPERATORID_M19 = "M19";
	public static String OPERATORID_M05 = "M05";
	public static String OPERATORID_M07 = "M07";
	public static String OPERATORID_D03 = "D03";

	public static String[] OPERATO_ID = { "D05", "D07", "D12", "M19", "M05",
			"M07", "M12", "M13" };
	// Account Loss Report Constants
	// Checks For Claims Paid Report constant
	public static String CHECKS_FOR_CLAIM_REPORT_CONSTANT_20 = "20";
	public static String TIMESTAMP = "timestamp";
}
